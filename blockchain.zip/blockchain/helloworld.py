import httpx
import ssl
import json

with httpx.Client(verify=None, timeout=None) as client:
    try:
        resp = client.post("https://127.0.0.1:5000/agent/doPrePrepareGenesis")
        print(resp)
    except httpx.ConnectError as e:
        pass