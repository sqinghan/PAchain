import json
import logging


class Message:
    def __init__(self):
        self.type = 0
        pass

    def toJson(self):
        return json.dumps(self, default=lambda o: o.__dict__)


class PeerMessage(Message):
    def __init__(self, operation, operation_data, involved_request_hashes, prev_block_hash,
                 matter_hash, view, sequence, time_stamp, uuid, relay_time_stamp):
        super().__init__()
        if not (operation in MessageType.consensus_operation_domain):
            logging.error("Operation undefined!")
            self.operation = None
        else:
            self.operation = operation
        self.operation_data = operation_data
        self.involved_request_hashes = involved_request_hashes  # (List)
        self.prev_block_hash = prev_block_hash
        self.matter_hash = matter_hash  # (hash str)
        self.view = view
        self.sequence = sequence
        self.time_stamp = time_stamp
        self.uuid = uuid
        self.relay_time_stamp = relay_time_stamp

    def toMatter(self):
        return {'operation': self.operation,
                'operation_data': self.operation_data,
                'involved_request_hashes': self.involved_request_hashes,
                'prev_block_hash': self.prev_block_hash,
                'time_stamp': self.time_stamp
                }


class MessageType:
    cli_operation_domain = {1, 2, 3, 4, 5}
    consensus_operation_domain = {21, 22, 23}
    gossip_operation_domain = {5}

    messageTypes = {9, 10, 11, 12, 13}

    REQUEST = 10
    PRE_PREPARE = 11
    PREPARE = 12
    COMMIT = 13

    CLI_MESSAGE = 0
    UPLOAD_GENESIS = 1
    SOLVING_REQUEST = 2
    SOLVING_RESULT = 3

    RESULT_GOSSIP = 5

    CONSENSUS_GENESIS = 21
    CONSENSUS_ITERATION = 22


class ConsensusStatus:
    lH = 0
    hH = 0
    view = 0
    sequence = 0
    n = 4
    f = 1
    block_timeout = 0.5
    primary_host = "127.0.0.1:5000"


class CliRequest(Message):
    def __init__(self, operation, data, iteration, time_stamp, uuid, comm=None):
        """

        :param operation: 来自Primary的操作请求代码
        :param data: 需要操作的数据，和具体的operation相关
        :param time_stamp:
        :param uuid:
        :param comm:
        """
        super().__init__()
        self.type = MessageType.REQUEST
        if not (operation in MessageType.cli_operation_domain):
            logging.error("Operation undefined!")
            self.operation = None
        else:
            self.operation = operation
        self.data = data
        self.iteration = iteration
        self.time_stamp = time_stamp
        self.uuid = uuid
        self.comm = comm


class ConsensusPrePrepare(PeerMessage):
    def __init__(self, operation, operation_data, involved_request_hashes, prev_block_hash, matter_hash, view, sequence,
                 time_stamp, uuid, relay_time_stamp):
        super().__init__(operation, operation_data, involved_request_hashes, prev_block_hash, matter_hash, view, sequence,
                         time_stamp, uuid, relay_time_stamp)
        self.type = MessageType.PRE_PREPARE


class ConsensusPrepare(PeerMessage):
    def __init__(self, operation, operation_data, involved_request_hashes, prev_block_hash, matter_hash, view, sequence,
                 time_stamp, uuid, relay_time_stamp):
        super().__init__(operation, operation_data, involved_request_hashes, prev_block_hash, matter_hash, view, sequence,
                         time_stamp, uuid, relay_time_stamp)
        self.type = MessageType.PREPARE


class ConsensusCommit(PeerMessage):
    def __init__(self, operation, operation_data, involved_request_hashes, prev_block_hash,
                 matter_hash, view, sequence, time_stamp, uuid, relay_time_stamp):
        super().__init__(operation, operation_data, involved_request_hashes, prev_block_hash, matter_hash, view, sequence,
                         time_stamp, uuid, relay_time_stamp)
        self.type = MessageType.COMMIT


class ConsensusMatter:
    f = 1

    def __init__(self, matter):
        self.matter = matter
        self.prepared = False
        self.committed = False

    def toJson(self):
        return json.dumps(self, default=lambda o: o.__dict__)
