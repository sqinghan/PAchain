import asyncio
import time
# from collections import Counter

import PBFT
from agent import *
# import logging
# from configparser import ConfigParser
from agent.config import configuration
import click
# from envparse import env
import logging
# from configparser import ConfigParser
# import hashlib

# from DES import DefaultSubproblem_VT, DefaultSubproblem_PQ_2, DefaultSubproblem_PQ_3, DefaultSubproblem_PQ_4
from agent.utils.broadcastutils import broadcast_callback
import json
import configparser
# import httpx
# import asyncio
# import ssl
# import requests
# logging.basicConfig(level=logging.DEBUG)

parser = configparser.ConfigParser()
path = 'personal_settings.ini'
parser.read(path)

configuration.NAME = parser['personal_info']['name']
configuration.ID = parser['personal_info']['uuid']
configuration.CERT = parser['key_info']['cert']
configuration.KEY = parser['key_info']['key']
configuration.CERT_PATH = parser['key_info']['cert_path']
configuration.CA_FILE = parser['key_info']['cert_path'] + '/ca.crt'
configuration.HOST = parser['personal_info']['ip']
configuration.PORT = eval(parser['personal_info']['port'])
configuration.MINER_NAME_LIST = eval(parser['peer_info']['miner_name_list'])
configuration.MINER_HOST_LIST = eval(parser['peer_info']['miner_host_list'])
configuration.MINER_ID_LIST = eval(parser['peer_info']['miner_id_list'])
configuration.WORKER_NAME_LIST = eval(parser['peer_info']['worker_name_list'])
configuration.WORKER_HOST_LIST = eval(parser['peer_info']['worker_host_list'])
configuration.WORKER_ID_LIST = eval(parser['peer_info']['worker_id_list'])
configuration.NEIGHBOUR_NAME_LIST = eval(parser['peer_info']['neighbour_name_list'])
configuration.NEIGHBOUR_ID_LIST = eval(parser['peer_info']['neighbour_id_list'])
# configuration.PEER_CERT_LIST = [f'{configuration.CERT_PATH}/{each_name}.crt'
#                                 for each_name in configuration.PEER_ID_LIST]


@click.command()
@click.option('-n', '--name', help='agent_name', default=configuration.NAME, show_default=True)
@click.option('-u', '--uuid', help='uuid', default=configuration.ID, show_default=True)
@click.option('-h', '--host', help='Bind host', default=configuration.HOST, show_default=True)
@click.option('-p', '--port', help='Bind port', default=configuration.PORT, type=int, show_default=True)
@click.option('-c', '--cert', help='certificate file', default=configuration.CERT)
@click.option('-k', '--key', help='key file', default=configuration.KEY)
def main(**kwargs):
    # --------------- 读取个人配置文件并实例化
    logging.debug(f"实例化{configuration.NAME}")
    myAgent = agent.Agent(conf=configuration)
    configuration.MY_HOST = f"{kwargs['host']}:{kwargs['port']}"
    formulation = json.loads(open('formulation.json').read())

    # default_subproblem = DefaultSubproblem_VT()
    # standard_formulation = default_subproblem.formulate_standard()
    myAgent.genesis_formulation = json.dumps({"H": formulation['H'],
                                              "G": formulation['G'],
                                              "h": formulation['h']}, sort_keys=True)
    import numpy as np
    myAgent.Cij_list = [np.array(_) for _ in formulation['Cij']]
    myAgent.Cji_list = [np.array(_) for _ in formulation['Cji']]
    myAgent.xi0_list = [np.array(_) for _ in formulation['xi0']]
    myAgent.xj0_list = [np.array(_) for _ in formulation['xj0']]
    myAgent.N = np.array(formulation['N'])
    myAgent.x = np.array(formulation['x'])
    myAgent.a0 = np.array(formulation['a'])
    myAgent.H_ori = np.array(formulation['H_ori'])
    myAgent.c_ori = np.array(formulation['c_ori'])
    myAgent.prox = np.array(formulation['prox'])
    myAgent.const = formulation['const']
    myAgent.T = formulation['T']
    myAgent.rho = np.array(formulation['rho']).reshape(3*myAgent.T)
    myAgent.rho = (myAgent.rho ** 2)
    myAgent.lij_list = [np.zeros(_.shape[0]) for _ in myAgent.Cij_list]
    myAgent.ly = len(formulation['H'])

    try:
        myAgent.event_loop = asyncio.get_event_loop()
    except Exception as e:
        myAgent.event_loop = asyncio.new_event_loop()
        asyncio.set_event_loop(myAgent.event_loop)
    # myAgent.z_pre = 0
    # for Cji in myAgent.Cji_list:
    #     myAgent.z_pre += Cji.T @ Cji
    # myAgent
    logging.info("%s 准备在向区块链节点注册自身信息" % myAgent.name)

    req = PBFT.CliRequest(operation=PBFT.MessageType.UPLOAD_GENESIS,
                          data=myAgent.genesis_formulation,
                          time_stamp=time.time(),
                          iteration=0,
                          uuid=myAgent.uuid,
                          comm=f"{myAgent.name}'s message of genesis formulation").toJson()
    signature = myAgent.sign(req)

    data_to_send = json.dumps({"uuid": configuration.ID,
                               "data": req,
                               "signature": signature,
                               "cli_type": "DES"})

    # 此处没有用executor 进行broadcast
    broadcast_callback(host_list=configuration.MINER_HOST_LIST,
                       msg=data_to_send,
                       url="/agent/request",
                       log="submit_genesis_information")

    print('finish sending')
    myAgent.run(host=kwargs['host'], port=kwargs['port'], ssl_context=(kwargs['cert'], kwargs['key']))


if __name__ == '__main__':
    main()
