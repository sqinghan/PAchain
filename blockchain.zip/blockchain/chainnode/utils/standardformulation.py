import json
import hashlib
import numpy as np
import cvxpy as cp


class StandardFormulation:
    def __init__(self, H, A, b, G, h):
        if isinstance(H, np.ndarray):
            self.H = H.tolist()
            self.A = A.tolist()
            self.b = b.tolist()
            self.G = None if G is None else G.tolist()
            self.h = None if h is None else h.tolist()
        else:
            self.H = H
            self.A = A
            self.b = b
            self.G = G
            self.h = h

    @classmethod
    def compute_hash(cls, formulation):
        formulation_string = json.dumps(formulation.__dict__, sort_keys=True)
        return hashlib.sha256(formulation_string.encode()).hexdigest()


class Model:
    def __init__(self, H, G, h, time_stamp=None):
        self.H = np.array(H)
        # self.A = np.array(A)
        # self.b = np.array(b)
        self.G = np.array(G) if G is not None else None
        self.h = np.array(h) if G is not None else None
        self.a = None
        self.y = None
        self.time_stamp = None
        # self.equ_cons = []
        self.ieq_cons = []
        self.problem = None
        self.solved = False

    def update_model(self, a):
        if self.a is None:
            self.a = cp.Parameter((self.H.shape[0]))
        if isinstance(a, list):
            self.a.value = np.array(a)
        elif isinstance(a, np.ndarray):
            self.a.value = a
        self.solved = False

    def formulate(self):
        self.y = cp.Variable(self.H.shape[0])
        self.solved = False
        if self.a is None:
            return False
        # self.equ_cons = [self.A @ self.y == self.b]
        if self.G is not None:
            self.ieq_cons = [self.G @ self.y <= self.h]

        self.problem = cp.Problem(cp.Minimize(1/2 * cp.quad_form(self.y, self.H) + self.a.T @ self.y),
                                  self.ieq_cons)
        return True

    def solve(self):
        # print(f"try_to_solve!!!")
        if self.problem is None:
            res = self.formulate()
            if res is False:
                return res
        if self.solved is False:
            self.problem.solve(solver=cp.GUROBI)
            self.solved = True
        if self.G is not None:
            if self.problem.status == "optimal" or self.problem.status == "optimal_inaccurate":
                return (self.problem.status,
                        self.problem.value,
                        self.y.value.tolist(),
                        # self.equ_cons[0].dual_value.tolist(),
                        self.ieq_cons[0].dual_value.tolist())
            else:
                return (None,
                        None)
        else:
            if self.problem.status == "optimal" or self.problem.status == "optimal_inaccurate":
                return (self.problem.status,
                        self.problem.value,
                        self.y.value.tolist(),
                        # self.equ_cons[0].dual_value.tolist(),
                        None)
            else:
                return (None,
                        None)

    def __str__(self):
        return str(self.problem.value)

    def verify_kkt(self, res):
        try:
            y = res[1]
            d1 = res[2]
            d2 = res[3]
            e1 = self.H @ y + self.a# + self.A @ d1
            e2 = 0
            if self.G is not None:
                e1 += self.G @ d2
                e2 = np.multiply(d2, self.G @ y - self.h)
            assert (abs(e1) < 1.e-3).all() and (abs(e2) < 1.e-3).all()
        except Exception as e:
            return False
        return True
