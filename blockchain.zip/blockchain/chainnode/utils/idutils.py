import uuid


def check_uuid(test_uuid, ver=4):
    try:
        return uuid.UUID(test_uuid).version == ver
    except ValueError:
        return False
