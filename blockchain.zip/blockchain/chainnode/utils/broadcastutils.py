import logging
import asyncio
import httpx
from chainnode.config import configuration
import ssl
from asyncio.proactor_events import _ProactorBasePipeTransport
from functools import wraps


async def broadcast(host_list=None, msg=None, url="/", log=None, including_self=False, protocol='https'):
    context = ssl.create_default_context(cafile=configuration.CA_FILE)
    # context = ssl.create_default_context()
    # L = [broadcast_each(index, host, msg, url, context, log, including_self) for index, host in enumerate(host_list)]
    L = await asyncio.gather(*[broadcast_each(host, msg, url, context, log, including_self, protocol)
                               for host in host_list])


async def broadcast_each(host=None, msg=None, url="/", context=None, log=None, including_self=False, protocol='https'):
    # from chainnode.data.global_variables import is_online
    # if is_online[host]:
    #     pass
    # else:
    #     return 0
    if host == configuration.MY_HOST and including_self is False:
        return 0
    async with httpx.AsyncClient(timeout=None, verify=context) as client:
        if log is not None:
            logging.info("broadcasting info:%s; host:%s" % (log, host))
        try:
            resp = await client.post(protocol + '://' + host + url, data=msg)
            # result = resp.text
            logging.info(f"broadcasting result:{str(resp)} from host {host} during {log} session")
        except httpx.ConnectError as e:
            logging.info(e)


def silence_event_loop_closed(func):
    @wraps(func)
    def wrapper(self, *args, **kwargs):

        try:

            return func(self, *args, **kwargs)

        except RuntimeError as e:

            if str(e) != 'Event loop is closed':
                raise

    return wrapper


def broadcast_callback(host_list=None, msg=None, url="/", log=None, including_self=False, protocol='https'):
    # print("尝试广播")
    # loop = asyncio.get_event_loop()
    # loop.run_until_complete(broadcast(
    #     host_list=host_list,
    #     msg=msg,
    #     url=url,
    #     log=log,
    #     including_self=including_self,
    #     protocol=protocol))
    # _ProactorBasePipeTransport.__del__ = silence_event_loop_closed(_ProactorBasePipeTransport.__del__)
    asyncio.run(broadcast(
        host_list=host_list,
        msg=msg,
        url=url,
        log=log,
        including_self=including_self,
        protocol=protocol))

