import hashlib
import json
import base64
import json
import PBFT
from chainnode.config import configuration
import OpenSSL


def hashmd5(st):
    """
    返回str型的md5 hash,输入可以为byte或str
    :param st:
    :return:
    """
    if isinstance(st, str):
        st = st.encode()
    md = hashlib.md5(st)
    return md.hexdigest()


def toMatter(data):
    matter = {
        'operation': data['operation'],
        'operation_data': data['operation_data'],
        'involved_request_hashes': data['involved_request_hashes'],
        'prev_block_hash': data['prev_block_hash'],
        'time_stamp': data['time_stamp']
    }
    return matter, hashmd5(json.dumps(matter))


def sign(data, key_path, hash_func="sha1"):
    key = open(key_path, "r").read()
    sk = OpenSSL.crypto.load_privatekey(OpenSSL.crypto.FILETYPE_PEM, key)
    sig = base64.b64encode(OpenSSL.crypto.sign(sk, data, hash_func)).decode()
    return sig


def verify_signature(data, cert_path, signature, method='sha1'):
    cert_body = open(cert_path, "r").read()
    cert = OpenSSL.crypto.load_certificate(OpenSSL.crypto.FILETYPE_PEM, cert_body)
    try:
        OpenSSL.crypto.verify(cert, base64.b64decode(signature.encode()), data, method)
        return True
    except:
        return False


def check_matter_validity(matter):
    try:
        operation = matter['operation']
        prev_block_hash = matter['prev_block_hash']
        if operation == PBFT.MessageType.UPLOAD_GENESIS:
            assert (prev_block_hash == '')
    except Exception as e:
        return dict(status='failed')
    return dict(status='success')


def check_request_validity(data):
    body = data['data']
    operation = data['operation']
    iteration = data['iteration']
    if operation == PBFT.MessageType.UPLOAD_GENESIS:
        if iteration != 0:
            return dict(status='failed')
    return dict(status='success')


def check_cli_type(request_info):
    """
    初步判断用户上传的request info是否符合格式要求，即是否的确是从某个登记过的分布式用户传过来的。
    0. request_info(dict)必须有uuid, data, signature三个entry, 其中uuid必须是登记过的用户，signature必须符合条件
    1. request_info["data"]必须有uuid， timestamp, data, operation 四个entry， 其中uuid必须和上层的uuid一致，operation必须在可用用户操作operation内选择
    本check函数并不check data和operation是否满足格式要求，也不check相应的request是否已经处理过。

    :param request_info: 用户的request信息（in dict format）
    :return:
    """
    if "type" in request_info.keys() and request_info['type'] == 'solution':
        required_info = ["uuid", "data"]
        if not all(each in request_info for each in required_info):
            return {
                "status": "failed",
                "msg": "Wrong data format!"
            }
        else:
            return {
                "status": "success"
            }

    required_info = ["uuid", "data", "signature", "cli_type"]
    if not all(each in request_info for each in required_info):
        return {
            "status": "failed",
            "msg": "Wrong data format!"
        }

    uuid = request_info["uuid"]
    signature = request_info["signature"]
    data = request_info["data"]
    cli_type = request_info['cli_type']

    cert = None
    try:
        if cli_type == 'DES':
            index: int = configuration.DES_ID_LIST.index(uuid)
            cert = f"{configuration.CERT_PATH}/{configuration.DES_NAME_LIST[index]}.crt"
        elif cli_type == 'MINER':
            index: int = configuration.MINER_ID_LIST.index(uuid)
            cert = f"{configuration.CERT_PATH}/{configuration.MINER_NAME_LIST[index]}.crt"
    except ValueError:
        return {
            "status": "failed",
            "msg": "Agent does not exist!"
        }

    # print(f"cli_type = {cli_type}")
    if verify_signature(data, cert, signature) is False:
        return {
            "status": "failed",
            "msg": "Signature does not match!"
        }
    data = json.loads(request_info["data"])
    required_info = ["type", "uuid", "time_stamp", "data", "operation", "comm", 'iteration']
    if not all(each in data for each in required_info):
        return {
            "status": "failed",
            "msg": "Wrong data format!"
        }
    if data["uuid"] != uuid or (not data["operation"] in PBFT.MessageType.cli_operation_domain) or \
            data['type'] != PBFT.MessageType.REQUEST:
        return {
            "status": "failed",
            "msg": "Conflict data in \'data\' index!"
        }
    if not ((cli_type == 'DES') ^ (data['operation'] == PBFT.MessageType.SOLVING_RESULT)):
        return{
            "status": "failed",
            "msg": "Access denied"
        }
    return check_request_validity(data)


def check_peer(request_info, message_type):
    """
    peer消息格式审查
    :param request_info:
    :param message_type:
    :return:
    """
    # 检查消息完整性，签名者、消息体、签名
    required_info = ["uuid", "data", "signature"]
    if not all(each in request_info for each in required_info):
        return {
            "status": "failed",
            "msg": "Wrong data format!"
        }
    uuid = request_info["uuid"]
    signature = request_info["signature"]
    data = request_info["data"]
    # 验证签名
    try:
        index: int = configuration.MINER_ID_LIST.index(uuid)
    except ValueError:
        return {
            "status": "failed",
            "msg": "Agent does not exist!"
        }
    if verify_signature(data, f"{configuration.CERT_PATH}/{configuration.MINER_NAME_LIST[index]}.crt", signature) is False:
        return {
            "status": "failed",
            "msg": "Signature does not match!"
        }

    # 检查消息体是否包含必要entry. 消息类型，消息来源，时间戳(初始)，视图，序列号，事务的hash，消息中继者时间戳，事务细节。
    data = json.loads(request_info["data"])
    required_info = ["type", "uuid", "time_stamp", "view", "sequence", "matter_hash", "relay_time_stamp",
                     "operation", "operation_data", "involved_request_hashes", "prev_block_hash"]
    if not all(each in data for each in required_info):
        return {
            "status": "failed",
            "msg": "Wrong data format!"
        }

    # 签名者需和消息体中的主体uuid一致， 需和调用接口提供的消息类型一致，需和当前视图号一致
    if data["uuid"] != uuid or (data["type"] != message_type) or data['view'] != PBFT.ConsensusStatus.view:
        return {
            "status": "failed",
            "msg": "Conflict data in \'data\' index! Wrong message sender id or type or view number"
        }

    # 如果是pre-prepare, 则只接受来自主节点的消息, 而且需要验证操作的validity, 验证过后在prepare和commit中无需再验证了。
    if (message_type == PBFT.MessageType.PRE_PREPARE
            and uuid == configuration.MINER_ID_LIST[PBFT.ConsensusStatus.view % PBFT.ConsensusStatus.n]):
        matter, matter_hash = toMatter(data)
        if matter_hash != data["matter_hash"]:
            return {
                "status": "failed",
                "msg": "Matter hash does not match!"
            }
        return check_matter_validity(matter)
    elif message_type == PBFT.MessageType.PREPARE:
        if uuid == configuration.MINER_ID_LIST[PBFT.ConsensusStatus.view % PBFT.ConsensusStatus.n]:
            return dict(status='failed', msg='prepare from primary is not accepted')
    elif message_type == PBFT.MessageType.COMMIT:
        pass
    else:
        return {
            "status": "failed",
            "msg": "Peer message check failed! Wrong message type or Pre-Prepare is not sent by primary"
        }

    return {
        'status':'success'
    }
