import hashlib
import time
import json
import pickle
import os
from chainnode.utils import StandardFormulation
from chainnode.data import database

class BlockBase:
    def __init__(self):
        pass

    @classmethod
    def compute_hash(cls, block):
        block_string = json.dumps(block.__dict__, sort_keys=True, cls=BlockEncoder)
        return hashlib.sha256(block_string.encode()).hexdigest()

class Block(BlockBase):
    def __init__(self, height=0, previous_hash=0):
        super(Block, self).__init__()
        self.previous_hash = previous_hash
        self.height = height
        self.formulations = dict()
        self.allocation = dict()
        self.solutions = dict()

class GenesisBLock(BlockBase):
    def __init__(self):
        super(GenesisBLock, self).__init__()
        self.previous_hash = ''
        self.height = 0
        self.formulations = dict()
        self.allocation = dict()

    def add_problem_data(self, uuid, formulation):
        # self.uuids.append(uuid)
        status = 1
        if uuid in self.formulations.keys():
            status = 2
        self.formulations[uuid] = formulation
        # self.hashes[uuid] = StandardFormulation.compute_hash(formulation)
        return status


class BlockEncoder(json.JSONEncoder):
    def default(self, o):
        return o.__dict__

class Blockchain:
    def __init__(self):
        # 0818前版本
        # self.genesis_block = GenesisBLock()
        # self.genesis_hash = BlockBase.compute_hash(self.genesis_block)
        # self.last_block = self.genesis_block
        # self.block_to_be_added = Block(height=1, previous_hash=self.genesis_hash)
        # self.height = 0

        # 0818早十点修改
        self.genesis_block = None
        self.genesis_hash = None
        self.last_block = None
        self.block_to_be_added = GenesisBLock()
        self.height = 0



    def dump_block(self, appClass, BLOCK_DATA_PATH=None):
        """
        将blockchain的block_to_be_added存入磁盘和区块链数据库做持久化
        :return:
        """
        if self.height == 0:  # 当前dump的是genesis block
            self.genesis_block = self.block_to_be_added
            self.genesis_hash = BlockBase.compute_hash(self.genesis_block)

        self.height += 1

        with appClass.app.app_context():
            appClass.db.session().add(database.Block_item(height=self.block_to_be_added.height,
                                                          block=self.block_to_be_added,
                                                          blockhash=BlockBase.compute_hash(self.block_to_be_added)))
            appClass.db.session().commit()

        if not BLOCK_DATA_PATH is None:
            pass
            # if not os.path.exists(BLOCK_DATA_PATH):
            #     os.makedirs(BLOCK_DATA_PATH)
            # with open(BLOCK_DATA_PATH + "/block_"+str(self.block_to_be_added.height), "wb") as file:
            #     pickle.dump(self.block_to_be_added, file)

        self.last_block = self.block_to_be_added
        self.block_to_be_added = Block(height=self.height,
                                       previous_hash=BlockBase.compute_hash(self.last_block))

    def add_problem_data(self, uuid, formulation):
        if self.genesis_block is None and self.genesis_hash is None and self.last_block is None:
            return self.block_to_be_added.add_problem_data(uuid, formulation)
        else:
            return 0

