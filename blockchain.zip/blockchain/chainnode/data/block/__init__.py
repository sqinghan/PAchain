from .block import BlockBase, Block, GenesisBLock, Blockchain

blockchain = Blockchain()
