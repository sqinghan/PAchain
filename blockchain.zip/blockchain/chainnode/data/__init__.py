"""
数据结构包:
子包 database中定义了数据库db和各表的接口，包括agents, blockhashes, peers
子包 block 中定义了区块链相关接口，包括持久化等功能。
"""
