from chainnode.data.database import db
import hashlib
import json


class Agent_item(db.Model):
    __tablename__ = "agents"
    uuid = db.Column(db.String(64), primary_key=True, unique=True, index=True)
    name = db.Column(db.String(64))
    pubkey = db.Column(db.Text)
    genesis_prepared = db.Column(db.Boolean)

    def __init__(self, name, uuid, pubkey):
        self.name = name
        self.uuid = uuid
        self.pubkey = pubkey
        self.genesis_prepared = 0

    def __repr__(self):
        # return "DES agent:%s (id=%s), pubkey_hash:%s" % (self.name,self.uuid, hashlib.sha256(self.pubkey.encode()).hexdigest())
        return json.dumps({
            "type": "AGENT",
            "name": self.name,
            "uuid": self.uuid,
            "pk_hash": hashlib.sha256(self.pubkey.encode()).hexdigest()
        })


class AgentRequest_item(db.Model):
    __tablename__ = "agent_requests"
    count = db.Column(db.Integer, primary_key=True)
    uuid = db.Column(db.String(64), index=True)
    operation = db.Column(db.Integer, index=True)
    iteration = db.Column(db.Integer, index=True)
    time_stamp = db.Column(db.DateTime)
    master_copy = db.Column(db.PickleType)
    comm = db.Column(db.Text)
    request_hash = db.Column(db.String(64), index=True, unique=True)
    valid = db.Column(db.String(8), index=True)
    onchain = db.Column(db.Boolean, index=True)
    access = db.Column(db.String(8), index=True)
    pending = db.Column(db.String(8), index=True)
    handled = db.Column(db.Boolean, index=True)
    data = db.Column(db.PickleType)
    result = db.Column(db.PickleType)
    result_time_stamp = db.Column(db.DateTime)
    result_request_hash = db.Column(db.String(64))
    # corresponding_matter_id = db.Column(db.Integer, db.ForeignKey('consensus_matter.sequence'))

    def __init__(self, uuid, operation, iteration, time_stamp, master_copy, comm, request_hash, valid, pending, access,
                 result=(None, None), data=None):
        self.uuid = uuid
        self.operation = operation
        self.iteration = iteration
        self.time_stamp = time_stamp
        self.master_copy = master_copy
        self.comm = comm
        self.request_hash = request_hash
        self.result_request_hash = ""
        self.onchain = False
        self.result = result
        self.valid = valid
        self.access = access
        self.pending = pending
        self.data = data
        self.handled = False

    def __repr__(self):
        return json.dumps({
            "本地消息号": self.count,
            "uuid(消息请求者id)": self.uuid,
            "operation(请求操作)": self.operation,
            "iteration": self.iteration,
            "comm": self.comm,
            "time_stamp(请求时间)": str(self.time_stamp),
            "hash(请求hash)": self.request_hash,
            "本地处理状态": str(self.result[0]),
            "本地处理结果": str(self.result[1]),
            "第三方处理结果的Request_hash": self.result_request_hash,
            "已进入上链程序": self.onchain,
            "合法性(valid)":self.valid,
            "权限(access)":self.access,
            "挂起(pending)":self.pending
        })
