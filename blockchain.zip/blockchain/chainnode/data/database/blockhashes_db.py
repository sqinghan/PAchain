import pickle

from chainnode.data.database import db
import json

class Blockhash_item(db.Model):
    __tablename__ = "blockhash"
    height = db.Column(db.Integer, primary_key=True)
    # height = db.Column(db.Integer)
    blockhash = db.Column(db.String(64))

    def __init__(self, height, blockhash):
        self.height = height
        self.blockhash = blockhash

    def __repr__(self):
        return "Block: (height=%s, height=%s)" % (str(self.height),self.blockhash)


class Block_item(db.Model):
    __tablename__ = "block"
    id = db.Column(db.Integer, primary_key=True)  # 区块高度
    sequence = db.Column(db.Integer, index=True, unique=True)  # 区块高度
    height = db.Column(db.Integer, unique=True, index=True)  # 区块高度
    block = db.Column(db.PickleType)  # 区块体
    block_type = db.Column(db.String(64))  # 区块类型，初始化区块或迭代区块
    prev_hash = db.Column(db.String(64), index=True, unique=True)  # 前一区块hash
    block_hash = db.Column(db.String(64), index=True, unique=True)  # 区块hash
    matter = db.relationship('ConsensusMatter_item', backref='block')
    # matter_hash = db.Column(db.String(64),)

    def __init__(self, height, block, block_type, prev_hash, block_hash, matter):
        self.height = height
        self.sequence = height
        self.block = block
        self.block_type = block_type
        self.prev_hash = prev_hash
        self.block_hash = block_hash
        self.matter.append(matter)

    def __repr__(self):
        return json.dumps({
            "height": self.height,
            "block_type": self.block_type,
            "previous_hash": self.prev_hash,
            "matter_hash": self.matter[0].sequence,
            "block_hash": self.block_hash
        })