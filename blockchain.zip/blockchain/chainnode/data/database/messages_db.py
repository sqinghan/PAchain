import PBFT
from chainnode.data.database import db
import json
import hashlib


class ConsensusMatter_item(db.Model):
    """
    ConsensusMatters Item 数据库模型类
    以 （消息视图，前置hash）为主键，剩下的必须保持一致
    本数据库记录了链节点针对某一事务的状态，当接收到来自主节点的preprepare消息时，将在数据库中建立一个条目
    """

    __tablename__ = "consensus_matter"

    view = db.Column(db.Integer, index=True, primary_key=True)
    sequence = db.Column(db.Integer, index=True)
    matter = db.Column(db.PickleType)
    matter_hash = db.Column(db.String(64), index=True)
    do_prepare_executed = db.Column(db.Boolean)
    prepares_collected = db.Column(db.Integer)
    is_prepared = db.Column(db.Boolean)

    do_commit_executed = db.Column(db.Boolean)
    commits_collected = db.Column(db.Integer)
    is_committed = db.Column(db.Boolean)
    prev_block_hash = db.Column(db.String(64), index=True, primary_key=True)
    prev_block_committed = db.Column(db.Boolean)
    block_hash = db.Column(db.String(64), db.ForeignKey('block.block_hash'))
    # involved_requests = db.relationship('AgentRequest_item', backref='matter_involved_in')
    # involved_messages = db.relationship('Message_item', backref='matter_involved_in')
    executed = db.Column(db.Boolean)

    # block = db.relationship('Block_item', use_list=False, back_ref ='consensus_matters')

    def __init__(self, view, sequence, matter, matter_hash, prev_block_hash, prev_block_committed):#, involved_requests):
        self.view = view
        self.sequence = sequence
        self.matter = matter
        self.matter_hash = matter_hash
        self.is_prepared = False
        self.is_committed = False
        self.prepares_collected = 0
        self.commits_collected = 0
        self.do_prepare_executed = False
        self.do_commit_executed = False
        self.prev_block_hash = prev_block_hash
        self.prev_block_committed = prev_block_committed
        self.executed = False
        # for each in involved_requests:
        #     self.involved_requests.append(each)

    def __repr__(self):
        return json.dumps({
            "view": self.view,
            "sequence": self.sequence,
            "matter_type": self.matter['operation'],
            "matter_hash": self.matter_hash,
            "prepares": self.prepares_collected,
            "is_prepared": self.is_prepared,
            "commits": self.commits_collected,
            "is_committed": self.is_committed,
            "prev_block_hash": self.prev_block_hash,
            "prev_block_committed": self.prev_block_committed
        })


class Message_item(db.Model):
    """
    Message Item 数据库模型类
    以 （消息源，消息类型，消息视图，前值hash（消息序列号））为主键，剩下的column必须保证一致性。
    本数据库记录了链节点接收到的所有消息。
    """
    __tablename__ = "message"
    source = db.Column(db.String(64), primary_key=True)
    time_stamp = db.Column(db.DateTime)
    type = db.Column(db.Integer, primary_key=True)
    message_text = db.Column(db.Text)

    view = db.Column(db.Integer, primary_key=True)
    sequence = db.Column(db.Integer)
    prev_block_hash = db.Column(db.String(64), primary_key=True)
    corresponding_matter_hash = db.Column(db.String(64))
    # corresponding_matter_id = db.Column(db.Integer, db.ForeignKey('consensus_matter.sequence'))
    handled = db.Column(db.Boolean)

    def __init__(self, source, time_stamp, typ, message_text, corresponding_matter_hash,
                 view, sequence, prev_block_hash):
        self.source = source
        self.time_stamp = time_stamp
        self.type = typ
        self.message_text = message_text
        self.view = view
        self.sequence = sequence
        self.prev_block_hash = prev_block_hash
        self.corresponding_matter_hash = corresponding_matter_hash
        self.handled = False

    def __repr__(self):
        return json.dumps(
            dict(source=self.source, time_stamp=str(self.time_stamp), type=self.type, message_text=self.message_text,
                 corresponding_matter_hash=self.matter_hash))

