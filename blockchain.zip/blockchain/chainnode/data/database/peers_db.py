import PBFT
from chainnode.data.database import db
from chainnode.config import configuration
import json
import hashlib


class Peer_item(db.Model):
    __tablename__ = "peers"
    uuid = db.Column(db.String(64), primary_key=True, unique=True, index=True)
    name = db.Column(db.String(64))
    pubkey = db.Column(db.Text)

    def __init__(self, name, uuid, pubkey):
        self.name = name
        self.uuid = uuid
        self.pubkey = pubkey

    def __repr__(self):
        return json.dumps({
            "type": "PEER",
            "name": self.name,
            "uuid": self.uuid,
            "pk_hash": hashlib.sha256(self.pubkey.encode()).hexdigest()
        })


