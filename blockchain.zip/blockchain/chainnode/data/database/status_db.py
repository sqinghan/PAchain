import PBFT
from chainnode.data.database import db
from chainnode.config import configuration
import json
import hashlib

class Database_status_item(db.Model):
    __tablename__ = "database_status"
    view = db.Column(db.Integer, index=True, primary_key=True)
    sequence = db.Column(db.Integer, index=True, primary_key=True)
    genesis_in_preparation = db.Column(db.Boolean, index=True, primary_key=True)
    genesis_prepared = db.Column(db.Boolean, index=True, primary_key=True)
    iteration_number = db.Column(db.Integer, index=True, primary_key=True)
    lock = db.Column(db.Boolean, index=True, primary_key=True)

    def __init__(self, view, sequence):
        self.view = view
        self.sequence = sequence
        self.genesis_in_preparation = False
        self.genesis_prepared = False
        self.iteration_number = 0
        self.lock = False

    def __repr__(self):
        return json.dumps({
            "view":self.view,
            "sequence":self.sequence,
            "genesis_prepared":self.genesis_prepared,
            "iteration":self.iteration,
        })
