import threading
import flask_apscheduler
from concurrent.futures import ThreadPoolExecutor
from flask_executor import Executor
from collections import Counter
from flask_socketio import SocketIO

pbft_matter_lock = threading.Lock()
agent_request_lock = threading.Lock()
block_lock = threading.Lock()

peer_pre_prepare_lock = threading.Lock()
peer_prepare_lock = threading.Lock()
peer_commit_lock = threading.Lock()

consensus_matter_lock = threading.Lock()
status_lock = threading.Lock()

class Pool(dict):
    def __init__(self):
        super().__init__()

    def refresh_with(self, key, time_stamp, cls, data, force_update=False):
        if key in self.keys():
            if force_update is False:
                if self[key].time_stamp > time_stamp:
                    return False
        self[key] = cls(**data)
        return True


connections = []
DES_connections = []
is_online = dict()
scheduler = flask_apscheduler.APScheduler()
executor = Executor()  # ThreadPoolExecutor(8)
socketio = SocketIO()
problem_pool = Pool()


result_gossip_pool = dict()


agent_request_pool = [dict()]# 用来收集来自DES客户端的消息

peer_pre_prepare_pool = [dict()] # 用来收集来自DES客户端的消息
peer_prepare_pool = [dict()] # 用来收集来自DES客户端的消息
peer_commit_pool = [dict()] # 用来收集来自DES客户端的消息

packaged_request_pool = [list()]
up_to_date_request_dict = dict()
up_to_date_result_dict = dict()

consensus_matter_pool = [dict()]

matter_pool = dict()  # 用来记录主节点提出的详细操作
prepared = set()
committed = set()
executed = set()


workers_connected = []
miners_connected = []
DESs_connected = []
ws_clients = []
connection_id_map = dict()
id_connection_map = dict()
client_manager = None
event_loop = None
event_loop_lock = threading.Lock()

status_pool = [set()]
do_preprepare_executed = 0

tip_block = None
tip_block_hash = None
