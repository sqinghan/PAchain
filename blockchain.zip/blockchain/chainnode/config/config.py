import os
import datetime
import uuid


class BaseConfig:
    """
    配置基类，用于存放共用的配置
    """
    SECRET_KEY = os.environ.get('SECRET_KEY') or os.urandom(16)
    DEBUG = False
    TESTING = False
    HOST = '127.0.0.1'
    PORT = '3306'

    BLOCK_RECOVER = False
    BLOCK_DATA_PATH = "block_data/"+datetime.datetime.now().strftime("%Y-%m-%d")
    BLOCK_DATA_NAME = "blockchain_genesis"

    DATABASE = 'chainnode'
    USERNAME = 'root'
    PASSWD = '123456'
    DB_URI = "mysql+pymysql://{username}:{passwd}@{host}:{port}/{db}?charset=utf8".format(
        username=USERNAME, passwd=PASSWD, host=HOST, port=PORT, db=DATABASE)

    SQLALCHEMY_DATABASE_URI = DB_URI
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SQLALCHEMY_ECHO = False
    CUSTOM_EXECUTOR_TYPE = 'thread'
    CUSTOM_EXECUTOR_MAX_WORKERS = 8


class ProductionConfig(BaseConfig):
    """
    生产环境配置类，用于存放生产环境的配置
    """
    pass


class DevelopmentConfig(BaseConfig):
    """
    开发环境配置类，用于存放开发环境的配置
    """
    DEBUG = True


class TestingConfig(BaseConfig):
    """
    测试环境配置类，用于存放开发环境的配置
    """
    DEBUG = True
    TESTING = True

class Myconfig(BaseConfig):
    NAME = "chainnode"
    ID = uuid.uuid4()
    SECRET_KEY = os.environ.get('SECRET_KEY') or os.urandom(16)
    DEBUG = True
    TESTING = False
    HOST = '127.0.0.1'
    MY_HOST = '127.0.0.1:5000'
    PORT = 3306
    DATABASE = 'chainnode'
    USERNAME = 'chainnode'
    PASSWD = '123456'
    DB_URI = "mysql+pymysql://{username}:{passwd}@{host}:{port}/{db}?charset=utf8".format(
        username=USERNAME, passwd=PASSWD, host=HOST, port=PORT, db=DATABASE)
    BFT_F = 1

    PK=None
    SK=None

    SQLALCHEMY_DATABASE_URI = DB_URI
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SQLALCHEMY_ECHO = False

    CA_FILE = '../certs/ca-cert/ca.crt'
    CERT = None
    KEY = None

    # PEER_HOST_LIST = []
    # PEER_ID_LIST = []
    # PEER_CERT_LIST = []
    #
    # AGENT_HOST_LIST = []
    # AGENT_ID_LIST = []
    # AGENT_CERT_LIST = []


registered_modules = [
    'agent_module',
    'peer_module'
]

config_map = {
    'development': DevelopmentConfig,
    'production': ProductionConfig,
    'testing': TestingConfig
}
