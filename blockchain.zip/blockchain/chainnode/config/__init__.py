from .config import *
from .logger import config_logger


"""
Config 文件
存储配置
"""
configuration = Myconfig