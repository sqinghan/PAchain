import importlib
import logging

# import sqlalchemy
# from flask_apscheduler import APScheduler
# from flask_socketio import emit

import PBFT
# from .schedules.chainnode_tasks import ping_to_peer, check_genesis
from chainnode.data.database.status_db import Database_status_item

# from crypto.Cipher import PKCS1_v1_5 as Cipher_pkcs1_v1_5
from flask import Flask, redirect, request
import os
from chainnode import config
from chainnode.data import block, database, global_variables
from chainnode.modules.ws_action_module import *

# def query_all_blocks():
#     response = database.db.session.query(database.Block_item).all()
#     if len(response) == 0:
#         return {
#             "status": "success",
#             "msg": "There is no block!",
#             "data": None
#         }
#     return {
#             "status": "success",
#             "msg": "Query successfully!",
#             "data": str(response)
#         }

class Chainnode:
    app_name = "chainnode"
    app_instance = None

    def __init__(self, name=None, uuid=None, env='development', conf=None):
        """

        :param name: name
        :param uuid: uuid
        :param env: environment, default to development, we use env to generate config object.
        :param conf: config object
        """
        # Initiate some basic info
        self.name = name
        self.uuid = uuid
        # Initiate data structures and special modules
        self.blockchain = block.blockchain
        # self.db = database.db
        self.scheduler = global_variables.scheduler
        self.executor = global_variables.executor
        self.socketio = global_variables.socketio

        # Initate apps
        self.conf = self.get_config_object(env) if conf is None else conf
        global_variables.is_online = {each_host: False for each_host in self.conf.MINER_HOST_LIST}
        self.is_online = global_variables.is_online
        self.is_online[self.conf.MY_HOST] = True
        self.create_chainnode(conf=self.conf)



        # Recover some data
        if not os.path.exists(conf.BLOCK_DATA_PATH):
            os.makedirs(conf.BLOCK_DATA_PATH)

        # if conf.BLOCK_RECOVER is True:
        #     cursor = Database_status_item.query
        #     PBFT.ConsensusStatus.view = cursor.first()['view']
        #     PBFT.ConsensusStatus.sequence = cursor.first()['sequence']
        #     cursor.update({Database_status_item.genesis_in_preparation: False})
        #     cursor.update({Database_status_item.genesis_prepared: False})
        #     self.db.session.commit()
        # else:
        #     with self.app.app_context():
        #         self.db.drop_all()
        #         self.db.create_all()
        #         self.db.session.add(Database_status_item(0, 0))
        #         self.db.session.commit()

        # self.load_key()
        self.app_instance = self



    def register_logger(self):
        log_level = os.environ.get('LOG_LEVEL') or 'WARNING'
        log_file = os.environ.get('LOG_FILE') or 'chainnode.log'
        config.config_logger(
            enable_console_handler=True,
            enable_file_handler=True,
            log_level=log_level,
            log_file=log_file
        )

    def get_config_object(self, env=None):
        """
        Get the config object according to running environment.

        :param env: environment, env='production', 'development' or 'testing', default to 'development'
        :return: corresponding config class
        """
        if not env:
            env = os.environ.get('FLASK_ENV')
        else:
            os.environ['FLASK_ENV'] = env
        if env in config.config_map:
            return config.config_map[env]
        else:
            # set default env if not set
            env = 'development'
            return config.config_map[env]

    def register_modules(self):
        for each_module_string in config.registered_modules:
            module = importlib.import_module(self.app_name + ".modules." + each_module_string)
            if hasattr(module, 'register'):
                getattr(module, 'register')(self.app)

    def create_chainnode(self, conf=None):
        """

        :param conf: config object,
        :return:
        """
        # initialize logger
        self.register_logger()
        # check instance path
        instance_path = os.environ.get('INSTANCE_PATH') or None
        # create and configure the app
        self.app = Flask(__name__, instance_path=instance_path)
        if not conf:
            conf = self.get_config_object()
        self.app.config.from_object(conf)
        # ensure the instance folder exists
        if self.app.instance_path:
            try:
                os.makedirs(self.app.instance_path)
            except OSError:
                pass
        # register app
        self.register_modules()
        # self.db.init_app(self.app)
        self.prepare_scheduler()
        # self.scheduler.init_app(self.app)
        self.executor.init_app(self.app)
        self.socketio.init_app(self.app)
        # self.scheduler.start()

        # @self.app.before_request
        # def before_request():
        #     if request.url.startswith("http://"):
        #         url = request.url.replace("http://", "https://", 1)
        #         return redirect(url, code=301)

        @self.app.route("/", methods=["GET", "POST"])
        def index():
            # from chainnode.modules.agent_module import query_all_agents
            all_mining_peers = {id:{'is_primary': self.conf.MINER_HOST_LIST[i] == PBFT.ConsensusStatus.primary_host,
                             'host':self.conf.MINER_HOST_LIST[i],
                             'is_online':self.is_online[self.conf.MINER_HOST_LIST[i]]}
                         for i,id in enumerate(self.conf.MINER_ID_LIST) }
            # existing_blocks = query_all_blocks()["data"]

            try:
                latest_allocation = global_variables.tip_block.allocation
            except Exception:
                latest_allocation = None

            return {
                "msg" : "Welcome:{name=%s, uuid=%s}" % (self.name, self.uuid),
                "All_peers": all_mining_peers,
                # "existing_blocks": existing_blocks,
                "latest_allocation": latest_allocation,
                "当前视图":PBFT.ConsensusStatus.view,
                "当前序列号":PBFT.ConsensusStatus.sequence
                # "current_block_to_be_added": current_block_str
            }

        @self.app.route("/add_block", methods=["GET", "POST"])
        def add_block():
            self.blockchain.dump_block(appClass=self)
            return {
                "msg" : "succeess"
            }

        @self.app.route("/get_request", methods=["POST"])
        def get_request():
            import json
            from chainnode.data.database.agents_db import AgentRequest_item
            request_in_dict = json.loads(request.data.decode("utf-8"))
            # print(f"Someone is asking for {request_in_dict['hash']}...")
            ans = []
            for each_hash in request_in_dict['hash']:
                seq = PBFT.ConsensusStatus.sequence
                while seq >= 0:
                    if each_hash in global_variables.agent_request_pool[seq].keys():
                        ans.append(global_variables.agent_request_pool[seq][each_hash].master_copy)
                        break
                    else:
                        seq -= 1

            print(f"I have found {len(ans)} for him...")
            # request_item_1 = AgentRequest_item.query.filter(
            #     AgentRequest_item.request_hash.in_(request_in_dict['hash'])).filter_by(operation=PBFT.MessageType.SOLVING_REQUEST).all()
            #
            # request_item_2 = AgentRequest_item.query.filter(
            #     AgentRequest_item.request_hash.in_(request_in_dict['hash'])).filter_by(operation=PBFT.MessageType.SOLVING_RESULT).all()

            # request_item_1 = AgentRequest_item.query.filter_by(request_hash=request_in_dict['hash'],
            #                                                    operation=PBFT.MessageType.SOLVING_REQUEST).all()
            # request_item_2 = AgentRequest_item.query.filter_by(request_hash=request_in_dict['hash'],
            #                                                    operation=PBFT.MessageType.SOLVING_RESULT).all()
            return {
                "msg": ans  # [each.master_copy for each in request_item_1 + request_item_2]  # request_item.first().master_copy
            }

        return self.app

    def prepare_scheduler(self):
        pass
        # def hello():
        #     print('Helloworld!')
        # self.scheduler.add_job(func=hello,
        #                        id="hello",
        #                        trigger="interval",
        #                        seconds=1,
        #                        replace_existing=True)
        # self.scheduler.add_job(func=ping_to_peer,
        #                        args=[self.is_online],
        #                        id="ping_to_peer",
        #                        trigger="interval",
        #                        seconds=5,
        #                        replace_existing=True)
        # self.scheduler.add_job(func=check_genesis,
        #                        args=[self, self.db, global_variables.pbft_matter_lock, self.scheduler],
        #                        id="check_genesis",
        #                        trigger="interval",
        #                        seconds=2,
        #                        replace_existing=True)

    # @classmethod
    def recover_block(self):
        with self.app.app_context():
            pass
            # logging.debug("利用数据库恢复blockchain：")
            # import sqlalchemy.func.max
            # max_height = self.db.session.query(sqlalchemy.func.max(database.Block_item.height)).first()[0]
            # item = database.Block_item.query.get(max_height)
            # if item is not None:
            #     self.blockchain.height = item.height
            #     self.blockchain.last_block = item.block
            #
            # item = database.Block_item.query.get(0)
            # if item is not None:
            #     self.blockchain.genesis_block = item.block
            #     self.blockchain.genesis_hash = item.blockhash
            #
            # if self.blockchain.height != 0:
            #     self.blockchain.block_to_be_added = block.Block(height=self.blockchain.height,
            #                                                     previous_hash=block.BlockBase.compute_hash(self.blockchain.last_block))

    # @classmethod

    # def record_matrix_to_genesis(self, request):
    #     request_info = json.loads(request.data.decode("utf-8"))
    #     required_info = ["uuid", "signature", "Hp", "Ap", "bp", "Gp", "hp"]
    #
    #     if not all(each in request_info for each in required_info):
    #         return "Missing data!"
    #
    #     try:
    #         pk = self.blockchain.DES_pk["uuid"]
    #         rsa_pk = RSA.importKey(pk)
    #         data = [request_info["Hp"],request_info["Ap"],request_info["bp"],request_info["Gp"],request_info["hp"]]
    #         verifier = Signature_pkcs1_v1_5.new(rsa_pk)
    #         digest = hashlib.sha256(str(data).encode()).hexdigest()
    #         is_verify = verifier.verify(digest, base64.b64decode(request_info["signature"]))
    #     except Exception:
    #         logging.exception("记录矩阵至创世区块：失败")

    def run(self, host=None, port=None, ssl_context=None, threaded=True, debug=False, load_dotenv=True, **options):
        self.app.run(host, port, debug, load_dotenv, threaded=threaded, ssl_context=ssl_context)
        # self.app.run(kwargs)
