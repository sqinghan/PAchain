from flask import Blueprint

agent_blueprint = Blueprint('agent_blueprint', __name__, url_prefix='/agent')

from .agent import *