import pickle
# import threading
from datetime import datetime
import logging

# import cvxpy

from chainnode.modules.agent_module import agent_blueprint
from chainnode.config import configuration
# from chainnode.data.block import blockchain, BlockBase
from chainnode.data.database import db
from chainnode.data.global_variables import executor, \
    agent_request_lock, problem_pool, block_lock, pbft_matter_lock, \
    result_gossip_pool

from chainnode.modules.ws_action_module.ws_clients import ws_broadcast
from chainnode.data.database.agents_db import AgentRequest_item, Agent_item
from chainnode.data.database.messages_db import Message_item, ConsensusMatter_item
# from chainnode.data.database.blockhashes_db import Block_item
# from chainnode.utils.broadcastutils import broadcast_callback
from chainnode.utils.common import verify_signature, sign, check_peer, check_cli_type, hashmd5
from chainnode.utils import check_uuid, toMatter
# from chainnode.utils.standardformulation import Model
from chainnode.data import global_variables
# from chainnode.utils import broadcast

import numpy as np
import random
import json
from flask import request
import asyncio
import time
import PBFT

from Crypto.Hash import SHA, SHA256


# @agent_blueprint.route("/query_requests", methods=['GET'])
# def query_requests():
#     res1 = db.session.query(AgentRequest_item).filter_by(iteration=PBFT.ConsensusStatus.sequence).all()
#     res2 = db.session.query(AgentRequest_item).filter_by(iteration=PBFT.ConsensusStatus.sequence - 1).all()
#     # res = ConsensusMatter_item.query.all()
#     if len(res1 + res2) == 0:
#         return {}
#     else:
#         d = {}
#         for each in res1 + res2:
#             res_load = json.loads(str(each))
#             d[res_load['本地消息号']] = res_load
#         return d


@agent_blueprint.route("/upload_formulation_pre_prepare", methods=["POST"])
def formulation_pre_prepare():
    pass


# @agent_blueprint.route("/query_all_agents", methods=['GET'])
# def query_all_agents():
#     response = Agent_item.query.all()
#     if len(response) == 0:
#         return {
#             "status": "success",
#             "msg": "There is no registered agent!",
#             "data": None
#         }
#     return {
#         "status": "success",
#         "msg": "Query successfully!",
#         "data": str(response)
#     }


def register(app):
    app.register_blueprint(agent_blueprint)


@agent_blueprint.route("/request", methods=["post"])
def redirect_request(msg=None):
    # 将用户提交的request提交至具体的执行函数（异步）
    # 数据格式检验--------------------------
    request_info = msg or request.data.decode("utf-8")
    request_in_dict = json.loads(request_info)
    # request_in_dict = json.loads(request.data.decode("utf-8"))
    check_format = check_cli_type(request_in_dict)

    if check_format["status"] == "failed":
        return check_format

    data = json.loads(request_in_dict['data'])

    executor.submit(handle_agent_requests,
                    operation_type=data['operation'],  # 操作类型
                    master_copy=request_info,  # 用户原文 in str
                    data=data)  # 去除原文中的uuid和签名后的数据实体(in json)
    # handle_agent_requests(data['operation'], request.data.decode(), data)

    return {
        "status": "success",
        "msg": "用户请求通过签名验证，以启动处理线程，请访问其他路由查看请求处理结果"
    }


def allocate_task(candi_tasks, candi_workers, repeat=PBFT.ConsensusStatus.f + 1, seed=0):
    np.random.seed(seed)
    tasks = candi_tasks * 1
    workers = candi_workers.copy()
    # print(workers)
    repeat = 1
    random.shuffle(tasks)
    # random.shuffle(workers)
    lt = len(tasks)
    lw = len(workers)
    # 设定分配比例
    rat = [1 / lw for num in range(lw)]
    # 设定分配任务数
    spl = np.round(np.array(rat).cumsum() * lt)
    # 设定分配
    allo = np.split(tasks, spl.astype(int).tolist()[:-1])
    d = {worker: [] for worker in workers}

    for j, worker in enumerate(workers):
        for task in allo[j]:
            d[worker].append(task)

    # for j, task in enumerate(tasks):
    #     allocated_solver = random.sample(workers, min(len(workers), repeat))
    #     for _ in allocated_solver:
    #         d[_].append(task)
    return d


# @agent_blueprint.route("/create_ws_connections", methods=["post"])
# def create_ws_connections():
#     loop = asyncio.new_event_loop()
#     asyncio.set_event_loop(loop)
#     from chainnode.modules.ws_action_module.ws_clients import FlaskSioClient
#     global_variables.connections = [FlaskSioClient() for _ in configuration.MINER_HOST_LIST]
#     from chainnode.modules.ws_action_module.ws_clients import async_connect
#     loop.run_until_complete(async_connect(clients=global_variables.connections,
#                                           ips=configuration.MINER_HOST_LIST))
#     asyncio.run(async_connect(clients=global_variables.connections,
#                               ips=configuration.MINER_HOST_LIST))
#     return {'status': 'success!'}


@agent_blueprint.route("/doPrePrepareGenesis", methods=["post"])
def doPrePrepareGenesis():
    print(f"迭代{PBFT.ConsensusStatus.sequence}, 确认执行do preprepare")
    # broadcast_callback(host_list=configuration.MINER_HOST_LIST,
    #                    msg=None,
    #                    url="/agent/create_ws_connections",
    #                    log="create_ws_connections",
    #                    including_self=True)
    # executor.submit(broadcast_callback,
    #                 host_list=configuration.MINER_HOST_LIST,
    #                 msg=None,
    #                 url="/agent/create_ws_connections",
    #                 log="create_ws_connections",
    #                 including_self=True)
    # create_ws_connections()
    # 生成pre-pre message并分配view和sequence
    # agent_request_lock.acquire()
    print("接收到开始迭代信息")
    # genesis_info = AgentRequest_item.query.filter_by(operation=PBFT.MessageType.UPLOAD_GENESIS,
    #                                                  valid="True").all()
    # involved_request_hashes = [item.request_hash for item in genesis_info]

    involved_request_hashes = []
    for each_key in global_variables.agent_request_pool[0].keys():
        msg = global_variables.agent_request_pool[0][each_key]
        if msg.operation == PBFT.MessageType.UPLOAD_GENESIS and msg.valid == 'True':
            involved_request_hashes += [each_key]
        global_variables.packaged_request_pool[0].append(msg)

    # for each in genesis_info:
    #     each.onchain = True
    # (self, operation, operation_data, involved_request_hashes, block_hash, view, sequence, time_stamp,
    #                  uuid):

    view = PBFT.ConsensusStatus.view
    sequence = PBFT.ConsensusStatus.sequence

    pre_prepare = PBFT.ConsensusPrePrepare(uuid=configuration.ID,
                                           operation=PBFT.MessageType.CONSENSUS_GENESIS,
                                           operation_data=allocate_task(configuration.DES_ID_LIST,
                                                                        global_variables.workers_connected),
                                           involved_request_hashes=involved_request_hashes,
                                           prev_block_hash='',
                                           matter_hash=None,
                                           view=PBFT.ConsensusStatus.view,
                                           sequence=PBFT.ConsensusStatus.sequence,
                                           time_stamp=time.time(),
                                           relay_time_stamp=time.time())

    # 对pre-pre 事务打包 签名
    matter, matter_hash = toMatter(json.loads(pre_prepare.toJson()))
    pre_prepare.matter_hash = matter_hash
    #
    # PBFT.ConsensusStatus.sequence += 1  # 注意此处并行的话需写进程锁
    #
    pre_prepare = pre_prepare.toJson()
    signature = sign(data=pre_prepare, key_path=configuration.KEY)
    data_to_send = json.dumps({"uuid": configuration.ID,
                               "data": pre_prepare,
                               "signature": signature})
    # 以上，所有的消息准备完成，接下来准备广播preprepare，首先是给自己广播
    message_item = Message_item(source=configuration.ID,
                                time_stamp=datetime.now(),
                                typ=PBFT.MessageType.PRE_PREPARE,
                                message_text=data_to_send,
                                view=view,
                                sequence=sequence,
                                corresponding_matter_hash=matter_hash,
                                prev_block_hash=""
                                )
    consensus_matter_item = ConsensusMatter_item(view, sequence, matter, matter_hash, "", True)
    global_variables.peer_pre_prepare_pool[sequence][configuration.ID] = message_item
    global_variables.consensus_matter_pool[sequence][configuration.ID] = consensus_matter_item
    # involved_requests=genesis_info)
    # db.session.add(message_item)
    # db.session.add(consensus_matter_item)
    # try:
    #     db.session.commit()
    # except Exception as e:
    #     db.session.rollback()
    # agent_request_lock.release()

    # executor.submit(broadcast_callback,
    #                 host_list=configuration.MINER_HOST_LIST,
    #                 msg=data_to_send,
    #                 url="/peer/handlePrePrepare",
    #                 log="pre-prepare")

    # ws_broadcast(configuration.MINER_HOST_LIST, 'preprepare', data_to_send)
    executor.submit(ws_broadcast,
                    ips=configuration.MINER_HOST_LIST,
                    event='preprepare',
                    msg=data_to_send)

    # 接下来是给其他peer广播
    # asyncio.run(broadcast(
    #     host_list=configuration.MINER_HOST_LIST,
    #     msg=data_to_send,
    #     url="/peer/handlePrePrepare",
    #     log="pre-prepare"))

    return {
        "status": "async success",
        "msg": "The primary server has started pBFT on the request"
    }


@agent_blueprint.route("/doPrePrepareNormal", methods=["post"])
def doPrePrepareNormal(timeout_execution=False, sequence=None):
    # print(f"迭代{PBFT.ConsensusStatus.sequence}, 尝试执行do preprepare")
    if sequence >= len(global_variables.status_pool) - 1:
        global_variables.status_pool += \
            [set() for _ in range(5 + sequence - len(global_variables.status_pool))]
    if PBFT.ConsensusStatus.sequence >= len(global_variables.packaged_request_pool) - 1:
        global_variables.packaged_request_pool += \
            [list() for _ in range(5 + sequence - len(global_variables.packaged_request_pool))]
    if sequence <= 500:
        pass
    else:
        return 0
        # 生成pre-pre message并分配view和sequence
    ll = len(configuration.DES_ID_LIST)
    if global_variables.do_preprepare_executed == sequence - 1:
        if timeout_execution or ((not timeout_execution) and len(global_variables.status_pool[sequence]) == ll):
            # print(json.dumps(dict(status="failed", msg=f"迭代{PBFT.ConsensusStatus.sequence}, "
            #                                  f"消息收集数{len(global_variables.status_pool[PBFT.ConsensusStatus.sequence])}"
            #                                  f"暂不计算")))
            global_variables.do_preprepare_executed = sequence
        else:
            return 0
        # global_variables.do_preprepare_executed = PBFT.ConsensusStatus.sequence
    else:
        return dict(status="failed", msg="已经执行过doprepreparenormal, 跳过")
    print(f"迭代{PBFT.ConsensusStatus.sequence}, 确认执行do preprepare")

    # request_info = AgentRequest_item.query. \
    #     filter(AgentRequest_item.operation == PBFT.MessageType.SOLVING_REQUEST,
    #            AgentRequest_item.iteration == PBFT.ConsensusStatus.sequence,
    #            AgentRequest_item.result_request_hash != "").with_for_update().all()
    # involved_hashes = [item.request_hash for item in request_info]
    # involved_hashes += [item.result_request_hash for item in request_info]

    if not timeout_execution:
        involved_hashes_1 = []
        for each_msgkey in global_variables.agent_request_pool[sequence].keys():
            if global_variables.agent_request_pool[sequence][each_msgkey].operation == PBFT.MessageType.SOLVING_REQUEST:
                involved_hashes_1 += [each_msgkey]
                global_variables.packaged_request_pool[sequence].\
                    append(global_variables.agent_request_pool[sequence][each_msgkey])

        involved_hashes_2 = []
        for each_msgkey in involved_hashes_1:
            involved_hashes_2 +=\
                [global_variables.agent_request_pool[sequence][each_msgkey].result_request_hash]
            global_variables.packaged_request_pool[sequence]. \
                append(global_variables.agent_request_pool[sequence][global_variables.
                       agent_request_pool[sequence][each_msgkey].result_request_hash])

        involved_hashes = involved_hashes_1 + involved_hashes_2
    else:
        # print(f"Timeout execution of iteration {sequence}, block_timeout = {PBFT.ConsensusStatus.block_timeout}")
        PBFT.ConsensusStatus.block_timeout += 0.1
        global_variables.packaged_request_pool[sequence] =\
            [global_variables.up_to_date_request_dict[_] for _ in configuration.DES_ID_LIST] + \
            [global_variables.up_to_date_result_dict[_] for _ in configuration.DES_ID_LIST]

        involved_hashes = [_.request_hash for _ in global_variables.packaged_request_pool[sequence]]
    # print(f'{len(involved_hashes)} involved hashes for iteration {PBFT.ConsensusStatus.sequence}')
    # for each in request_info:
    #     each.onchain = True
    # db.session.commit()
    # print(f"确认执行do preprepare, involved_hashes长度为{len(involved_hashes)}\n")
    # solution_info = AgentRequest_item.query. \
    #     filter(AgentRequest_item.request_hash.in_(involved_hashes)).with_for_update().all()
    # print(f"确认执行do preprepare, involved_hashes长度为{len(involved_hashes)}\n")
    # for each in solution_info:
    #     each.onchain = True
    # db.session.commit()
    # (self, operation, operation_data, involved_request_hashes, block_hash, view, sequence, time_stamp,
    #                  uuid):

    view = PBFT.ConsensusStatus.view
    # prev_block_hash = BlockBase.compute_hash(global_variables.tip_block)
    prev_block_hash = global_variables.tip_block_hash
    pre_prepare = PBFT.ConsensusPrePrepare(uuid=configuration.ID,
                                           operation=PBFT.MessageType.CONSENSUS_ITERATION,  # 将会被打包进matter
                                           operation_data=allocate_task(configuration.DES_ID_LIST,
                                                                        global_variables.workers_connected),  # 将会被打包进matter
                                           involved_request_hashes=involved_hashes,  # 将会被打包进matter
                                           prev_block_hash=prev_block_hash,  # 将会被打包进matter
                                           matter_hash=None,
                                           view=view,
                                           sequence=sequence,
                                           time_stamp=time.time(),  # 将会被打包进matter
                                           relay_time_stamp=time.time())

    # 对pre-pre 事务打包 签名
    matter, matter_hash = toMatter(json.loads(pre_prepare.toJson()))
    pre_prepare.matter_hash = matter_hash
    #
    # PBFT.ConsensusStatus.sequence += 1  # 注意此处并行的话需写进程锁
    #
    pre_prepare = pre_prepare.toJson()
    signature = sign(data=pre_prepare, key_path=configuration.KEY)
    data_to_send = json.dumps({"uuid": configuration.ID,
                               "data": pre_prepare,
                               "signature": signature})

    # 以上，所有的消息准备完成，接下来准备广播preprepare，首先是给自己广播
    message_item = Message_item(source=configuration.ID,
                                time_stamp=datetime.now(),
                                typ=PBFT.MessageType.PRE_PREPARE,
                                message_text=data_to_send,
                                view=view,
                                sequence=sequence,
                                corresponding_matter_hash=matter_hash,
                                prev_block_hash=prev_block_hash
                                )

    consensus_matter_item = ConsensusMatter_item(view, sequence, matter, matter_hash, prev_block_hash, True)
    # involved_requests=request_info + solution_info)
    # db.session.add(message_item)
    # db.session.add(consensus_matter_item)
    # try:
    #     db.session.commit()
    # except Exception as e:
    #     logging.error(e)
    #     db.session.rollback()

    from chainnode.modules.peer_module import extend_pool
    extend_pool(global_variables.peer_pre_prepare_pool, global_variables.peer_pre_prepare_lock, sequence)
    extend_pool(global_variables.consensus_matter_pool, global_variables.consensus_matter_lock, sequence)
    global_variables.peer_pre_prepare_pool[sequence][configuration.ID] = message_item
    global_variables.consensus_matter_pool[sequence][configuration.ID] = consensus_matter_item

    # print(f"迭代{PBFT.ConsensusStatus.sequence}, do preprepare执行成功\n")
    # executor.submit(broadcast_callback,
    #                 host_list=configuration.MINER_HOST_LIST,
    #                 msg=data_to_send,
    #                 url="/peer/handlePrePrepare",
    #                 log="pre-prepare")
    # ws_broadcast(configuration.MINER_HOST_LIST, 'preprepare', data_to_send)
    executor.submit(ws_broadcast,
                    ips=configuration.MINER_HOST_LIST,
                    event='preprepare',
                    msg=data_to_send)
    # 接下来是给其他peer广播
    # asyncio.run(broadcast(
    #     host_list=configuration.MINER_HOST_LIST,
    #     msg=data_to_send,
    #     url="/peer/handlePrePrepare",
    #     log="pre-prepare"))

    return {
        "status": "async success",
        "msg": "The primary server has started pBFT on the request"
    }


def do_collect_agent_request():
    pass


def analyze(master_copy):
    # print(f"尝试分析master_copy{master_copy}")
    request_in_dict = json.loads(master_copy)
    check_format = check_cli_type(request_in_dict)
    # print(f"尝试check_format")
    if check_format["status"] == "failed":
        print(f"check_format失败")
        return False
    data = json.loads(request_in_dict['data'])
    return handle_agent_requests(data['operation'], master_copy, data, force=True)


def extend_agent_request_pool(iteration):
    if iteration >= len(global_variables.agent_request_pool) - 1:
        global_variables.agent_request_pool += \
            [dict() for _ in range(5 + iteration - len(global_variables.agent_request_pool))]


def handle_agent_requests(operation_type, master_copy, data, force=None):
    # 将用户的request插入数据库，这里利用了uuid operation iteration组合主键保证唯一性
    agent_request_hash = hashmd5(master_copy)
    uuid = data['uuid']
    time_stamp = data['time_stamp']
    iteration = data['iteration']
    comm = data['comm']
    data_body = json.loads(data['data'])
    # print(f"来自客户端 {uuid}的消息，时间戳 {time_stamp},迭代数 {iteration}, 备注 {comm}")

    extend_agent_request_pool(iteration)
    if iteration >= len(global_variables.status_pool) - 1:
        global_variables.status_pool += \
            [set() for _ in range(5 + iteration - len(global_variables.status_pool))]

    # 验证消息类型，验证是否已经处理过，写入数据库----------------------------
    try:
        res = None
        # res = AgentRequest_item.query.filter(AgentRequest_item.request_hash == agent_request_hash).first()
        access = "False"
        pending = "True"
        valid = "True"
        # 尚未处理过该消息
        if res is None:
            if operation_type == PBFT.MessageType.SOLVING_REQUEST:
                # if iteration == PBFT.ConsensusStatus.sequence:
                pending = "False"
                if configuration.ID == data_body['target_solver']:
                    logging.debug(f"I'm the selected solver of {comm}")
                    access = 'True'
                else:
                    access = 'True'
                valid = 'True'
            elif operation_type == PBFT.MessageType.UPLOAD_GENESIS:
                if PBFT.ConsensusStatus.sequence == 0:
                    # res = AgentRequest_item.query.filter(AgentRequest_item.uuid == uuid,
                    #                                      AgentRequest_item.operation == operation_type,
                    #                                      AgentRequest_item.iteration == iteration,
                    #                                      AgentRequest_item.valid == "True").first()
                    #
                    # if res is not None:
                    #     if res.time_stamp < datetime.fromtimestamp(time_stamp):
                    #         res.valid = "False"
                    #     else:
                    #         valid = "False"

                    for each_key in global_variables.agent_request_pool[0].keys():
                        msg = global_variables.agent_request_pool[0][each_key]
                        if msg.uuid == uuid and msg.operation == operation_type and msg.iteration == iteration and msg.valid == 'True':
                            if msg.time_stamp < datetime.fromtimestamp(time_stamp):
                                msg.valid = 'False'
                            else:
                                valid = 'False'
                    access = "True"
                    pending = "False"
                else:
                    pending = "Timeout"
                    access = "False"
                    valid = "False"
            elif operation_type == PBFT.MessageType.SOLVING_RESULT:
                if iteration < PBFT.ConsensusStatus.sequence:
                    pending = "Timeout"
                    access = "False"
                    valid = "False"
                elif iteration >= PBFT.ConsensusStatus.sequence:
                    pending = "False"
                    access = "True"
                    valid = "Unknown"

            # print(
            #     f"来自客户端 {uuid}的消息,迭代数 {iteration},备注 {comm} 初筛结果：valid={valid},pending={pending},access={access}")

            if PBFT.ConsensusStatus.sequence > 0:
                agent_request_item = AgentRequest_item(uuid=uuid,
                                                       operation=operation_type,
                                                       iteration=iteration,
                                                       time_stamp=datetime.fromtimestamp(time_stamp),
                                                       master_copy=master_copy,
                                                       comm=comm,
                                                       request_hash=agent_request_hash,
                                                       valid=valid,
                                                       pending=pending,
                                                       access=access,
                                                       data=json.loads(data['data']))
            else:
                agent_request_item = AgentRequest_item(uuid=uuid,
                                                       operation=operation_type,
                                                       iteration=iteration,
                                                       time_stamp=datetime.fromtimestamp(time_stamp),
                                                       master_copy='',
                                                       comm=comm,
                                                       request_hash=agent_request_hash,
                                                       valid=valid,
                                                       pending=pending,
                                                       access=access,
                                                       data='')
                with open(f'genesis_info/{agent_request_hash}.txt', 'w') as file:
                    file.write(master_copy)
                with open(f'genesis_info/{agent_request_hash}.pkl', 'wb') as file:
                    pickle.dump(data['data'], file)

            try:
                global_variables.agent_request_lock.acquire()
                if agent_request_hash in global_variables.agent_request_pool[iteration].keys():
                    # global_variables.agent_request_lock.release()
                    return dict(status='success', msg='ignored')
                else:
                    # if len(global_variables.agent_request_judger) >= 200:
                    #     global_variables.agent_request_judger = set()
                    # db.session.add(agent_request_item)
                    # db.session.commit()
                    global_variables.agent_request_pool[iteration][agent_request_hash] = agent_request_item
                    # global_variables.agent_request_lock.release()
            except Exception as e:
                print(f'插入消息至数据库时的exception', str(e))
            finally:
                global_variables.agent_request_lock.release()

            # try:
            #     global_variables.agent_request_lock.acquire()
            #     __res__ = AgentRequest_item.query.filter(AgentRequest_item.request_hash == agent_request_hash).first()
            #     if __res__ is None:
            #         db.session.add(agent_request_item)
            #     db.session.commit()
            # except Exception as e:
            #     print(f'插入消息至数据库时的exception', str(e))
            #     # db.session.rollback()
            # finally:
            #     pass
            #     global_variables.agent_request_lock.release()
        # 处理过该消息
        else:
            return dict(status='success', msg='ignored')
    except Exception as e:
        print(f"Exception when handling request, {str(e)}")
    finally:
        # global_variables.agent_request_lock.release()
        pass
    # 验证消息类型，验证是否已经处理过，写入数据库----------------------------

    if operation_type == PBFT.MessageType.UPLOAD_GENESIS or access == 'False':
        return True


    status_code = 0
    # 注意，由于异步问题，执行到这里后可能区块更新，原本合法的消息又不合法了， 所以上面只是完成了合法性的初筛。
    # agent_request_lock.acquire()
    try:
        logging.debug(
            f"收到用户消息{comm}初筛已完成，准备处理：operation_type={operation_type}, access={access}, pending={pending}")
        # 消息类型2：求解
        if operation_type == PBFT.MessageType.SOLVING_REQUEST:
            logging.debug(f"来自客户端 {uuid}的消息,迭代数 {iteration},备注 {comm}，准备求解")

            if uuid in global_variables.up_to_date_request_dict.keys():
                if iteration > global_variables.up_to_date_request_dict[uuid].iteration:
                    global_variables.up_to_date_request_dict[uuid] = agent_request_item
                    # print("update_request!!")
            else:
                global_variables.up_to_date_request_dict[uuid] = agent_request_item

            target_solver = data_body['target_solver']
            if isinstance(target_solver, str):
                target_solver = [target_solver]
            # print(f'target_solver = {target_solver}')
            from chainnode.modules.ws_action_module.ws_actions import relay_tasks
            target_workers = [global_variables.id_connection_map[_] for _ in target_solver]
            index = configuration.DES_ID_LIST.index(uuid) % len(configuration.MINER_ID_LIST)
            self_index = configuration.MINER_ID_LIST.index(configuration.ID)
            if index == self_index:# or PBFT.ConsensusStatus.primary_host == configuration.MY_HOST: #PBFT.ConsensusStatus.primary_host == configuration.MY_HOST:
                executor.submit(relay_tasks(data=master_copy,
                                            target=target_workers))
            # problem_pool[uuid].update_model(np.array(data_body['a']))
            # result = problem_pool[uuid].solve()
            #
            # # agent_request_item = AgentRequest_item.query. \
            # #     filter(AgentRequest_item.request_hash == agent_request_hash).with_for_update().first()
            #
            # agent_request_item = global_variables.agent_request_pool[iteration][agent_request_hash]
            # agent_request_item.result = result
            # # try:
            # #     db.session.commit()
            # # except Exception as e:
            # #     print(str(e))
            # #     db.session.rollback()
            # # 以客户端身份提交求解结果
            # req = PBFT.CliRequest(operation=PBFT.MessageType.SOLVING_RESULT,
            #                       data=json.dumps({"requestor": uuid,
            #                                        "master_copy": master_copy,
            #                                        "solving_request_hash": agent_request_hash,
            #                                        "result": result}),
            #                       time_stamp=time.time(),
            #                       iteration=iteration,
            #                       uuid=configuration.ID,
            #                       comm=f"Chainnode {configuration.NAME}'s"
            #                            f" solution to solving request {agent_request_hash}").toJson()
            # signature = sign(data=req, key_path=configuration.KEY)
            # data_to_send = json.dumps({"uuid": configuration.ID,
            #                            "data": req,
            #                            "signature": signature,
            #                            "cli_type": "MINER"})
            #
            # executor.submit(broadcast_callback,
            #                 host_list=configuration.MINER_HOST_LIST,
            #                 msg=data_to_send,
            #                 url="/agent/request",
            #                 log="submit_solution",
            #                 including_self=True)

        # 消息类型3：来自其他节点的求解结果
        elif operation_type == PBFT.MessageType.SOLVING_RESULT:
            logging.debug(f"来自客户端 {uuid} 的消息,迭代数 {iteration},备注 {comm}，准备验证")
            solver = uuid
            requestor = data_body['requestor']
            solving_request_hash = data_body['solving_request_hash']

            # print(f"用户认为的迭代数 {iteration},收到求解结果后的处理，尝试锁定原始请求{solving_request_hash}")
            # 现在，我们收到了一条求解结果声明，其声明求解的迭代号等于当前的sequence号，已经计入了agent_request_item条目，
            # 我们先找到其对应的solving_request_item，
            # 如果找不到, 则请求
            # solving_request_item = AgentRequest_item.query.filter(
            #     AgentRequest_item.request_hash == solving_request_hash).first()
            if not (solving_request_hash in global_variables.agent_request_pool[iteration].keys()):
                try:
                    if analyze(data_body['master_copy']) is False:
                        print("尚未集齐所有数据，且处理失败！！！！！！！！")
                        # db.session.commit()
                        return False
                    else:
                        pass
                        # solving_request_item = AgentRequest_item.query. \
                        #     filter(AgentRequest_item.request_hash == solving_request_hash).first()
                except Exception as e:
                    print(f"尚未集齐所有数据，{str(e)}")
                    # db.session.rollback()
                    return False
            try:
                solving_request_item = global_variables.agent_request_pool[iteration][solving_request_hash]
                agent_request_item = global_variables.agent_request_pool[iteration][agent_request_hash]
            except Exception:
                print("解和原始请求获取失败")
            # agent_request_item = AgentRequest_item.query. \
            #     filter(AgentRequest_item.request_hash == agent_request_hash).with_for_update().first()
            logging.debug("收到用户消息的后处理，锁定成功")
            status_code = 1
            KKT = True  # 需要补充代码
            if KKT:
                if solving_request_item.result_request_hash == '':
                    solving_request_item.result_request_hash = agent_request_hash
                    agent_request_item.valid = "True"
                    solving_request_item.valid = "True"
                    global_variables.status_lock.acquire()
                    global_variables.status_pool[iteration].add(requestor)
                    global_variables.status_lock.release()

                    if requestor in global_variables.up_to_date_result_dict.keys():
                        if iteration > global_variables.up_to_date_result_dict[requestor].iteration:
                            # print("update_result!!")
                            global_variables.up_to_date_result_dict[requestor] = agent_request_item
                    else:
                        global_variables.up_to_date_result_dict[requestor] = agent_request_item

                    # print(f"{requestor}在迭代{iteration}记录为已求解"
                    #       f"，{len(global_variables.status_pool[iteration])}。")
            else:
                agent_request_item.valid = "False"
            status_code = 2
            # try:
            #     db.session.commit()
            # except BaseException:
            #     print("验证求解结果后commit失败")
            #     db.session.rollback()
            if configuration.MINER_HOST_LIST[PBFT.ConsensusStatus.view % PBFT.ConsensusStatus.n] \
                    == configuration.MY_HOST:
                doPrePrepareNormal(sequence=PBFT.ConsensusStatus.sequence)
                # logging.debug(str(doPrePrepareNormal()))
        else:
            pass
    except Exception as e:
        print(e)
        print(f"接收到用户消息进行后处理中的exception,force={force}, 消息类型={'Result' if operation_type == PBFT.MessageType.SOLVING_RESULT else 'Request'},"
              f"状态={status_code}")
        print(f"sequence = {PBFT.ConsensusStatus.sequence}")
    finally:
        pass
        # db.session.commit()
        # agent_request_lock.release()
    return True
    # agent_request_lock.release()
    # 用户发布solving request时，如果当前已经进入

