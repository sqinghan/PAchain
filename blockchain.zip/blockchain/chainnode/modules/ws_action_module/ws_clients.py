import asyncio
import json
import time

import aiohttp
import socketio

import PBFT
from chainnode.data import global_variables
import ssl
from chainnode.config import configuration


class FlaskSioClient:
    def __init__(self):
        self.ssl_context = ssl.create_default_context()
        self.ssl_context.load_verify_locations(configuration.CERT_PATH + '/ca.crt')
        # self.connector = aiohttp.TCPConnector(ssl=self.ssl_context)
        self.connector = aiohttp.TCPConnector(verify_ssl=False)
        self.http_session = aiohttp.ClientSession(connector=self.connector)
        self.sio = socketio.AsyncClient(http_session=self.http_session)

        @self.sio.event(namespace='/miner')
        def connect():
            print(f'connection established: {self.sio.connection_url}')

        @self.sio.event(namespace='/miner')
        async def redirect_message_to_handler(data):
            print(data)

        @self.sio.event(namespace='/miner')
        def disconnect():
            print('disconnected from server')


async def async_disconnect(ips):
    tasks = []
    try:
        for client, ip in zip(global_variables.connections, ips):
            if ip != configuration.MY_HOST or True:
                tasks.append(asyncio.create_task(client.sio.disconnect()))
        await asyncio.gather(*tasks)
    except Exception as e:
        print(e)
    #


async def async_connect_to_miners(ips, protocol_head='https://', namespaces=None):
    if namespaces is None:
        namespaces = ['/']
    tasks = []
    if not global_variables.connections:
        global_variables.connections = [FlaskSioClient() for _ in configuration.MINER_HOST_LIST]

    try:
        for client, ip in zip(global_variables.connections, ips):
            if ip != configuration.MY_HOST or True:
                tasks.append(asyncio.create_task(client.sio.connect(protocol_head + ip,
                             namespaces=namespaces, auth=json.dumps({'uuid': configuration.ID}))))
        await asyncio.gather(*tasks)
    except Exception as e:
        print(e)
    #
    # tasks = []
    # for client in clients:
    #     tasks.append(asyncio.create_task(client.sio.wait()))
    # tasks.append(asyncio.create_task(get_message()))
    # await asyncio.gather(*tasks)


async def __ws_broadcast__(ips, event, msg, excluding_self=True, namespace=None):
    tasks = []
    try:
        for client, ip in zip(global_variables.connections, ips):
            if excluding_self and ip == configuration.MY_HOST:
                continue
            tasks.append(asyncio.create_task(client.sio.emit(event, msg, namespace)))
        await asyncio.gather(*tasks)
    except Exception as e:
        print(e)


def ws_broadcast(ips=None, event=None, msg=None,
                 excluding_self=True, namespace=None, protocol_head='https'):
    if namespace is None:
        namespace = '/miner'
    # try:
    #     asyncio.run(async_connect(clients, ips))
    # except Exception as e:
    #     print(e)
    need_to_connect = False
    if global_variables.connections:
        for each in global_variables.connections:
            if each.sio.connected is False:
                need_to_connect = True
    else:
        need_to_connect = True

    loop = global_variables.event_loop
    asyncio.set_event_loop(loop)

    if need_to_connect:
        print("Create client connections to miners!")
        loop.run_until_complete(async_connect_to_miners(ips, namespaces=namespace))
        # asyncio.run_coroutine_threadsafe(async_connect(ips), loop)
        # time.sleep(0.1)
        if global_variables.connections:
            for each in global_variables.connections:
                print(each.sio.connected, end=' ')
    try:
        global_variables.event_loop_lock.acquire()
        loop.run_until_complete(__ws_broadcast__(ips, event, msg, excluding_self, namespace))
        global_variables.event_loop_lock.release()
        # asyncio.run_coroutine_threadsafe(__ws_broadcast__(ips, event, msg, excluding_self, namespace), loop)
        # loop.run_until_complete(async_disconnect(ips))
    except Exception as e:
        print(e)


async def async_connect_to_DESs(ips, protocol_head='https://', namespaces=None):
    if namespaces is None:
        namespaces = ['/']
    tasks = []
    if not global_variables.DES_connections:
        global_variables.DES_connections = [FlaskSioClient() for _ in configuration.DES_HOST_LIST]

    try:
        for client, ip in zip(global_variables.DES_connections, ips):
            tasks.append(asyncio.create_task(client.sio.connect(protocol_head + ip,
                         namespaces=namespaces, auth=json.dumps({'uuid': configuration.ID}))))
        await asyncio.gather(*tasks)
    except Exception as e:
        print(e)


async def __ws_broadcast_to_DESs__(ips, event, msg, namespace=None):
    tasks = []
    try:
        for client, ip in zip(global_variables.DES_connections, ips):
            tasks.append(asyncio.create_task(client.sio.emit(event, msg, namespace)))
        await asyncio.gather(*tasks)
    except Exception as e:
        print(e)


def ws_broadcast_to_DES(ips=None, event=None, msg=None, namespace=None, protocol_head='https'):
    if namespace is None:
        namespace = '/miner_DES_channel'
    # try:
    #     asyncio.run(async_connect(clients, ips))
    # except Exception as e:
    #     print(e)
    need_to_connect = False
    if global_variables.DES_connections:
        for each in global_variables.DES_connections:
            if each.sio.connected is False:
                need_to_connect = True
    else:
        need_to_connect = True

    loop = global_variables.event_loop
    asyncio.set_event_loop(loop)

    if need_to_connect:
        print("Create client connections to DESs!")
        loop.run_until_complete(async_connect_to_DESs(ips, namespaces=namespace))
        if global_variables.DES_connections:
            for each in global_variables.DES_connections:
                print(each.sio.connected, end=' ')
            print("")
    try:
        global_variables.event_loop_lock.acquire()
        loop.run_until_complete(__ws_broadcast_to_DESs__(ips=ips, event=event, msg=msg, namespace=namespace))
        global_variables.event_loop_lock.release()
    except Exception as e:
        print(e)

