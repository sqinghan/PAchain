import json

from chainnode.data import global_variables
from flask_socketio import emit, send
from flask import request
from chainnode.config import configuration
import logging


def broadcast_all(event, data,  namespace):
    global_variables.socketio.emit(event, data=data, namespace=namespace, broadcast=True)
    # for each in global_variables.workers_connected:
    #     connection = global_variables.id_connection_map[each]
    #     global_variables.socketio.emit(event, data=data, namespace=namespace, to=connection, callback=print)


def relay_tasks(data, target):
    for each in target:
        global_variables.socketio.emit(event='solving_request', data=data, namespace='/worker', to=each)


@global_variables.socketio.on('solving_solution', namespace='/worker')
def on_received_solution(data):
    # print(f"receive_solving_result from {global_variables.connection_id_map[request.sid]}")
    from chainnode.modules.agent_module.agent import redirect_request
    redirect_request(msg=data)
    # from chainnode.modules.agent_module.agent import handle_worker_solutions
    # global_variables.executor.submit(handle_worker_solutions(data))


@global_variables.socketio.on('connect', namespace='/worker')  # 有客户端连接会触发该函数
def on_connect_worker(auth):
    # 建立连接 sid:连接对象ID
    # return False
    client_id = request.sid
    auth_id = json.loads(auth)['uuid']
    print(
        f'new connection, connection id=[{client_id}], client id={auth_id} try to connect to worker channel...')
    if auth_id in configuration.WORKER_ID_LIST:
        global_variables.ws_clients.append(client_id)
        print(
            f'new connection, connection id=[{client_id}], worker id={auth_id} accepted')
        global_variables.workers_connected.append(auth_id)
        print(f'Now have {len(global_variables.workers_connected)} workers, {len(global_variables.ws_clients)} clients')
        global_variables.connection_id_map[client_id] = auth_id
        global_variables.id_connection_map[auth_id] = client_id
    else:
        print(
            f'new connection, connection id=[{client_id}], client id={auth_id} rejected')
        return False


@global_variables.socketio.on('disconnect', namespace='/worker')
def on_disconnect_worker():
    worker_id = global_variables.connection_id_map[request.sid]
    global_variables.workers_connected.remove(worker_id)
    global_variables.ws_clients.remove(request.sid)
    print(f'connection id={request.sid}, worker id={worker_id}'
          f' exited, now have {len(global_variables.workers_connected)} workers')
    global_variables.connection_id_map[request.sid] = None
    global_variables.id_connection_map[worker_id] = None


@global_variables.socketio.on('connect', namespace='/miner')  # 有客户端连接会触发该函数
def on_connect_miner(auth):
    # 建立连接 sid:连接对象ID
    # return False
    client_id = request.sid
    auth_id = json.loads(auth)['uuid']
    print(
        f'new connection, connection id=[{client_id}], miner id={auth_id} try to connect to miner channel...')
    if auth_id in configuration.MINER_ID_LIST:
        print(
            f'new connection, connection id=[{client_id}], miner id={auth_id} accepted')
        global_variables.miners_connected.append(auth_id)
        print(f'Now have {len(global_variables.miners_connected)} miners')
        global_variables.connection_id_map[client_id] = auth_id
        global_variables.id_connection_map[auth_id] = client_id
    else:
        print(
            f'new connection, connection id=[{client_id}], id={auth_id} rejected')
        return False
    print("connection created successfully")
    send('hello', namespace='/miner')
    return True


@global_variables.socketio.on('disconnect', namespace='/miner')
def on_disconnect_miner():
    miner_id = global_variables.connection_id_map[request.sid]
    global_variables.miners_connected.remove(miner_id)
    print(f'connection id={request.sid}, miner id={miner_id}'
          f' exited, now have {len(global_variables.miners_connected)} miners')
    global_variables.connection_id_map[request.sid] = None
    global_variables.id_connection_map[miner_id] = None
    print("disconnected!")


@global_variables.socketio.on('preprepare', namespace='/miner')
def handle_pre_prepare_ws(data):
    # print('receive preprepare through socketio!')
    from chainnode.modules.peer_module import handle_pre_prepare
    global_variables.executor.submit(handle_pre_prepare, data)
    # handle_pre_prepare(data)


@global_variables.socketio.on('prepare', namespace='/miner')
def handle_prepare_ws(data):
    # print('receive preprepare through socketio!')
    from chainnode.modules.peer_module import handle_prepare
    handle_prepare(data)


@global_variables.socketio.on('commit', namespace='/miner')
def handle_commit_ws(data):
    # print('receive preprepare through socketio!')
    from chainnode.modules.peer_module import handle_commit
    handle_commit(data)


@global_variables.socketio.on('connect', namespace='/DES')  # 有客户端连接会触发该函数
def on_connect_DES(auth):
    # 建立连接 sid:连接对象ID
    # return False
    client_id = request.sid
    auth_id = json.loads(auth)['uuid']
    print(
        f'new connection, connection id=[{client_id}], DES id={auth_id} try to connect to DES channel...')
    if auth_id in configuration.DES_ID_LIST:
        print(
            f'new connection, connection id=[{client_id}], DES id={auth_id} accepted')
        global_variables.DESs_connected.append(auth_id)
        print(f'Now have {len(global_variables.DESs_connected)} DESs')
        global_variables.connection_id_map[client_id] = auth_id
        global_variables.id_connection_map[auth_id] = client_id
    else:
        print(
            f'new connection, connection id=[{client_id}], id={auth_id} rejected')
        return False
    print("connection created successfully")
    # send('hello', namespace='/DES')
    return True


@global_variables.socketio.on('disconnect', namespace='/DES')
def on_disconnect_DES():
    DES_id = global_variables.connection_id_map[request.sid]
    global_variables.DESs_connected.remove(DES_id)
    print(f'connection id={request.sid}, worker id={DES_id}'
          f' exited, now have {len(global_variables.miners_connected)} workers')
    global_variables.connection_id_map[request.sid] = None
    global_variables.id_connection_map[DES_id] = None
    print("disconnected!")


@global_variables.socketio.on('solving_request', namespace='/DES')
def on_received_request(data):
    from chainnode.modules.agent_module.agent import redirect_request
    redirect_request(msg=data)