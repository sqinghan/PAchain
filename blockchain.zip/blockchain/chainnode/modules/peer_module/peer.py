import hashlib
import logging
import pickle
import time
from datetime import datetime

import httpx
import numpy as np
# from sqlalchemy import or_

import PBFT
from chainnode.data.block.block import BlockEncoder
from chainnode.modules.agent_module import analyze
from chainnode.modules.peer_module import peer_blueprint
from chainnode.data.block import blockchain, Block, GenesisBLock, BlockBase
from chainnode.data.database import db
from chainnode.data.database.peers_db import Peer_item
# from chainnode.data.database.agents_db import AgentRequest_item
from chainnode.data.database.messages_db import Message_item, ConsensusMatter_item
# from chainnode.data.database.status_db import Database_status_item
from chainnode.data.database.blockhashes_db import Block_item
from chainnode.modules.ws_action_module.ws_clients import ws_broadcast, ws_broadcast_to_DES
from chainnode.utils.broadcastutils import broadcast_callback
# from chainnode.utils.standardformulation import StandardFormulation, Model
from chainnode.utils.common import verify_signature, sign, check_peer, check_cli_type, hashmd5, toMatter
from chainnode.config import configuration
from chainnode.utils import check_uuid
# from chainnode.utils import broadcast
import json
from flask import request
# import asyncio
# from Crypto.Hash import SHA, SHA256
from chainnode.errors import *
from chainnode.data.global_variables import block_lock, agent_request_lock, executor, \
    problem_pool, status_pool
# from chainnode.data.global_variables import result_gossip_pool
from chainnode.data import global_variables


# @peer_blueprint.route("/register", methods=['POST'])
# def register_peer():
#     request_info = json.loads(request.data.decode("utf-8"))
#     required_info = ["name", "uuid", "pubkey"]
#
#     if not all(each in request_info for each in required_info):
#         # print("missing peer data")
#         return "Missing peer data!"
#
#     if Peer_item.query.get(request_info["uuid"]) is None and check_uuid(request_info["uuid"]):
#         item = Peer_item(name=request_info["name"], uuid=request_info["uuid"], pubkey=request_info["pubkey"])
#         db.session.add(item)
#         db.session.commit()
#         return {
#             "status": "success",
#             "msg": "Register successfully!"
#         }
#     else:
#         return {
#             "status": "failed",
#             "msg": "Peer Item exists! Register Failed!"
#         }


# @peer_blueprint.route("/query_all_peers", methods=['GET'])
# def query_all_peers():
#     response = Peer_item.query.all()
#     if len(response) == 0:
#         return {
#             "status": "success",
#             "msg": "There is no registered peer!",
#             "data": None
#         }
#     return {
#         "status": "success",
#         "msg": "Query successfully!",
#         "data": str(response)
#     }


# @peer_blueprint.route("/query_matters", methods=['GET'])
# def query_matters():
#     res = db.session.query(ConsensusMatter_item).all()
#     # res = ConsensusMatter_item.query.all()
#     if len(res) == 0:
#         return {}
#     else:
#         d = {}
#         for each in res:
#             res_load = json.loads(str(each))
#             d[str((res_load['view'], res_load['sequence']))] = {
#                 'matter_type': res_load['matter_type'],
#                 'matter_hash': res_load['matter_hash'],
#                 'prepares': res_load['prepares'],
#                 'is_prepared': res_load['is_prepared'],
#                 'commits': res_load['commits'],
#                 'is_committed': res_load['is_committed'],
#                 'prev_committed': res_load['prev_block_committed']
#             }
#         return d


# @peer_blueprint.route("/query_blocks", methods=['GET'])
# def query_blocks():
#     res = db.session.query(Block_item).all()
#     # res = ConsensusMatter_item.query.all()
#     if len(res) == 0:
#         return {}
#     else:
#         d = {}
#         for each in res:
#             res_load = json.loads(str(each))
#             d[res_load['height']] = res_load
#         return d


# @peer_blueprint.route("/query", methods=['GET'])
# def query():
#     try:
#         request_info = json.loads(request.data.decode("utf-8"))
#         required_info = ["uuid"]
#         if not all(each in request_info for each in required_info):
#             return {
#                 "status": "failed",
#                 "msg": "missing uuid data",
#                 "data": ""
#             }
#     except Exception:
#         return {
#             "status": "failed",
#             "msg": "failed when loading request data!",
#             "data": ""
#         }
#
#     response = Peer_item.query.filter_by(uuid=request_info["uuid"]).all()
#     if len(response) == 0:
#         return {
#             "status": "success",
#             "msg": "False",
#             "data": None
#         }
#     return {
#         "status": "success",
#         "msg": "True",
#         "data": str(response)
#     }


def extend_pool(pool, lock, l):
    lock.acquire()
    if l >= len(pool) - 1:
        pool += [dict() for _ in range(5 + l - len(pool))]
    lock.release()


@peer_blueprint.route("/handlePrePrepare", methods=['POST'])
def handle_pre_prepare(msg=None):
    # from random import random
    # time.sleep(random())
    request_data = msg or request.data.decode('utf-8')
    request_in_dict = json.loads(request_data)
    # 当前view下的消息，签名、格式检查 ------------------ PREPREPARE ------------------
    #  ----------------------------第一次合法性验证-----------------------------------
    #  ----------------------------基本格式验证-----------------------------------
    check_format = check_peer(request_in_dict, PBFT.MessageType.PRE_PREPARE)
    if check_format["status"] == "failed":
        return check_format

    # 验证通过， 展开消息，获取view, sequence, matter, matterhash等基本信息
    data = json.loads(request_in_dict["data"])
    view = data["view"]
    sequence = data["sequence"]
    prev_block_hash = data['prev_block_hash']
    matter, matter_hash = toMatter(data)
    assert matter_hash == data["matter_hash"]
    # print(f"迭代{PBFT.ConsensusStatus.sequence}: 接收到pre-prepare sequence={data['sequence']}")

    extend_pool(global_variables.peer_pre_prepare_pool, global_variables.peer_pre_prepare_lock, sequence)
    extend_pool(global_variables.consensus_matter_pool, global_variables.consensus_matter_lock, sequence)
    logging.debug(f"{configuration.NAME} handling pre-prepare...for iteration{sequence}, 形式验证通过")

    # 将消息计入log, 包括消息源、时间戳、消息类型(pre-prepare)、消息原文，对应的事务信息，对应的view和sequence信息
    # 验证消息 是否是和已有消息冲突的，legality in terms of consensus
    # ----------------------------------------------------------------------------
    # ----------------------------第二次合法性验证,插入消息库--------------------------
    # try:
    #     existing_message = Message_item.query.get((data['uuid'], data['type'], view, prev_block_hash))
    #     if existing_message is None:
    #         # 收到了合法的Pre-prepare消息，消息来源是主节点，原始消息存入message_text，对应的matter记入corresponding matter hash
    #         message_item = Message_item(source=data['uuid'],
    #                                     time_stamp=datetime.now(),
    #                                     typ=data["type"],  # PRE-PREPARE
    #                                     message_text=request.data.decode("utf-8"),
    #                                     view=view,
    #                                     sequence=sequence,
    #                                     prev_block_hash=prev_block_hash,
    #                                     corresponding_matter_hash=matter_hash
    #                                     )
    #         db.session.add(message_item)
    #         db.session.commit()
    #     else:
    #         existing_matter_hash = existing_message.corresponding_matter_hash
    #         existing_matter_sequence = existing_message.sequence
    #         if existing_matter_hash != matter_hash or existing_matter_sequence != sequence:
    #             raise ConflictMessageError(data['uuid'], data['type'], view, prev_block_hash, sequence)
    #         else:
    #             raise RepeatedMessageException(data['uuid'], data['type'], view, prev_block_hash, sequence)
    # except Exception as e:
    #     # print(e.message)
    #     logging.info("消息冲突或已处理，请查看日志")
    #     return dict(status="failed", msg="消息冲突或已处理, 中止流程")
    # finally:
    #     pass
    #     # 根据e的type实施viewchange
    #  ----------------------------第二次合法性验证-----------------------------------
    #  ----------------------------主节点preprepare消息验证，验证是否重复-----------------------------------
    message_item = Message_item(source=data['uuid'],
                                time_stamp=datetime.now(),
                                typ=data["type"],  # PRE-PREPARE
                                message_text=request_data,
                                view=view,
                                sequence=sequence,
                                prev_block_hash=prev_block_hash,
                                corresponding_matter_hash=matter_hash
                                )
    try:
        global_variables.peer_pre_prepare_lock.acquire()
        if data['uuid'] in global_variables.peer_pre_prepare_pool[sequence].keys():
            if global_variables.peer_pre_prepare_pool[sequence][data['uuid']].matter_hash \
                    != message_item.corresponding_matter_hash:
                return {"msg": "错误！换主"}
            return {"msg": "handled"}
        else:
            global_variables.peer_pre_prepare_pool[sequence][data['uuid']] = message_item
    except Exception as e:
        pass
        # print(f'插入消息至preprepare_pool时的错误', str(e))
    finally:
        global_variables.peer_pre_prepare_lock.release()

    # print(f"迭代{PBFT.ConsensusStatus.sequence}: 通过第二次合法性验证")
    # Pre-prepare消息，写入Matters表，建立事务，并准备check prepare
    # 首先验证上一个block是否是对的，如果自己还未建立上一个block，那么依然会正常处理消息，但是不会prepare。
    # ----------------------------------------------------------------------------
    # ----------------------------第三次合法性验证，是否能提供相关的master copy----------------------------------
    collected_hashes = []
    uncollected_hashes = []
    for each_key in data['involved_request_hashes']:
        if each_key in global_variables.agent_request_pool[sequence].keys():
            collected_hashes += [each_key]
        else:
            uncollected_hashes += [each_key]
    if len(uncollected_hashes) != 0:
        # print(f"I'm collecting master_copies:{uncollected_hashes}, uncollected={len(uncollected_hashes)}, collected={len(collected_hashes)}")
        master_copies = do_collect_agent_request(uncollected_hashes)
        for each in master_copies:
            analyze(each)
    else:
        pass
        # print(f"迭代{PBFT.ConsensusStatus.sequence}: 通过第三次合法性验证，所有区块内部信息已到位")

    if sequence >= len(global_variables.packaged_request_pool) - 1:
        global_variables.packaged_request_pool += \
            [list() for _ in range(5 + sequence - len(global_variables.packaged_request_pool))]

    for each_hash in data['involved_request_hashes']:
        seq = sequence
        while seq >= 0:
            if each_hash in global_variables.agent_request_pool[seq].keys():
                global_variables.packaged_request_pool[sequence].\
                    append(global_variables.agent_request_pool[seq][each_hash])
                break
            else:
                seq -= 1
    # # print(f"sequence = {sequence}, prev_committed={prev_block_committed}")

    # 上述过程对待执行事务进行第三次合法性验证，
    # 第一次在check_peer里验证签名和必要的key
    # 第二次验证待打包的区块和已有事务是否不同，即此前是否收到了相关的事务，并插入消息库
    # 第三次验证前一区块是否到位，是否和当前事务矛盾，
    # 第四次验证要求所有的原始消息，

    prev_block_committed = False
    consensus_matter_item = ConsensusMatter_item(view, sequence,
                                                 matter, matter_hash, matter["prev_block_hash"], prev_block_committed)
    # db.session.add(consensus_matter_item)
    # db.session.commit()
    try:
        # 这里不需要锁，因为前面pre prepare message锁已经隔离了不同的sequence了
        # global_variables.consensus_matter_lock.acquire()
        global_variables.consensus_matter_pool[sequence][data['uuid']] = consensus_matter_item
        # print(f"迭代{PBFT.ConsensusStatus.sequence}: 写入事务{sequence} {data['uuid']}")
    except Exception as e:
        pass
        # print(f'插入消息至consensus_matter_pool时的错误', str(e))
    finally:
        pass
        # global_variables.consensus_matter_lock.release()

    global_variables.peer_prepare_lock.acquire()
    consensus_matter_item.prepares_collected = 0
    for key in global_variables.peer_prepare_pool[sequence].keys():
        global_variables.peer_prepare_pool[sequence][key].handled = True
        consensus_matter_item.prepares_collected += 1
    global_variables.peer_prepare_lock.release()

    global_variables.peer_commit_lock.acquire()
    consensus_matter_item.commits_collected = 0
    for key in global_variables.peer_commit_pool[sequence].keys():
        global_variables.peer_commit_pool[sequence][key].handled = True
        consensus_matter_item.commits_collected += 1
    global_variables.peer_commit_lock.release()

    # ----------------------------------------------------------------------------
    # ----------------------------第四次合法性验证,前一区块是否一致-----------------------------------
    if matter['operation'] == PBFT.MessageType.CONSENSUS_GENESIS:  # and PBFT.ConsensusStatus.sequence == 0:
        prev_block_committed = True
    else:
        if global_variables.tip_block.height == sequence - 1:
            if global_variables.tip_block_hash == matter['prev_block_hash'] \
                    and PBFT.ConsensusStatus.sequence == sequence:
                prev_block_committed = True
                # print(f"迭代事务{PBFT.ConsensusStatus.sequence}， 当前节点区块高度为{global_variables.tip_block.height},通过第三次合法性验证")
            else:
                return dict(status="failed", msg="待执行事务不成立")
        else:
            pass
            # print(f"迭代{PBFT.ConsensusStatus.sequence}: 未通过第四次合法性验证，前一区块未就绪")

    logging.debug(
        f"{configuration.NAME} handling pre-prepare...for iteration{sequence},前一区块提交状态:{prev_block_committed}")

    consensus_matter_item.prev_block_committed = prev_block_committed
    if prev_block_committed:
        # print(f"迭代{PBFT.ConsensusStatus.sequence}: do prepare成功")
        return do_prepare(matter, matter_hash, data, view, sequence)
    else:
        # print(f"迭代{PBFT.ConsensusStatus.sequence}: handle pre-prepare时前一区块尚未完成，暂缓prepare")
        logging.debug(f"{configuration.NAME} handling pre-prepare...for iteration{sequence}, 但前一区块尚未完成，暂缓")
        return dict(status='pending', msg='previous block not handled')


@peer_blueprint.route("/handlePrepare", methods=['POST'])
def handle_prepare(msg=None):
    # from random import random
    # time.sleep(random())
    request_data = msg or request.data.decode('utf-8')
    request_in_dict = json.loads(request_data)
    # 当前view下的消息，签名、格式检查 ------------------ PREPARE ------------------
    #  ----------------------------第一次合法性验证-----------------------------------
    check_format = check_peer(request_in_dict, PBFT.MessageType.PREPARE)
    if check_format["status"] == "failed":
        return check_format

    # 验证通过， 展开消息，获取view, sequence, matter, matter_hash等基本信息
    data = json.loads(request_in_dict["data"])
    view = data["view"]
    sequence = data["sequence"]
    prev_block_hash = data['prev_block_hash']
    matter, matter_hash = toMatter(data)
    assert matter_hash == data["matter_hash"]

    extend_pool(global_variables.peer_prepare_pool, global_variables.peer_prepare_lock, sequence)
    extend_pool(global_variables.consensus_matter_pool, global_variables.consensus_matter_lock, sequence)
    # # print(f"{configuration.NAME} handling prepare...for iteration{sequence}")
    # 将消息计入log, 包括消息源、时间戳、消息类型(prepare)、消息原文，对应的事务信息，对应的view和sequence信息
    # 验证消息 是否是和已有消息冲突的，legality in terms of consensus
    # try:
    #     # message_lock.acquire()
    #     existing_message = Message_item.query.get((data['uuid'], data['type'], view, prev_block_hash))
    #     if existing_message is None:
    #         message_item = Message_item(source=data['uuid'],
    #                                     time_stamp=datetime.now(),
    #                                     typ=data["type"],
    #                                     message_text=request.data.decode("utf-8"),
    #                                     view=view,
    #                                     sequence=sequence,
    #                                     prev_block_hash=prev_block_hash,
    #                                     corresponding_matter_hash=matter_hash,
    #                                     )
    #         db.session.add(message_item)
    #         db.session.commit()
    #     else:
    #         existing_matter_hash = existing_message.corresponding_matter_hash
    #         existing_sequence = existing_message.sequence
    #         if existing_matter_hash != matter_hash or existing_sequence != sequence:
    #             raise ConflictMessageError(data['uuid'], data['type'], view, prev_block_hash, sequence)
    #         else:
    #             raise RepeatedMessageException(data['uuid'], data['type'], view, prev_block_hash, sequence)
    # except (ConflictMessageError, RepeatedMessageException, Exception) as e:
    #     print(e.message)
    #     logging.debug("prepare和此前的prepare消息冲突或已处理，请查看日志")
    #     return dict(status="failed", msg="消息冲突或已处理, 中止流程")
    # finally:
    #     pass

    message_item = Message_item(source=data['uuid'],
                                time_stamp=datetime.now(),
                                typ=data["type"],  # PREPARE
                                message_text=request_data,
                                view=view,
                                sequence=sequence,
                                prev_block_hash=prev_block_hash,
                                corresponding_matter_hash=matter_hash
                                )
    try:
        global_variables.peer_prepare_lock.acquire()
        if data['uuid'] in global_variables.peer_prepare_pool[sequence].keys():
            if global_variables.peer_prepare_pool[sequence][data['uuid']].matter_hash \
                    != message_item.corresponding_matter_hash:
                return {"msg": "错误！"}
            return {"msg": "handled"}
        else:
            global_variables.peer_prepare_pool[sequence][data['uuid']] = message_item
    except Exception as e:
        print(f'插入消息至prepare_pool时的错误', str(e))
    finally:
        global_variables.peer_prepare_lock.release()

    # prepare消息，考察Matters表中是否存在相应事务，并记录，并准备check prepared

    # existing_matter = ConsensusMatter_item.query.filter(ConsensusMatter_item.view == view,
    #                                                     ConsensusMatter_item.prev_block_hash == matter[
    #                                                         'prev_block_hash']).first()
    # if existing_matter is None:
    current_primary_id = configuration.MINER_ID_LIST[PBFT.ConsensusStatus.view % PBFT.ConsensusStatus.n]
    if not (current_primary_id in global_variables.consensus_matter_pool[sequence].keys()):
        pass
        # db.session.commit()
    else:
        existing_matter = \
            global_variables.consensus_matter_pool[sequence][current_primary_id]
        try:
            existing_matter_hash = existing_matter.matter_hash
            existing_matter_sequence = existing_matter.sequence
            if matter_hash != existing_matter_hash or sequence != existing_matter_sequence:
                raise ConflictMatterError(data['uuid'], data['type'], view, prev_block_hash, sequence)
            else:
                logging.info("来自他人的prepare")
                # existing_message = Message_item.query. \
                #     filter(Message_item.source == data['uuid'],
                #            Message_item.type == data['type'],
                #            Message_item.view == view,
                #            Message_item.prev_block_hash == prev_block_hash).first()
                existing_message = message_item
                if existing_message.handled is True:
                    # db.session.commit()
                    return {
                        "status": "success",
                        "msg": "prepare message handled already"
                    }
                else:
                    global_variables.consensus_matter_lock.acquire()
                    existing_message.handled = True
                    # db.session.commit()
                    # existing_matter = ConsensusMatter_item.query.filter(ConsensusMatter_item.view == view,
                    #                                                     ConsensusMatter_item.prev_block_hash == matter[
                    #                                                         'prev_block_hash']).with_for_update().first()
                    existing_matter.prepares_collected = existing_matter.prepares_collected + 1
                    global_variables.consensus_matter_lock.release()
                    if existing_matter.prev_block_committed and existing_matter.prepares_collected >= 2 * PBFT.ConsensusStatus.f:
                        existing_matter.is_prepared = True
                        # db.session.commit()
                        do_commit(matter, matter_hash, data, view, sequence)
                    else:
                        pass
                        # db.session.commit()
        except (ConflictMatterError, Exception) as e:
            print(e)
            # print(f"handle_prepare消息时出错，和已接受的pre-prepare冲突或其他错误, 序列号{sequence}")
        finally:
            pass
            # try:
            #     db.session.commit()
            # except Exception as e:
            #     db.session.rollback()
    # if not released:
    #     pbft_matter_lock.release()

    # 一般不会在这一步出现Conflict matter error, 出现了则基本说明commit来源在造假
    # 守护进程需要向prepare来源索取其用以生成commit的原始prepared消息包，以证明其清白
    # 若能证明，可能是pbFT的假设根本不满足，恶意节点过多了

    return {
        "status": "success",
        "msg": "prepare message handled"
    }


@peer_blueprint.route("/handleCommit", methods=['POST'])
def handle_commit(msg=None):
    # from random import random
    # time.sleep(random())
    request_data = msg or request.data.decode('utf-8')
    request_in_dict = json.loads(request_data)
    # 对消息的格式、签名验证是否是literally legal的，排除不符合规则的消息 ------------------ COMMIT ------------------
    #  ----------------------------第一次合法性验证-----------------------------------
    check_format = check_peer(request_in_dict, PBFT.MessageType.COMMIT)
    if check_format["status"] == "failed":
        return check_format

    # 验证通过， 展开消息，获取view, sequence, matter, matterhash等基本信息
    data = json.loads(request_in_dict["data"])
    view = data["view"]
    sequence = data["sequence"]
    prev_block_hash = data['prev_block_hash']
    matter, matter_hash = toMatter(data)
    assert matter_hash == data["matter_hash"]

    extend_pool(global_variables.peer_commit_pool, global_variables.peer_commit_lock, sequence)
    extend_pool(global_variables.consensus_matter_pool, global_variables.consensus_matter_lock, sequence)
    # # print(f"{configuration.NAME} handling commit...for iteration{sequence}, 消息来源{data['uuid']}")
    # 将消息计入log, 包括消息源、时间戳、消息类型(Commit)、消息原文，对应的事务信息，对应的view和sequence信息
    # 验证消息 是否是和同来源已有消息冲突的，legality in terms of consensus
    # try:
    #     # message_lock.acquire()
    #     existing_message = Message_item.query.get((data['uuid'], data['type'], view, prev_block_hash))
    #     if existing_message is None:
    #         message_item = Message_item(source=data['uuid'],
    #                                     time_stamp=datetime.now(),
    #                                     typ=data["type"],
    #                                     message_text=request.data.decode("utf-8"),
    #                                     view=view,
    #                                     sequence=sequence,
    #                                     prev_block_hash=prev_block_hash,
    #                                     corresponding_matter_hash=matter_hash
    #                                     )
    #         try:
    #             db.session.add(message_item)
    #             db.session.commit()
    #         except Exception:
    #             db.session.rollback()
    #     else:
    #         existing_matter_hash = existing_message.corresponding_matter_hash
    #         existing_matter_sequence = existing_message.sequence
    #         if existing_matter_hash != matter_hash or existing_matter_sequence != sequence:
    #             raise ConflictMessageError(data['uuid'], data['type'], view, prev_block_hash, sequence)
    #         else:
    #             raise RepeatedMessageException(data['uuid'], data['type'], view, prev_block_hash, sequence)
    # except (ConflictMessageError, RepeatedMessageException) as e:
    #     # print(e.message)
    #     # print("commit消息和此前的commit消息冲突或已处理，请查看日志")
    #     return dict(status="failed", msg="消息冲突或重复, 中止流程")
    # finally:
    #     pass
    message_item = Message_item(source=data['uuid'],
                                time_stamp=datetime.now(),
                                typ=data["type"],  # COMMIT
                                message_text=request_data,
                                view=view,
                                sequence=sequence,
                                prev_block_hash=prev_block_hash,
                                corresponding_matter_hash=matter_hash
                                )
    try:
        global_variables.peer_commit_lock.acquire()
        if data['uuid'] in global_variables.peer_commit_pool[sequence].keys():
            if global_variables.peer_commit_pool[sequence][data['uuid']].matter_hash \
                    != message_item.corresponding_matter_hash:
                return {"msg": "错误！"}
            return {"msg": "handled"}
        else:
            global_variables.peer_commit_pool[sequence][data['uuid']] = message_item
    except Exception as e:
        pass
        # print(f'插入消息至commit_pool时的错误', str(e))
    finally:
        global_variables.peer_commit_lock.release()

    # commit消息，考察Matters表中是否存在相应事务，并记录，并准备check committed
    # pbft_matter_lock.acquire()
    # released = False
    # existing_matter = ConsensusMatter_item.query.filter_by(view=view,
    #                                                        prev_block_hash=prev_block_hash).first()
    # if existing_matter is None:
    current_primary_id = configuration.MINER_ID_LIST[view % PBFT.ConsensusStatus.n]
    if not (current_primary_id in global_variables.consensus_matter_pool[sequence].keys()):
        pass
        # db.session.commit()
    else:
        existing_matter = \
            global_variables.consensus_matter_pool[sequence][current_primary_id]
        try:
            existing_matter_hash = existing_matter.matter_hash
            existing_matter_sequence = existing_matter.sequence
            if matter_hash != existing_matter_hash or sequence != existing_matter_sequence:
                raise ConflictMatterError(data['uuid'], data['type'], view, prev_block_hash, sequence)
            else:
                logging.info("来自他人的commit")
                # existing_message = Message_item.query. \
                #     filter(Message_item.source == data['uuid'],
                #            Message_item.type == data['type'],
                #            Message_item.view == view,
                #            Message_item.prev_block_hash == prev_block_hash).first()
                existing_message = message_item
                if existing_message.handled is True:
                    # db.session.commit()
                    return {
                        "status": "success",
                        "msg": "prepare message handled already"
                    }
                else:
                    global_variables.consensus_matter_lock.acquire()
                    existing_message.handled = True
                    # db.session.commit()
                    # existing_matter = ConsensusMatter_item.query.filter_by(view=view,
                    #                                                        prev_block_hash=prev_block_hash).with_for_update().first()
                    existing_matter.commits_collected = existing_matter.commits_collected + 1
                    global_variables.consensus_matter_lock.release()
                    if existing_matter.is_prepared and existing_matter.commits_collected >= 2 * PBFT.ConsensusStatus.f + 1:
                        existing_matter.is_committed = True
                        # db.session.commit()
                        do_execute_block(view, sequence, matter, matter_hash)
                    # else:
                    #     db.session.commit()
        except (ConflictMessageError, Exception) as e:
            print(e)
            # print(f"handle_commit消息时出错，和已接受的pre-prepare冲突或其他错误, 序列号{sequence}")
        finally:
            pass
            # try:
            #     db.session.commit()
            # except Exception as e:
            #     # print("handle_commit结束会话提交失败，rollback!")
            #     db.session.rollback()
    # if not released:
    #     pbft_matter_lock.release()
    return {
        "status": "success",
        "msg": "commit message handled"
    }


def do_collect_agent_request(_hash):
    host = configuration.MINER_HOST_LIST[PBFT.ConsensusStatus.view % PBFT.ConsensusStatus.n]
    import ssl
    context = None #ssl.create_default_context(configuration.CA_FILE)
    with httpx.Client(verify=context, timeout=None) as client:
        try:
            # print(f"迭代{PBFT.ConsensusStatus.sequence}: 尝试询问")
            resp = client.post("https://" + host + "/get_request", data=json.dumps({'hash': _hash}))
            logging.debug(resp.text)
            # print(f"迭代{PBFT.ConsensusStatus.sequence}: 寻找成功")
            return json.loads(resp.text)['msg']
        except httpx.ConnectError as e:
            # print(f"迭代{PBFT.ConsensusStatus.sequence}: 寻找失败")
            # print(e)
            logging.info(e)


def do_prepare(matter, matter_hash, data, view, sequence):
    # 这一事务的入口有两个，要么在处理主节点的pre-prepare后节点认为前一个block已经到位，进行do_prepare，
    # 要么在一个block到位后对相应的matter做do_prepare
    # 首先，验证这一事务此前没有广播过prepare消息
    # 会不会存在一种情况，节点认为前一个block到位，do_prepare了，但紧接着本地另外一个区块建立了呢，不会，这意味着收到了两个不同的pre-prepare
    # 首先判断要执行的事务是否是合法的
    # --------------------------------------------
    # 等待补充

    # ---------------------------------------------
    # 可能需加锁
    if matter_hash in global_variables.prepared:
        return
    else:
        global_variables.prepared.add(matter_hash)

    # # print(f"{configuration.NAME} pre_prepared, do prepare for iteration{sequence}")
    prepare = PBFT.ConsensusPrepare(uuid=configuration.ID,
                                    operation=matter['operation'],
                                    operation_data=matter['operation_data'],
                                    involved_request_hashes=matter['involved_request_hashes'],
                                    prev_block_hash=matter['prev_block_hash'],
                                    matter_hash=matter_hash,
                                    view=view,
                                    sequence=sequence,
                                    time_stamp=matter['time_stamp'],
                                    relay_time_stamp=time.time()).toJson()
    signature = sign(data=prepare, key_path=configuration.KEY)
    data_to_send = json.dumps({"uuid": configuration.ID,
                               "data": prepare,
                               "signature": signature})

    # message_item = Message_item(source=configuration.ID,
    #                             time_stamp=datetime.now(),
    #                             typ=PBFT.MessageType.PREPARE,
    #                             message_text=data_to_send,
    #                             view=view,
    #                             sequence=sequence,
    #                             corresponding_matter_hash=matter_hash,
    #                             prev_block_hash=matter['prev_block_hash']
    #                             )
    # db.session.add(message_item)
    # db.session.commit()

    # prepares = Message_item.query.filter(Message_item.view == view,
    #                                      Message_item.sequence == sequence,
    #                                      Message_item.type == PBFT.MessageType.PREPARE,
    #                                      Message_item.corresponding_matter_hash == matter_hash).with_for_update()
    # prepares.update({Message_item.handled: True})
    # prepares = len(prepares.all())
    # db.session.commit()
    #
    # matter_item = ConsensusMatter_item.query.filter(ConsensusMatter_item.view == view,
    #                                                 ConsensusMatter_item.prev_block_hash == matter['prev_block_hash']). \
    #     with_for_update().first()
    # matter_item.prepares_collected = prepares
    # if prepares >= 2 * PBFT.ConsensusStatus.f:
    #     matter_item.is_prepared = True
    #     db.session.commit()
    #     do_commit(matter, matter_hash, data, view, sequence)
    # else:
    #     db.session.commit()

    # executor.submit(broadcast_callback,
    #                 host_list=configuration.MINER_HOST_LIST,
    #                 msg=data_to_send,
    #                 url="/peer/handlePrepare",
    #                 including_self=True,
    #                 log="prepare")
    # ws_broadcast(ips=configuration.MINER_HOST_LIST,
    #              event='prepare',
    #              msg=data_to_send)
    executor.submit(ws_broadcast,
                    ips=configuration.MINER_HOST_LIST,
                    event='prepare',
                    msg=data_to_send,
                    excluding_self=False)
    return {
        "status": "async success",
        "msg": "The replica server has been sending prepare msgs on the request"
    }


def do_commit(matter, matter_hash, data, view, sequence):
    # 这一事务的入口有两个，要么在执行do_prepare后进入，此时节点认为自己新收集了一个pre-prepare, 且prepares已经到位，进行do_commit，
    # 要么在handle prepare后进入， 此时既有preprepare也有prepare
    # 可能需加锁
    if matter_hash in global_variables.committed:
        return
    else:
        global_variables.committed.add(matter_hash)

    # # print(f"{configuration.NAME} prepared, do commit for iteration{sequence}")
    commit = PBFT.ConsensusCommit(uuid=configuration.ID,
                                  operation=matter['operation'],
                                  operation_data=matter['operation_data'],
                                  involved_request_hashes=matter['involved_request_hashes'],
                                  prev_block_hash=matter['prev_block_hash'],
                                  matter_hash=matter_hash,
                                  view=view,
                                  sequence=sequence,
                                  time_stamp=matter['time_stamp'],
                                  relay_time_stamp=time.time()).toJson()
    signature = sign(data=commit, key_path=configuration.KEY)
    data_to_send = json.dumps({"uuid": configuration.ID,
                               "data": commit,
                               "signature": signature})

    # message_item = Message_item(source=configuration.ID,
    #                             time_stamp=datetime.now(),
    #                             typ=PBFT.MessageType.COMMIT,
    #                             message_text=data_to_send,
    #                             view=view,
    #                             sequence=sequence,
    #                             corresponding_matter_hash=matter_hash,
    #                             prev_block_hash=matter['prev_block_hash']
    #                             )
    # db.session.add(message_item)
    # db.session.commit()
    #
    # commits = Message_item.query.filter(Message_item.view == view,
    #                                     Message_item.sequence == sequence,
    #                                     Message_item.type == PBFT.MessageType.COMMIT,
    #                                     Message_item.corresponding_matter_hash == matter_hash).with_for_update()
    # commits.update({Message_item.handled: True})
    # commits = len(commits.all())
    # db.session.commit()
    #
    # matter_item = ConsensusMatter_item.query.filter(ConsensusMatter_item.view == view,
    #                                                 ConsensusMatter_item.prev_block_hash == matter['prev_block_hash']). \
    #     with_for_update().first()
    # matter_item.commits_collected = commits
    #
    # if commits >= 2 * PBFT.ConsensusStatus.f + 1:
    #     matter_item.is_committed = True
    #     db.session.commit()
    #     do_execute_block(view, sequence, matter, matter_hash)
    # else:
    #     db.session.commit()
    #     pass

    # executor.submit(broadcast_callback,
    #                 host_list=configuration.MINER_HOST_LIST,
    #                 msg=data_to_send,
    #                 url="/peer/handleCommit",
    #                 including_self=True,
    #                 log="commit")

    # ws_broadcast(ips=configuration.MINER_HOST_LIST,
    #              event='commit',
    #              msg=data_to_send)
    executor.submit(ws_broadcast,
                    ips=configuration.MINER_HOST_LIST,
                    event='commit',
                    msg=data_to_send,
                    excluding_self=False)
    return {
        "status": "async success",
        "msg": "The server has been sending commit msgs on the request"
    }


def do_execute_block(view, sequence, matter, matter_hash):
    # matter_item = ConsensusMatter_item.query.filter(ConsensusMatter_item.view == view,
    #                                                 ConsensusMatter_item.prev_block_hash == matter['prev_block_hash']). \
    #     with_for_update().first()
    # if matter_item.executed is True:
    #     db.session.commit()
    #     return
    # matter_item.executed = True
    # db.session.commit()
    if matter_hash in global_variables.executed:
        return
    else:
        global_variables.executed.add(matter_hash)
    # # print(f"{configuration.NAME} committed, do execute for iteration{sequence}")
    block_lock.acquire()
    # agent_request_lock.acquire()
    # matter = {
    #     'operation': data['operation'],
    #     'operation_data': data['operation_data'],
    #     'involved_request_hashes': data['involved_request_hashes'],
    #     'prev_block_hash': data['prev_block_hash'],
    #     'time_stamp': data['time_stamp']
    # }
    try:
        logging.debug(f"进入执行状态, 事务操作为{matter['operation']}，  iteration：{sequence}")
        if matter['operation'] == PBFT.MessageType.CONSENSUS_GENESIS:
            block_candidate = GenesisBLock()
            height = 0
            primary_id = configuration.MINER_ID_LIST[view % PBFT.ConsensusStatus.n]
            matter_item = global_variables.consensus_matter_pool[sequence][primary_id]
            # matter_item = ConsensusMatter_item.query.filter(ConsensusMatter_item.matter_hash == matter_hash,
            #                                                 ConsensusMatter_item.view == PBFT.ConsensusStatus.view,
            #                                                 ConsensusMatter_item.sequence == PBFT.ConsensusStatus.sequence) \
            #     .first()
            block_candidate.allocation = matter['operation_data']
            # involved_requests = [global_variables.agent_request_pool[height][_]
            #                      for _ in matter['involved_request_hashes']]
            involved_requests = global_variables.packaged_request_pool[height]

            # AgentRequest_item.query.filter(
            #     AgentRequest_item.request_hash.in_(matter['involved_request_hashes'])).all()

            # for each_request in involved_requests:
            #     with open(f'genesis_info/{each_request.request_hash}.pkl', 'wb') as file:
            #         block_candidate.formulations[each_request.uuid] = json.loads(pickle.load(file))
            # block_candidate.formulations = {each_request.uuid: each_request.data for each_request in involved_requests}
            for each_request in involved_requests:
                # data_body = each_request.data
                with open(f'genesis_info/{each_request.request_hash}.pkl', 'rb') as file:
                    data_body = json.loads(pickle.load(file))
                    block_candidate.formulations[each_request.uuid] = data_body
            block_string = json.dumps(block_candidate.__dict__, sort_keys=True, cls=BlockEncoder)
            # with open('genesis_block_string.txt', 'w') as file:
            #     file.write(block_string)
            # logging.debug(f"block_string_size = {len(block_string)}")
            prev_hash = ''
            block_hash = hashlib.sha256(block_string.encode()).hexdigest()
            # block = Block_item(height=height,
            #                    block=None,
            #                    block_type='genesis',
            #                    prev_hash='',
            #                    block_hash=block_hash,
            #                    matter=matter_item)
            global_variables.tip_block = block_candidate
            global_variables.tip_block_hash = block_hash
            # db.session.add(block)
            # try:
            #     db.session.commit()
            # except Exception as e:
            #     # print(f"迭代{PBFT.ConsensusStatus.sequence}, 提交区块失败， rollback")
            #     db.session.rollback()
        else:
            height = PBFT.ConsensusStatus.sequence
            block_candidate = Block(height=PBFT.ConsensusStatus.sequence, previous_hash='')
            primary_id = configuration.MINER_ID_LIST[view % PBFT.ConsensusStatus.n]
            matter_item = global_variables.consensus_matter_pool[sequence][primary_id]
            prev_hash = matter['prev_block_hash']

            # matter_item = ConsensusMatter_item.query.filter(ConsensusMatter_item.matter_hash == matter_hash,
            #                                                 ConsensusMatter_item.view == PBFT.ConsensusStatus.view,
            #                                                 ConsensusMatter_item.sequence == PBFT.ConsensusStatus.sequence) \
            #     .first()
            # db.session.commit()
            block_candidate.allocation = matter['operation_data']
            # # print(f'{len(matter["involved_request_hashes"])} involved hashes for iteration {height}')
            ll = len(configuration.DES_ID_LIST)
            for _i, _j in zip(range(ll), range(ll, 2 * ll)):
                # involved_request = AgentRequest_item.query.filter(
                #     AgentRequest_item.request_hash == matter['involved_request_hashes'][_i]).first()
                # involved_solution = AgentRequest_item.query.filter(
                #     AgentRequest_item.request_hash == matter['involved_request_hashes'][_j]).first()
                try:
                    # involved_request = global_variables.agent_request_pool[height][
                    #     matter['involved_request_hashes'][_i]]
                    # involved_solution = global_variables.agent_request_pool[height][
                    #     matter['involved_request_hashes'][_j]]
                    involved_request = global_variables.packaged_request_pool[height][_i]
                    involved_solution = global_variables.packaged_request_pool[height][_j]
                except Exception as e:
                    print("在消息表中没有消息！！！！")
                block_candidate.solutions[involved_request.uuid] = involved_solution.data['result']
                block_candidate.formulations[involved_request.uuid] = involved_request.data['a']

            block_string = json.dumps(block_candidate.__dict__, sort_keys=True, cls=BlockEncoder)
            block_hash = hashlib.sha256(block_string.encode()).hexdigest()
            # block = Block_item(height=height,
            #                    block=None,
            #                    block_type='normal',
            #                    prev_hash=prev_hash,
            #                    block_hash=block_hash,
            #                    matter=matter_item)
            # with open(f'block_data/block-{PBFT.ConsensusStatus.sequence}.txt', 'w') as file:
            #     file.write(block_string)
            global_variables.tip_block = block_candidate
            global_variables.tip_block_hash = block_hash
            # db.session.add(block)
            # try:
            #     db.session.commit()
            # except Exception as e:
            #     # print(f"迭代{PBFT.ConsensusStatus.sequence}, 提交区块失败， rollback")
            #     db.session.rollback()

        PBFT.ConsensusStatus.sequence += 1
    except Exception as e:
        print(f"do execute block中的exception: {str(e)}")
    finally:
        # agent_request_lock.release()
        block_lock.release()

    # # print(f"{configuration.NAME} executed, do solving callback for {sequence}")
    # solving_callback()

    from chainnode.modules.ws_action_module.ws_actions import broadcast_all
    if block_candidate.height == 0:
        for each_key in block_candidate.formulations.keys():
            formulation = block_candidate.formulations[each_key]
            msg_to_worker = json.dumps({"uuid": each_key,
                                        "formulation": formulation})
            broadcast_all(event='broadcast_block', data=msg_to_worker, namespace='/worker')
    else:
        msg_to_worker = json.dumps({"iteration":PBFT.ConsensusStatus.sequence})
        broadcast_all(event='broadcast_iteration', data=msg_to_worker, namespace='/worker')

    # signature = sign(data=block_hash, key_path=configuration.KEY)
    # executor.submit(solving_callback)

    block_candidate.formulations = None
    block_string = json.dumps(block_candidate.__dict__, sort_keys=True, cls=BlockEncoder)
    msg = json.dumps({"uuid": configuration.ID,
                      "block_hash": 'block_hash',
                      "block_string": block_string,
                      "signature": '',  # signature,
                      "height": height})
    # with open('last_block.txt', "w") as file:
    #     file.write(msg)

    # executor.submit(broadcast_callback,
    #                 host_list=configuration.DES_HOST_LIST,
    #                 msg=msg,
    #                 url="/block_listening",
    #                 log='向客户端广播区块',
    #                 including_self=False,
    #                 protocol="https")

    executor.submit(ws_broadcast_to_DES,
                    ips=configuration.DES_HOST_LIST,
                    event='new_block_listening',
                    msg=msg)
    logging.debug(f"{configuration.NAME} executed, do execute callback for {sequence}")
    # execute_callback(prev_block_hash=prev_hash,
    #                  block_hash=block_hash,
    #                  view=view,
    #                  sequence=PBFT.ConsensusStatus.sequence)

    executor.submit(execute_callback,
                    prev_block_hash=prev_hash,
                    block_hash=block_hash,
                    view=view,
                    sequence=PBFT.ConsensusStatus.sequence)
    # # print("msg_to_worker:", msg_to_worker)
    return 0


def execute_callback(prev_block_hash, block_hash, view, sequence):
    # 修改对应事务的log
    old_iteration = PBFT.ConsensusStatus.sequence - 10
    # print(f"执行callback， sequence+1 ={PBFT.ConsensusStatus.sequence}")
    if old_iteration >= 1:
        global_variables.agent_request_pool[old_iteration] = None
        global_variables.peer_pre_prepare_pool[old_iteration] = None
        global_variables.peer_prepare_pool[old_iteration] = None
        global_variables.peer_commit_pool[old_iteration] = None

    extend_pool(global_variables.consensus_matter_pool, global_variables.consensus_matter_lock, sequence)

    # 如果本节点就是主节点
    if configuration.MINER_HOST_LIST[PBFT.ConsensusStatus.view % PBFT.ConsensusStatus.n] \
            == configuration.MY_HOST:
        from chainnode.modules.agent_module import doPrePrepareNormal
        doPrePrepareNormal(sequence=PBFT.ConsensusStatus.sequence)
        # if PBFT.ConsensusStatus.sequence >= 30:
        #     sequence = PBFT.ConsensusStatus.sequence
        #     time.sleep(PBFT.ConsensusStatus.block_timeout)
        #     doPrePrepareNormal(timeout_execution=True, sequence=sequence)
        return
    else:
        pass
    # 找寻以当前block为prev_block的新事务。

    current_primary_id = configuration.MINER_ID_LIST[view % PBFT.ConsensusStatus.n]
    if not (current_primary_id in global_variables.consensus_matter_pool[sequence].keys()):
        # print(f"迭代{PBFT.ConsensusStatus.sequence}: callback未找到主节点{current_primary_id}的pre_prepare")
        return
    # print(f"迭代{PBFT.ConsensusStatus.sequence}: callback找到事务")
    matter_item = global_variables.consensus_matter_pool[sequence][current_primary_id]
    matter_item.prev_block_committed = True
    # # print(matter_item.sequence, ' ', PBFT.ConsensusStatus.sequence)
    assert matter_item.sequence == PBFT.ConsensusStatus.sequence

    global_variables.peer_prepare_lock.acquire()
    matter_item.prepares_collected = 0
    for key in global_variables.peer_prepare_pool[sequence].keys():
        global_variables.peer_prepare_pool[sequence][key].handled = True
        matter_item.prepares_collected += 1
    global_variables.peer_prepare_lock.release()

    global_variables.peer_commit_lock.acquire()
    matter_item.commits_collected = 0
    for key in global_variables.peer_commit_pool[sequence].keys():
        global_variables.peer_commit_pool[sequence][key].handled = True
        matter_item.commits_collected += 1
    global_variables.peer_commit_lock.release()

    # # print(f"迭代{PBFT.ConsensusStatus.sequence}: execute回调处理区块要求, 查找到事务，准备do_prepare")
    return do_prepare(matter=matter_item.matter,
                      matter_hash=matter_item.matter_hash,
                      data=None,
                      view=matter_item.view,
                      sequence=matter_item.sequence)


def register(app):
    app.register_blueprint(peer_blueprint)
