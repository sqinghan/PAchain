from flask import Blueprint

peer_blueprint = Blueprint('peer_blueprint', __name__, url_prefix='/peer')

from .peer import *