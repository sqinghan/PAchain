import logging
from chainnode.config import configuration
from tcping import *
from chainnode.data.database.status_db import Database_status_item

import requests
import json


class MyPing(Ping):
    def ping(self, count=10):
        for n in range(1, count + 1):
            s = self._create_socket(socket.AF_INET, socket.SOCK_STREAM)
            try:
                time.sleep(1)
                cost_time = self.timer.cost(
                    (s.connect, s.shutdown),
                    ((self._host, self._port), None))
                s_runtime = 1000 * cost_time
                self._conn_times.append(s_runtime)
            except socket.timeout:
                self._failed += 1

            except KeyboardInterrupt:
                self.statistics(n - 1)
                raise KeyboardInterrupt()

            else:
                self._successed += 1
            finally:
                s.close()
        self.statistics(n)


def ping_to_peer(is_online):
    for each_host in configuration.MINER_HOST_LIST:
        if each_host == configuration.MY_HOST:
            continue
        host, port = each_host.split(":",1)
        ping = Ping(host, port)
        try:
            ping.ping(1)
            ret = ping.result.rows[0].success_rate
            if float(ping.result.rows[0].success_rate.strip('%')) > 50:
                is_online[each_host] = True
            else:
                is_online[each_host] = False
        except Exception:
            is_online[each_host] = False
    return 0


def check_genesis(app, db, lock, scheduler):
    lock.acquire()
    with app.app.app_context():
        cursor = Database_status_item.query
        prepared = cursor.first().genesis_prepared
        cursor.update({Database_status_item.genesis_in_preparation: prepared})
        db.session.commit()
    lock.release()
    if prepared is True:
        scheduler.remove_job('check_genesis')
