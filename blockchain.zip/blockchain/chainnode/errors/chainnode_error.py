

class ConflictMessageError(Exception):
    def __init__(self, source, typ, view, prev_hash, sequence):
        self.message = f"来自{source},视图号{view}前值hash{prev_hash}计划序列号{sequence}的{typ}消息" \
                       f"与Message数据库中的其他同来源条目冲突, 冲突在于的事务操作hash或序列号！"


class RepeatedMessageException(Exception):
    def __init__(self, source, typ, view, prev_hash, sequence):
        self.message = f"来自{source},视图号{view}前值hash{prev_hash}计划序列号{sequence}的{typ}消息与" \
                       f"Message数据库中的其他同来源条目重复，已忽略！"


class ConflictMatterError(Exception):
    def __init__(self, source, typ, view, prev_hash, sequence):
        self.message = f"来自{source},视图号{view}前值hash{prev_hash}计划序列号{sequence}的{typ}消息与" \
                       f"Matter数据库中根据主节点记录的Prepare条目冲突！冲突在于冲突的事务操作hash或序列号"

