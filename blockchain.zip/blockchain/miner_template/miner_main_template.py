import asyncio

from chainnode.config import configuration
from chainnode.data import global_variables
import logging
import configparser
from chainnode import *
import click
from envparse import env
import os


logging.basicConfig(level=logging.WARNING)
parser = configparser.ConfigParser()
path = 'personal_settings.ini'

parser.read(path)
configuration.FLASK_ENV = 'development'
configuration.NAME = parser['personal_info']['name']
configuration.ID = parser['personal_info']['uuid']
configuration.CERT = parser['key_info']['cert']
configuration.KEY = parser['key_info']['key']
configuration.CERT_PATH = parser['key_info']['cert_path']
configuration.HOST = parser['personal_info']['ip']
configuration.HOST_PORT = eval(parser['personal_info']['port'])
configuration.MINER_NAME_LIST = eval(parser['peer_info']['miner_name_list'])
configuration.MINER_HOST_LIST = eval(parser['peer_info']['miner_host_list'])
configuration.MINER_ID_LIST = eval(parser['peer_info']['miner_id_list'])
configuration.WORKER_NAME_LIST = eval(parser['peer_info']['worker_name_list'])
configuration.WORKER_HOST_LIST = eval(parser['peer_info']['worker_host_list'])
configuration.WORKER_ID_LIST = eval(parser['peer_info']['worker_id_list'])
configuration.DES_NAME_LIST = eval(parser['peer_info']['DES_name_list'])
configuration.DES_HOST_LIST = eval(parser['peer_info']['DES_host_list'])
configuration.DES_ID_LIST = eval(parser['peer_info']['DES_id_list'])

configuration.MY_HOST = f'{configuration.HOST}:{configuration.HOST_PORT}'
configuration.USERNAME = parser['personal_info']['db_username']
configuration.DATABASE = parser['personal_info']['db_database']
configuration.PASSWD = '123456'
configuration.DB_URI = "mysql+pymysql://{username}:{passwd}@{host}:{port}/{db}?charset=utf8".format(
    username=configuration.USERNAME,
    passwd=configuration.PASSWD,
    host=configuration.HOST, port=configuration.PORT, db=configuration.DATABASE)
configuration.SQLALCHEMY_DATABASE_URI = configuration.DB_URI
# configuration.PEER_CERT_LIST = [('../certs/chainnode1-cert/chainnode1.crt',]


@click.command()
@click.option('-n', '--name', help='chainnode_name', default=configuration.NAME, show_default=True)
@click.option('-u', '--uuid', help='uuid', default=configuration.ID, show_default=True)
@click.option('-h', '--host', help='Bind host', default=configuration.HOST, show_default=True)
@click.option('-p', '--port', help='Bind port', default=configuration.HOST_PORT, type=int, show_default=True)
@click.option('-e', '--env', help='Running env, override environment FLASK_ENV.', default='development',
              show_default=True)
@click.option('-f', '--env-file', help='Environment from file', type=click.Path(exists=True))
@click.option('-r', '--restart', help='Restart from existing blockchain', default=True)
@click.option('-c', '--cert', help='certificate file', default=configuration.CERT)
@click.option('-k', '--key', help='key file', default=configuration.KEY)
def main(**kwargs):
    if kwargs['env_file']:
        env.read_envfile(kwargs['env_file'])

    configuration.MY_HOST = f"{kwargs['host']}:{kwargs['port']}"
    configuration.CERT = kwargs['cert']
    configuration.KEY = kwargs['key']
    myMiner = Chainnode(name=kwargs['name'],
                        uuid=kwargs['uuid'],
                        env=kwargs['env'],
                        conf=configuration)

    import subprocess as sp
    if os.path.exists("genesis_info"):
        sp.call(["rmdir", "/s", "/q", "genesis_info"], shell=True)
    sp.call(["mkdir", "genesis_info"], shell=True)
    try:
        global_variables.event_loop = asyncio.get_event_loop()
    except Exception as e:
        global_variables.event_loop = asyncio.new_event_loop()
        asyncio.set_event_loop(global_variables.event_loop)
    print(kwargs['cert'], kwargs['key'])
    myMiner.run(host=kwargs['host'], port=kwargs['port'], ssl_context=(kwargs['cert'], kwargs['key']), threaded=True)
    # myMiner.socketio.run(myMiner.app, host=kwargs['host'], port=kwargs['port'], ssl_context=(kwargs['cert'], kwargs['key']), allow_unsafe_werkzeug=True)


if __name__ == '__main__':
    main()
