import os
import datetime
import uuid


class BaseConfig:
    NAME = "DES_cli"
    ID = uuid.uuid4()
    CERT = None
    KEY = None
    CERT_PATH = ''
    HOST = '127.0.0.1'
    PORT = 3306
    BFT_F = 1

    CA_FILE = '../certs/ca-cert/ca.crt'

    MINER_NAME_LIST = []
    MINER_HOST_LIST = []
    MINER_ID_LIST = []
    WORKER_NAME_LIST = []
    WORKER_HOST_LIST = []
    WORKER_ID_LIST = []
    NEIGHBOUR_NAME_LIST = []
    NEIGHBOUR_HOST_LIST = []



registered_modules = []
