from .config import *
from .logger import config_logger

configuration = BaseConfig

"""
Config 文件
存储配置
"""