import logging

import requests
import json

def register_to_peer(host, appClass):
    try:
        response = requests.get("http://"+host+"/peer/query",
                                 data=json.dumps({
                                     "uuid":appClass.uuid
                                 }))
    except Exception as e:
        logging.debug("query host exception:%s"%str(e))
        return
    response_dict = json.loads(response.content.decode())
    try:
        # print("STATUS:%s     MSG:%s"%(response_dict["status"],response_dict["msg"]))
        if response_dict["status"] == "success" and response_dict["msg"] == "True":
            appClass.scheduler.remove_job("register_"+host)
            # print("JOB REMOVED!!!!!!")
        else:
            # print("准备注册！！！")
            response = requests.post("http://" + host + "/peer/register",
                                     data=json.dumps({
                                         "name": appClass.name,
                                         "uuid": appClass.uuid,
                                         "pubkey": appClass.conf.PK
                                     }))

    except Exception as e:
        pass

    return response