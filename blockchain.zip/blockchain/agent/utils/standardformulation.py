import json
import hashlib
import numpy

class StandardFormulation:
    def __init__(self, H, A, b, G, h):
        if isinstance(H, numpy.ndarray):
            self.H = H.tolist()
            self.A = A.tolist()
            self.b = b.tolist()
            self.G = None if G is None else G.tolist()
            self.h = None if h is None else h.tolist()
        else:
            self.H = H
            self.A = A
            self.b = b
            self.G = G
            self.h = h

    @classmethod
    def compute_hash(cls, formulation):
        formulation_string = json.dumps(formulation.__dict__, sort_keys=True)
        return hashlib.sha256(formulation_string.encode()).hexdigest()
