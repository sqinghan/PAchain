import numpy as np
from Crypto.PublicKey import RSA
from Crypto.Signature import PKCS1_v1_5
from Crypto.Hash import SHA, SHA256
import base64


def sign(data, sk, hash_func=None):
    hash_data = SHA.new(data.encode())
    prikey = RSA.importKey(sk)
    signature = PKCS1_v1_5.new(prikey).sign(hash_data)
    return base64.b64encode(signature).decode()

def verify_signature(data, pk, signature):
    hash_data = SHA.new(data.encode())
    pubkey = RSA.importKey(pk)
    is_verify = PKCS1_v1_5.new(pubkey).verify(hash_data, base64.b64decode(signature.encode()))
    return is_verify
