import logging
import asyncio
import httpx
from agent.config import configuration
import ssl


async def broadcast(host_list=None, msg=None, url="/", log=None, including_self=False, protocol='https'):
    context = ssl.create_default_context(cafile=configuration.CA_FILE)
    # context = ssl.create_default_context()
    # L = [broadcast_each(index, host, msg, url, context, log, including_self) for index, host in enumerate(host_list)]
    L = await asyncio.gather(*[broadcast_each(host, msg, url, context, log, including_self, protocol)
                               for host in host_list])


async def broadcast_each(host=None, msg=None, url="/", context=None, log=None, including_self=False, protocol='https'):
    # from chainnode.data.global_variables import is_online
    # if is_online[host]:
    #     pass
    # else:
    #     return 0
    if host == configuration.MY_HOST and including_self is False:
        return 0
    async with httpx.AsyncClient(timeout=None, verify=context) as client:
        if log is not None:
            logging.info("broadcasting info:%s; host:%s" % (log, host))
        try:
            resp = await client.post(protocol + '://' + host + url, data=msg)
            # result = resp.text
            logging.info("broadcasting result:%s from host %s" % (str(resp), host))
        except httpx.ConnectError as e:
            logging.info(e)


def broadcast_callback(host_list=None, msg=None, url="/", log=None, including_self=False, protocol='https'):
    asyncio.run(broadcast(
        host_list=host_list,
        msg=msg,
        url=url,
        log=log,
        including_self=including_self,
        protocol=protocol))