import asyncio
import hashlib
import ssl
# import io
# import random
import threading
from collections import Counter
# from datetime import datetime

# import matplotlib.pyplot as plt
# import rsa
# from configparser import ConfigParser
import time
import json
import logging

import aiohttp
import socketio

import PBFT
# import agent.settings
# import cvxpy as cp
import numpy as np
# from Crypto.PublicKey import RSA
# from Crypto.Signature import PKCS1_v1_5
# from Crypto.Hash import SHA, SHA256
import base64
from flask import Flask, request, render_template
import os
from agent import config
import importlib
import OpenSSL
from flask_executor import Executor
from flask_socketio import SocketIO
# import ssl
from agent.utils.broadcastutils import broadcast_callback


class FlaskSioClient:
    def __init__(self, conf):
        configuration = self.configuration = conf
        self.ssl_context = ssl.create_default_context()
        self.ssl_context.load_verify_locations(configuration.CERT_PATH + '/ca.crt')
        # self.connector = aiohttp.TCPConnector(ssl=self.ssl_context)
        self.connector = aiohttp.TCPConnector(verify_ssl=False)
        self.http_session = aiohttp.ClientSession(connector=self.connector)
        self.sio = socketio.AsyncClient(http_session=self.http_session)

        @self.sio.event(namespace='/DES')
        def connect():
            print(f'connection established: {self.sio.connection_url}')

        @self.sio.event(namespace='/DES')
        async def redirect_message_to_handler(data):
            print(data)

        @self.sio.event(namespace='/DES')
        def disconnect():
            print('disconnected from server')



def register_logger():
    log_level = os.environ.get('LOG_LEVEL') or 'INFO'
    log_file = os.environ.get('LOG_FILE') or 'agent.log'
    config.config_logger(
        enable_console_handler=True,
        enable_file_handler=False,
        log_level=log_level,
        log_file=log_file
    )


class Agent:
    app = None
    app_name = 'agent'

    def __init__(self, conf=config.BaseConfig):
        """

        :param conf:  Config object
        """
        # initialize logger
        register_logger()

        self.conf = conf

        self.name = conf.NAME
        self.uuid = conf.ID
        logging.debug("个体名称:%s, uuid: %s" % (self.name, self.uuid))

        self.cert_path = conf.CERT
        self.key_path = conf.KEY
        self.lock = threading.Lock()
        logging.debug("读取个人公钥身份...")
        try:
            cert_file = open(self.cert_path, "r")
            key_file = open(self.key_path, "r")
            self.cert = cert_file.read()
            self.cert = OpenSSL.crypto.load_certificate(OpenSSL.crypto.FILETYPE_PEM, self.cert)
            self.key = key_file.read()
            self.key = OpenSSL.crypto.load_privatekey(OpenSSL.crypto.FILETYPE_PEM, self.key)
            cert_file.close()
            key_file.close()
        except FileNotFoundError as e:
            logging.error("个人证书和密钥文件读取错误")

        logging.debug("个人公钥读取完成, 生成个人身份信息")
        self.personal_info = {"name": self.name,
                              "uuid": self.uuid,
                              "cert": self.cert}
        logging.debug("个人信息:%s" % str(self.personal_info))

        self.genesis_formulation = None
        self.executor = Executor()
        self.socketio = SocketIO()
        self.neighbours = None
        self.peers = None
        self.create_agent(conf=conf)
        self.height_of_peer_blocks = {}
        self.log_dict = {}
        self.blocks = {}
        self.stable_height = -1
        self.applied_height = np.zeros(1005)
        self.Pgen = []
        self.Qgen = []
        self.u = []
        self.time_consumption = []
        self.p1 = 0
        self.p2 = 0
        self.p1_last = 0
        self.p2_last = 0

        self.Cij_list = []
        self.lij_list = []
        self.Cji_list = []
        self.ly = 0
        self.ll = 0
        self.a0 = 0
        self.z = 0
        self.last_proposal_time = 0
        self.rho = 5
        self.solutions = []
        self.x_average = dict()
        self.y_average = dict()
        self.N = 0
        self.x = 0
        self.H_ori = 0
        self.c_ori = 0
        self.last_x = 0
        self.primal_residuals = []
        self.dual_residuals = []
        self.connections = None
        self.event_loop = None
        self.event_loop_lock = threading.Lock()
        self.miners_connected = []
        self.connection_id_map = dict()
        self.id_connection_map = dict()
        self.costs = []
        self.prox = 0

    def create_agent(self, conf=config.BaseConfig):
        """
        :param
        conf: config
        object,
        :return:
        """
        # check instance path
        instance_path = os.environ.get('INSTANCE_PATH') or None
        # create and configure the app
        self.app = Flask(__name__, instance_path=instance_path)
        self.app.config.from_object(conf)
        self.conf = conf
        # ensure the instance folder exists
        if self.app.instance_path:
            try:
                os.makedirs(self.app.instance_path)
            except OSError:
                pass
        # register app
        self.executor.init_app(self.app)
        self.socketio.init_app(self.app)
        self.register_modules()

        @self.app.route("/block_listening", methods=["POST"])
        def listen_blocks(msg=None):
            # from random import random
            # time.sleep(random()*0.05)
            request_msg = msg or request.data.decode("utf-8")
            request_in_dict = json.loads(request_msg)
            uuid = request_in_dict['uuid']
            block_string = request_in_dict['block_string']
            block_hash = hashlib.sha256(block_string.encode()).hexdigest()  # request_in_dict['block_hash']
            logging.info(f"listen block from {uuid}, hash={block_hash}, height={request_in_dict['height']}")
            try:
                index: int = conf.MINER_ID_LIST.index(uuid)
            except Exception as e:
                return dict(status="failed")

            height = request_in_dict['height']

            self.lock.acquire()
            if (index, height) in self.log_dict.keys():
                return dict(status="failed")
            self.log_dict[(index, height)] = 1
            if height not in self.height_of_peer_blocks.keys():
                self.height_of_peer_blocks[height] = Counter()
            self.height_of_peer_blocks[height][block_hash] += 1
            # logging.info(f"认为高度{height},hash为{block_hash}的票数为{self.height_of_peer_blocks[height][block_hash]}")
            if self.height_of_peer_blocks[height][block_hash] == conf.BFT_F + 1:
                if height > self.stable_height and self.applied_height[height + 1] == 0:
                    self.applied_height[height + 1] = 1
                    self.stable_height = height
                    # self.blocks[block_hash] = block_string
                    self.executor.submit(self.propose_new_request, height + 1, block_string)
            self.lock.release()
            return dict(status="success")

        @self.app.route("/", methods=["GET"])
        def index_page():
            with open("ans.txt", "w") as file:
                for i in range(500):
                    file.writes(f'{self.Pgen[i]} ')

            return {"Hello World!"}

        @self.socketio.on('connect', namespace='/miner_DES_channel')  # 有客户端连接会触发该函数
        def on_connection_of_miners(auth):
            # 建立连接 sid:连接对象ID
            # return False
            client_id = request.sid
            auth_id = json.loads(auth)['uuid']
            print(
                f'new connection, connection id=[{client_id}], miner id={auth_id} try to connect to MINER-DES channel...')
            if auth_id in self.conf.MINER_ID_LIST:
                print(
                    f'new connection, connection id=[{client_id}], miner id={auth_id} accepted')
                self.miners_connected.append(auth_id)
                print(f'Now have {len(self.miners_connected)} miners')
                self.connection_id_map[client_id] = auth_id
                self.id_connection_map[auth_id] = client_id
            else:
                print(
                    f'new connection, connection id=[{client_id}], id={auth_id} rejected')
                return False
            print("connection created successfully")
            return True

        @self.socketio.on('disconnect', namespace='/miner_DES_channel')
        def on_disconnection_of_miners():
            miner_id = self.connection_id_map[request.sid]
            self.miners_connected.remove(miner_id)
            print(f'connection id={request.sid}, miner id={miner_id}'
                  f' exited, now have {len(self.miners_connected)} miners')
            self.connection_id_map[request.sid] = None
            self.id_connection_map[miner_id] = None

        @self.socketio.on('new_block_listening', namespace='/miner_DES_channel')
        def on_listen_blocks(data):
            listen_blocks(msg=data)

    async def async_connect(self, ips, protocol_head='https://', namespaces=None):
        if namespaces is None:
            namespaces = ['/DES']
        tasks = []
        if not self.connections:
            self.connections = [FlaskSioClient(self.conf) for _ in self.conf.MINER_HOST_LIST]

        try:
            for client, ip in zip(self.connections, ips):
                tasks.append(asyncio.create_task(client.sio.connect(protocol_head + ip,
                                                                    namespaces=namespaces,
                                                                    auth=json.dumps({'uuid': self.uuid}))))
            await asyncio.gather(*tasks)
        except Exception as e:
            print(e)

    async def __ws_broadcast__(self, ips, event, msg, namespace=None):
        tasks = []
        try:
            for client, ip in zip(self.connections, ips):
                tasks.append(asyncio.create_task(client.sio.emit(event, msg, namespace)))
            await asyncio.gather(*tasks)
        except Exception as e:
            print(e)

    def ws_broadcast(self, ips=None, event=None, msg=None, namespace=None, protocol_head='https'):
        if namespace is None:
            namespace = '/DES'
        need_to_connect = False
        if self.connections:
            for each in self.connections:
                if each.sio.connected is False:
                    need_to_connect = True
        else:
            need_to_connect = True
        loop = self.event_loop
        asyncio.set_event_loop(loop)

        if need_to_connect:
            print("Create DES client connections!")
            loop.run_until_complete(self.async_connect(ips))
            if self.connections:
                for each in self.connections:
                    print(each.sio.connected, end=' ')
        try:
            self.event_loop_lock.acquire()
            loop.run_until_complete(self.__ws_broadcast__(ips, event, msg, namespace))
            self.event_loop_lock.release()
        except Exception as e:
            print(e)

    def propose_new_request(self, target_height, block_string):
        # 从区块链获取上次计算结果
        # 本地计算下一次的a
        # 广播solving request

        # logging.info(f"准备提交求解请求,目标区块高度{target_height}, 区块{block_string}")
        block = json.loads(block_string)

        target_solver = 0
        for each_solver in block['allocation'].keys():
            if self.uuid in block['allocation'][each_solver]:
                target_solver = each_solver
                break

        if target_height == 1:
            self.last_proposal_time = time.time()
            a = self.a0 + 0
        else:
            this_proposal_time = time.time()
            self.time_consumption += [this_proposal_time - self.last_proposal_time]
            self.last_proposal_time = this_proposal_time

            recovered_solution = self.N @ np.array(block["solutions"][self.uuid][2]) + self.x
            if not (self.uuid in self.x_average.keys()):
                self.x_average[self.uuid] = [recovered_solution]
                self.y_average[self.uuid] = [np.array(block["solutions"][self.uuid][2])]
            else:
                self.x_average[self.uuid] += [((target_height - 2) * self.x_average[self.uuid][target_height - 3]
                                               + recovered_solution) / (target_height - 1)]
                self.y_average[self.uuid] += [((target_height - 2) * self.y_average[self.uuid][target_height - 3]
                                               + np.array(block["solutions"][self.uuid][2])) / (target_height - 1)]
            # recovered_solution = self.x_average[self.uuid][target_height - 2]

            recovered_cost = (1/2 * recovered_solution @ self.H_ori @ recovered_solution +
                              self.c_ori @ recovered_solution)

            self.dual_residuals += [max(np.abs(recovered_solution - self.last_x))]
            self.last_x = recovered_solution

            self.solutions += [recovered_solution]
            self.costs += [recovered_cost]
            self.Pgen += [recovered_solution[0:self.T]]
            # self.Qgen += [recovered_solution[1]]
            # self.u += [recovered_solution[4]]
            self.z = 0
            a = self.a0 - self.prox * np.array(block["solutions"][self.uuid][2])
            if target_height >= 2:
                self.p1_last = self.p1
                self.p2_last = self.p2
                self.p1 = []
                self.p2 = []
            for j, neighbour_id in enumerate(self.conf.NEIGHBOUR_ID_LIST):
                # AGENT_NEIGHBOUR在建模时生成。建模时输入所有的Agent list
                # 返回Cij_list和Cji_list和AGENT_NEIGHBOUR
                # 他们长度相同，每一项表示一条邻居的信息，其中Agentneibour表示邻居的iD的编号
                # 可以用来在ID list中找到ID， 从而定位求解
                #
                # neighbour_y = np.array(block["solutions"][neighbour_id][2])
                # neighbour_x = (self.Cji_list[j] @ neighbour_y + self.xj0_list[j])
                #
                # if not (neighbour_id in self.x_average.keys()):
                #     self.x_average[neighbour_id] = [neighbour_x]
                #     self.y_average[neighbour_id] = [neighbour_y]
                # else:
                #     self.x_average[neighbour_id] += [((target_height - 2) * self.x_average[neighbour_id][target_height - 3]
                #                                    + neighbour_x) / (target_height - 1)]
                #     self.y_average[neighbour_id] += [((target_height - 2) * self.y_average[neighbour_id][target_height - 3]
                #                                    + neighbour_y) / (target_height - 1)]

                self.p1 += [(self.Cij_list[j] @ np.array(block["solutions"][self.uuid][2]) + self.xi0_list[j])]
                self.p2 += [(self.Cji_list[j] @ np.array(block["solutions"][neighbour_id][2]) + self.xj0_list[j])]

                # self.p1 += [(self.Cij_list[j] @ self.y_average[self.uuid][target_height - 2] + self.xi0_list[j])]
                # self.p2 += [(self.Cji_list[j] @ self.y_average[neighbour_id][target_height - 2] + self.xj0_list[j])]

                if target_height >= 3:
                    # self.lij_list[j] += self.rho / 1.8 * (self.p1[j] - self.p2[j] + self.p1_last[j] - self.p2_last[j])
                    self.lij_list[j] += self.rho / 2 * (self.p1[j] - self.p2[j])
                else:
                    self.lij_list[j] += self.rho / 2 * (self.p1[j] - self.p2[j])
                a += self.Cij_list[j].T @ (self.lij_list[j] + self.rho * self.xi0_list[j] - self.rho * (self.p1[j] + self.p2[j])/2)
                self.primal_residuals += [max(np.abs(self.p1[j] - self.p2[j]))]


            # if self.conf.PORT == 5060:
            #     print(f'迭代{target_height}预处理完成')
        if target_height == 500 and self.conf.PORT != 5050:
            with open("ans.txt", "w") as file:
                file.write('x = ' + str(self.solutions[-1]) + '\n')
                file.write(f'N = {str(self.N)}, y = {str(block["solutions"][self.uuid][2])}, x0 = {str(self.x)}\n')
                father = self.conf.NEIGHBOUR_ID_LIST[0]
                file.write(
                    f'cifxi = {self.Cij_list[0] @ np.array(block["solutions"][self.uuid][2]) + self.xi0_list[0]},'
                    f'cfixf = {self.Cji_list[0] @ np.array(block["solutions"][father][2]) + self.xj0_list[0]}\n')

            with open("Pgen.txt", 'w') as file:
                file.write("Primal_residuals:\n")
                for each in self.Pgen:
                    for dt in range(self.T):
                        file.write(f'{round(each[dt], 4)} ')
                    file.write('\n')
                file.write("\n")
            with open("Primal_residuals.txt", 'w') as file:
                # file.write("Primal_residuals:\n")
                for each in self.primal_residuals:
                    file.write(f'{each}\n')
            with open("Dual_residuals.txt", 'w') as file:
                # file.write("Dual_residuals:\n")
                for each in self.dual_residuals:
                    file.write(f'{each}\n')
            with open("costs.txt", 'w') as file:
                for each in self.costs:
                    file.write(f'{each}\n')
        req = PBFT.CliRequest(operation=PBFT.MessageType.SOLVING_REQUEST,
                              data=json.dumps({'a': a.tolist(), 'target_solver': target_solver}),
                              time_stamp=time.time(),
                              iteration=target_height,
                              uuid=self.uuid,
                              comm=f"{self.conf.NAME}'s message for iteration{target_height}").toJson()
        signature = self.sign(req)
        data_to_send = json.dumps({"uuid": self.uuid,
                                   "data": req,
                                   "signature": signature,
                                   "cli_type": "DES"})
        # logging.info(f"准备广播求解请求,目标区块高度{target_height}")
        # self.executor.submit(broadcast_callback,
        #                      host_list=self.conf.MINER_HOST_LIST,
        #                      msg=data_to_send,
        #                      url="/agent/request",
        #                      log='submit_solving_request')
        # broadcast_callback(host_list=self.conf.MINER_HOST_LIST,
        #                    msg=data_to_send,
        #                    url="/agent/request",
        #                    log="submit_solving_request")

        self.executor.submit(self.ws_broadcast,
                             ips=self.conf.MINER_HOST_LIST,
                             event='solving_request',
                             msg=data_to_send)

    def register_modules(self):
        for each_module_string in config.registered_modules:
            module = importlib.import_module(self.app_name + ".modules." + each_module_string)
            if hasattr(module, 'register'):
                getattr(module, 'register')(self.app)

    @property
    def regis_data(self):
        return self.personal_info

    def initiate_matrix(self):
        pass

    def sign(self, data="", hash_func="sha"):
        """
        对数据hash后用私钥签名。

        :param data: 要签名的数据(str格式) data to be signed(in str)
        :param hash_func:  签名前对数据采用的hash
        :return:
        """
        sig = base64.b64encode(OpenSSL.crypto.sign(self.key, data, "sha1")).decode()
        return sig

    def run(self, host=None, port=None, ssl_context=None, debug=False, load_dotenv=True, **options):
        self.app.run(host, port, debug, load_dotenv, ssl_context=ssl_context)
