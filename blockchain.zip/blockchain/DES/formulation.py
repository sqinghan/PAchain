import cvxpy as cp
import numpy as np

import DES.settings
from chainnode import utils


class Subproblem:
    def __init__(self, n_P=0, n_H=0):
        pass

        self.H = None
        self.a = None
        self.A = None
        self.b = None
        self.G = None
        self.h = None

        self.n_P_neighbours = n_P
        self.n_H_neighbours = n_H

        self.var_P_neighbours = []
        self.var_H_neighbours = []

        self.lijs = []
        self.Cijs = []
        self.rho = 50

    def formulate_standard(self, Cjiys=None):
        pass
        Hp = self.H + self.rho/2 * sum([self.Cijs[k].T @ self.Cijs[k] for k in range(self.n_P_neighbours)])
        # ap = self.a + sum([self.Cijs[k].T @ (self.lijs[k] - rho * Cjiys[k]) for k in range(self.n_P_neighbours)])
        Ap = self.A
        bp = self.b
        Gp = self.G
        hp = self.h
        return utils.StandardFormulation(Hp, Ap, bp, Gp, hp)


class DefaultSubproblem_PQ_2(Subproblem):
    def __init__(self):
        super().__init__(n_P=1, n_H=0)
        I = np.eye(DES.T)
        Z = np.zeros((DES.T, DES.T))
        R = I * 0.005
        X = I * 0.005
        e1 = np.ones(DES.T)
        e0 = np.zeros(DES.T)
        # [Pg, Qg, Pi, Qi, ui, uf]
        self.A = np.vstack([np.hstack([I, Z, I, Z, Z, Z]),
                            np.hstack([Z, I, Z, I, Z, Z]),
                            np.hstack([Z, Z, 2 * R, 2 * X, I, -I])])
        self.b = np.hstack([e1,
                            e1,
                            e0])
        self.G = np.vstack([np.eye(6*DES.T),-np.eye(6*DES.T)])
        self.h = np.hstack([10*e1, 10*e1, 100*e1, 100*e1, 1.1025*e1, 1.1025*e1,
                            0*e1, 0*e1, 100*e1, 100*e1, -0.9025*e1, -0.9025*e1])
        self.H = np.diag(
            (np.vstack([100 * e1, 100 * e1, 0.0 * e1, 0.0 * e1, 0.0 * e1, 0.0 * e1])).reshape(6 * DES.T))
        self.a = np.hstack([e1 * 400, e0, e0, e0, e0, e0])
        self.Cijs = [np.vstack([np.hstack([Z, Z, Z, Z, Z, I]),
                                np.hstack([Z, Z, I, Z, Z, Z]),
                                np.hstack([Z, Z, Z, I, Z, Z])])
                     ]

        self.Cjis = [np.vstack([np.hstack([Z, Z, Z, Z, I, Z, Z, Z, Z]),
                                np.hstack([Z, Z, Z, Z, Z, I, Z, Z, Z]),
                                np.hstack([Z, Z, Z, Z, Z, Z, I, Z, Z])]),
                     ]

        self.lijs = [np.hstack([e0,
                                e0,
                                e0])
                     ]
        self.standard_formulation = self.formulate_standard()


class DefaultSubproblem_VT(Subproblem):
    def __init__(self):
        super().__init__(n_P=2, n_H=0)
        I = np.eye(DES.T)
        Z = np.zeros((DES.T, DES.T))
        R = I * 0.005
        X = I * 0.005
        e1 = np.ones(DES.T)
        e0 = np.zeros(DES.T)
        # [Pg, Qg, Pi, Qi, ui, Pc1, Qc1, Pc2, Qc2]
        self.A = np.vstack([np.hstack([I, Z, I, Z, Z, -I, Z, -I, Z]),
                            np.hstack([Z, I, Z, I, Z, Z, -I, Z, -I]),
                            np.hstack([Z, Z, Z, Z, I, Z, Z, Z, Z]),
                            np.hstack([Z, Z, I, Z, Z, Z, Z, Z, Z]),
                            np.hstack([Z, Z, Z, I, Z, Z, Z, Z, Z])])
        self.b = np.hstack([e0,
                            e0,
                            e1,
                            e0,
                            e0])
        self.G = np.vstack([np.eye(9 * DES.T), -np.eye(9 * DES.T)])
        self.h = np.hstack([10 * e1, 10 * e1, 100 * e1, 100 * e1, 100 * e1, 100 * e1, 100 * e1, 100 * e1, 100 * e1,
                            0 * e1, 0 * e1, 100 * e1, 100 * e1, 100 * e1, 100 * e1, 100 * e1, 100 * e1, 100 * e1])
        self.H = np.diag((np.vstack(
            [100 * e1, 100 * e1, 0.0 * e1, 0.0 * e1, 0.0 * e1, 0.0 * e1, 0.0 * e1, 0.0 * e1,
             0.01 * e1])).reshape(9 * DES.T))
        self.a = np.hstack([e1 * 400, e0, e0, e0, e0, e0, e0, e0, e0])
        self.Cijs = [np.vstack([np.hstack([Z, Z, Z, Z, I, Z, Z, Z, Z]),
                                np.hstack([Z, Z, Z, Z, Z, I, Z, Z, Z]),
                                np.hstack([Z, Z, Z, Z, Z, Z, I, Z, Z])]),
                     np.vstack([np.hstack([Z, Z, Z, Z, I, Z, Z, Z, Z]),
                                np.hstack([Z, Z, Z, Z, Z, Z, Z, I, Z]),
                                np.hstack([Z, Z, Z, Z, Z, Z, Z, Z, I])]),
                     ]
        self.Cjis = [np.vstack([np.hstack([Z, Z, Z, Z, Z, I]),
                                np.hstack([Z, Z, I, Z, Z, Z]),
                                np.hstack([Z, Z, Z, I, Z, Z])]),
                     np.vstack([np.hstack([Z, Z, Z, Z, Z, I, Z, Z]),
                                np.hstack([Z, Z, I, Z, Z, Z, Z, Z]),
                                np.hstack([Z, Z, Z, I, Z, Z, Z, Z])]),
                     ]
        self.lijs = [-np.hstack([e0,
                                e0,
                                e0]),
                     -np.hstack([e0,
                                e0,
                                e0])
                     ]
        self.standard_formulation = self.formulate_standard()


class DefaultSubproblem_PQ_3(Subproblem):
    def __init__(self):
        super().__init__(n_P=2, n_H=0)
        I = np.eye(DES.T)
        Z = np.zeros((DES.T, DES.T))
        R = I * 0.005
        X = I * 0.005
        e1 = np.ones(DES.T)
        e0 = np.zeros(DES.T)
        # Pg, Qg, Pi, Qi, ui, uf, Ps, Qs
        self.A = np.vstack([np.hstack([I, Z, I, Z, Z, Z, -I, Z]),
                            np.hstack([Z, I, Z, I, Z, Z, Z, -I]),
                            np.hstack([Z, Z, 2 * R, 2 * X, I, -I, Z, Z])])
        self.b = np.hstack([e1,
                            e1,
                            e0])
        self.G = np.vstack([np.eye(8 * DES.T), -np.eye(8 * DES.T)])
        self.h = np.hstack([10 * e1, 10 * e1, 100 * e1, 100 * e1, 1.1025 * e1, 1.1025 * e1, 100 * e1, 100 * e1,
                            0 * e1, 0 * e1, 100 * e1, 100 * e1, -0.9025 * e1, -0.9025 * e1, 100 * e1, 100 * e1])
        self.H = np.diag((np.vstack(
            [100 * e1, 100 * e1, 0.0 * e1, 0.0 * e1, 0.0 * e1, 0.0 * e1, 0.0 * e1, 0.0 * e1])).reshape(
            8 * DES.T))
        self.a = np.hstack([e1 * 400, e0, e0, e0, e0, e0, e0, e0])
        self.Cijs = [np.vstack([np.hstack([Z, Z, Z, Z, Z, I, Z, Z]),
                                np.hstack([Z, Z, I, Z, Z, Z, Z, Z]),
                                np.hstack([Z, Z, Z, I, Z, Z, Z, Z])]),
                     np.vstack([np.hstack([Z, Z, Z, Z, I, Z, Z, Z]),
                                np.hstack([Z, Z, Z, Z, Z, Z, I, Z]),
                                np.hstack([Z, Z, Z, Z, Z, Z, Z, I])])
                     ]

        self.Cjis = [np.vstack([np.hstack([Z, Z, Z, Z, I, Z, Z, Z, Z]),
                                np.hstack([Z, Z, Z, Z, Z, Z, Z, I, Z]),
                                np.hstack([Z, Z, Z, Z, Z, Z, Z, Z, I])]),
                     np.vstack([np.hstack([Z, Z, Z, Z, Z, I]),
                                np.hstack([Z, Z, I, Z, Z, Z]),
                                np.hstack([Z, Z, Z, I, Z, Z])])
                     ]

        self.lijs = [np.hstack([e0,
                                e0,
                                e0]),
                     np.hstack([e0,
                                e0,
                                e0])
                     ]
        self.standard_formulation = self.formulate_standard()


class DefaultSubproblem_PQ_4(Subproblem):
    def __init__(self):
        super().__init__(n_P=1, n_H=0)
        I = np.eye(DES.T)
        Z = np.zeros((DES.T, DES.T))
        R = I * 0.005
        X = I * 0.005
        e1 = np.ones(DES.T)
        e0 = np.zeros(DES.T)
        # [Pg, Qg, Pi, Qi, ui, uf]
        self.A = np.vstack([np.hstack([I, Z, I, Z, Z, Z]),
                            np.hstack([Z, I, Z, I, Z, Z]),
                            np.hstack([Z, Z, 2 * R, 2 * X, I, -I])])
        self.b = np.hstack([e1,
                            e1,
                            e0])
        self.G = np.vstack([np.eye(6 * DES.T), -np.eye(6 * DES.T)])
        self.h = np.hstack([10 * e1, 10 * e1, 100 * e1, 100 * e1, 1.1025 * e1, 1.1025 * e1,
                            0 * e1, 0 * e1, 100 * e1, 100 * e1, -0.9025 * e1, -0.9025 * e1])
        self.H = np.diag(
            (np.vstack([100 * e1, 100 * e1, 0.0 * e1, 0.0 * e1, 0.0 * e1, 0.0 * e1])).reshape(6 * DES.T))
        self.a = np.hstack([e1 * 400, e0, e0, e0, e0, e0])
        self.Cijs = [np.vstack([np.hstack([Z, Z, Z, Z, Z, I]),
                                np.hstack([Z, Z, I, Z, Z, Z]),
                                np.hstack([Z, Z, Z, I, Z, Z])])
                     ]

        self.Cjis = [np.vstack([np.hstack([Z, Z, Z, Z, I, Z, Z, Z]),
                                np.hstack([Z, Z, Z, Z, Z, Z, I, Z]),
                                np.hstack([Z, Z, Z, Z, Z, Z, Z, I])])
                     ]

        self.lijs = [np.hstack([e0,
                                e0,
                                e0])
                     ]
        self.standard_formulation = self.formulate_standard()