import asyncio
import hashlib
import logging
import threading
import time
from collections import Counter
from concurrent.futures import ThreadPoolExecutor
import socketio
import json
import configparser
import httpx
import requests
import cvxpy as cp
import numpy as np
import aiohttp
import ssl

logging.basicConfig(level=logging.INFO, format='%(asctime)s %(message)s', datefmt='%Y/%m/%d %H:%M:%S')


class Model:
    def __init__(self, H, G, h):
        self.H = np.array(H)
        # self.A = np.array(A)
        # self.b = np.array(b)
        self.G = np.array(G) if G is not None else None
        self.h = np.array(h) if G is not None else None
        self.a = None
        self.y = None
        # self.equ_cons = []
        self.ieq_cons = []
        self.problem = None
        self.solved = False

    def update_model(self, a):
        if self.a is None:
            self.a = cp.Parameter((self.H.shape[0]))
        if isinstance(a, list):
            self.a.value = np.array(a)
        elif isinstance(a, np.ndarray):
            self.a.value = a
        self.solved=False

    def formulate(self):
        self.y = cp.Variable(self.H.shape[0])
        self.solved = False
        if self.a is None:
            return False
        # self.equ_cons = [self.A @ self.y == self.b]
        if self.G is not None:
            self.ieq_cons = [self.G @ self.y <= self.h]

        self.problem = cp.Problem(cp.Minimize(1/2 * cp.quad_form(self.y, self.H) + self.a.T @ self.y),
                                  self.ieq_cons)
        return True

    def solve(self):
        if self.problem is None:
            res = self.formulate()
            if res is False:
                return res
        if self.solved is False:
            st = time.time()
            # time.sleep(0.01)
            self.problem.solve(solver=cp.GUROBI)
            ed = time.time()
            # logging.info(self.problem.status)
            # logging.info(ed-st)
            self.solved = True
        if self.G is not None:
            if self.problem.status == "optimal" or self.problem.status == "optimal_inaccurate":
                return (self.problem.status,
                        self.problem.value,
                        self.y.value.tolist(),
                        # self.equ_cons[0].dual_value.tolist(),
                        self.ieq_cons[0].dual_value.tolist())
            else:
                return (None,
                        None)
        else:
            if self.problem.status == "optimal" or self.problem.status == "optimal_inaccurate":
                return (self.problem.status,
                        self.problem.value,
                        self.y.value.tolist(),
                        # self.equ_cons[0].dual_value.tolist(),
                        None)
            else:
                return (None,
                        None)

    def __str__(self):
        return str(self.problem.value)


class MyConfig:
    pass


class WorkingDST:
    pass


def hashmd5(st):
    """
    返回str型的md5 hash,输入可以为byte或str
    :param st:
    :return:
    """
    if isinstance(st, str):
        st = st.encode()
    md = hashlib.md5(st)
    return md.hexdigest()


configuration = MyConfig
dst = WorkingDST

parser = configparser.ConfigParser()
path = 'personal_settings.ini'
parser.read(path)

configuration.NAME = parser['personal_info']['name']
configuration.ID = parser['personal_info']['uuid']
configuration.HOST = parser['personal_info']['ip']
configuration.CERT = parser['key_info']['cert']
configuration.KEY = parser['key_info']['key']
configuration.CERT_PATH = parser['key_info']['cert_path']
configuration.MINER_NAME_LIST = eval(parser['peer_info']['miner_name_list'])
configuration.MINER_HOST_LIST = eval(parser['peer_info']['miner_host_list'])
configuration.MINER_ID_LIST = eval(parser['peer_info']['miner_id_list'])
configuration.DES_NAME_LIST = eval(parser['peer_info']['DES_name_list'])
configuration.DES_ID_LIST = eval(parser['peer_info']['DES_id_list'])
configuration.WINDOW = 100
configuration.F = 1

# http_session = requests.Session()
# http_session.verify = configuration.CERT_PATH + '/ca.crt'
# sio = socketio.Client(http_session=http_session)

dst.broadcast_log = dict()
dst.votes_on_iterations = Counter()
dst.current_iteration = 0
dst.prepare_iteration = 0
dst.accepted_ids = set()
dst.problem_pool = dict()
dst.current_view = 0
dst.executor = ThreadPoolExecutor(max_workers=4)
dst.clients = []
dst.solving_lock = threading.Lock()
dst.handled_requests = set()


async def async_connect(clients, ips, protocal_head='https://'):
    tasks = []
    try:
        for client, ip in zip(clients,ips):
            tasks.append(asyncio.create_task(client.sio.connect(protocal_head + ip,
                                       namespaces=['/worker'], auth=json.dumps({'uuid': configuration.ID}))))
        await asyncio.gather(*tasks)
    except Exception as e:
        print(e)

    tasks = []
    # await client.connect(protocal_head + ip, )
    for client in clients:
        tasks.append(asyncio.create_task(client.sio.wait()))
    await asyncio.gather(*tasks)
    # await clients[0].sio.wait()


async def async_broadcast(clients, event, message, namespace):
    tasks = []
    try:
        for client in clients:
            tasks.append(client.sio.emit(event, message, namespace))
        await asyncio.gather(*tasks)
    except Exception as e:
        print(e)


class MyClient:
    def __init__(self):
        self.ssl_context = ssl.create_default_context()
        self.ssl_context.load_verify_locations(configuration.CERT_PATH + '/ca.crt')
        print(configuration.CERT_PATH + '/ca.crt')
        self.connector = aiohttp.TCPConnector(ssl_context=self.ssl_context)
        self.connector = aiohttp.TCPConnector(verify_ssl=False)
        self.http_session = aiohttp.ClientSession(connector=self.connector)
        self.sio = socketio.AsyncClient(http_session=self.http_session)

        @self.sio.event(namespace='/worker')
        def connect():
            print(f'connection established: {self.sio.connection_url}')

        @self.sio.on('solving_request', namespace='/worker')
        async def handle_solving_request(data):
            # verify signature
            # verify signature

            # print("I received a request!")
            request_hash = hashmd5(data)

            dst.solving_lock.acquire()
            if request_hash in dst.handled_requests:
                # print('The worker has dealt with the request already!')
                print("I reject a request!")
                return None
            dst.handled_requests.add(request_hash)
            dst.solving_lock.release()

            resolved_dict = json.loads(json.loads(data)['data'])
            uuid = resolved_dict['uuid']
            iteration = resolved_dict['iteration']

            if iteration <= dst.current_iteration - 2:
                # print("I reject a request!")
                return None
            # print(f'The worker is dealing with the request {uuid} in iteration{iteration}!')
            a = json.loads(resolved_dict['data'])['a']
            while True:
                if uuid in dst.problem_pool.keys():
                    dst.problem_pool[uuid].update_model(np.array(a))
                    break
                else:
                    await asyncio.sleep(0.1)
            # dst.executor.submit(solve_and_return, {'uuid': uuid, 'request_hash': request_hash,
            #                                        'iteration': iteration, 'master_copy': data})
            solve_and_return(uuid=uuid, request_hash=request_hash, master_copy=data, iteration=iteration)
            return 'The worker has accepted the solving request'

        @self.sio.on('broadcast_block', namespace='/worker')
        def handle_block_broadcasts(data):
            resolved_dict = json.loads(data)
            data_hash = hashmd5(data)
            uuid = resolved_dict['uuid']
            server = self.sio.connection_url
            if not (uuid in dst.broadcast_log.keys()):
                dst.broadcast_log[uuid] = set()
            if server in dst.broadcast_log[uuid]:
                return False
            else:
                dst.votes_on_iterations[data_hash] += 1
                dst.broadcast_log[uuid].add(server)
            if dst.votes_on_iterations[data_hash] == configuration.F + 1:
                dst.problem_pool[uuid] = Model(H=resolved_dict['formulation']['H'],
                                               G=resolved_dict['formulation']['G'],
                                               h=resolved_dict['formulation']['h'])
                print("successfully analyze formulation info!")
            return True

        @self.sio.on('broadcast_iteration', namespace='/worker')
        def handle_iteration(data):
            resolved_dict = json.loads(data)
            if resolved_dict['iteration'] > dst.current_iteration:
                dst.current_iteration = resolved_dict['iteration']
            return True

        @self.sio.event(namespace='/worker')
        def disconnect():
            print('disconnected from server')

        def solve_and_return(uuid=None, request_hash=None, master_copy=None, iteration=0):
            # print(f"I'm solving the request of {uuid}")
            if iteration <= dst.current_iteration - 2:
                print("I reject a request!")
                return 0
            result = dst.problem_pool[uuid].solve()
            # print("I handled a request!")
            data = json.dumps({'type': 10,
                               'operation': 3,
                               'data': json.dumps({"requestor": uuid,
                                                   "master_copy": master_copy,
                                                   "solving_request_hash": request_hash,
                                                   "result": result}),
                               'iteration': iteration,
                               'comm': f'{configuration.ID}\'s solution to iteration {iteration} of DES {uuid}',
                               'uuid': configuration.ID,
                               'solving_request_hash': request_hash,
                               'time_stamp': time.time()
                               })
            ans_string = json.dumps({'uuid': configuration.ID,
                                     'data': data,
                                     'type': 'solution'})
            # print(ans_string)
            # print("I have solved the request")
            coro = async_broadcast(dst.clients, 'solving_solution', ans_string, '/worker')
            # dst.loop.run_until_complete(coro)
            try:
                 coro.send(None)
            except Exception as e:
                print(e)


loop = asyncio.get_event_loop()
dst.loop = loop
dst.clients = [MyClient() for _ in configuration.MINER_HOST_LIST]
loop.run_until_complete(async_connect(clients=dst.clients,
                                      ips=configuration.MINER_HOST_LIST))
# asyncio.run(async_connect(configuration.MINER_HOST_LIST[0]))
print("000")

ut = 1
# 向服务端发送消息
# sio.emit('message', ut)
# sio.wait()




# connector = aiohttp.TCPConnector(ssl=False)
# http_session = aiohttp.ClientSession(connector=connector)
# sio = socketio.AsyncClient(http_session=http_session)
#
# @sio.event
# async def connect():
#     print('connection established')
#
# @sio.on("message")
# async def my_message(data):
#     print('message received with ', data)
#     await sio.emit('message', {'response': 'my response'})
#
# @sio.event
# async def disconnect():
#     print('disconnected from server')
#
# async def main():
#     await sio.connect('wss://127.0.0.1:5000')
#     await sio.wait()
#
# if __name__ == '__main__':
#     loop = asyncio.get_event_loop()
#     loop.run_until_complete(main())
#     # asyncio.run(main())