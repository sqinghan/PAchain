from DES import DefaultSubproblem_VT

defaultProblem_1 = DefaultSubproblem_VT()