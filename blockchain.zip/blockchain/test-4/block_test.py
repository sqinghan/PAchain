from block import Block, Blockchain
import logging

logging.basicConfig(level=logging.DEBUG)

logging.log(logging.DEBUG, "Block测试开始")
myBlock = Block(-1, 0, None)
myChain = Blockchain(create_new_chain=True)
logging.log(logging.DEBUG, "Block测试结束")