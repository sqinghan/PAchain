import time

import numpy as np
import cvxpy as cp
import gurobipy as gp


def calculate_cpu_time(func):
    def wrapper(*args, **kwargs):
        start_cpu = time.process_time()
        result = func(*args, **kwargs)
        end_cpu = time.process_time()
        print(func.__name__, "CPU Time:", end_cpu - start_cpu)
        return result
    return wrapper

H = np.loadtxt("H1.txt")
c = np.loadtxt("c1.txt")
A = np.loadtxt("A2.txt")
b = np.loadtxt("b2.txt")
G = np.loadtxt("G2.txt")
h = np.loadtxt("h2.txt")

Hmsk = np.loadtxt("Hmsk1.txt")
amsk = np.loadtxt("amsk1.txt")
Gmsk = np.loadtxt("Gmsk2.txt")
hmsk = np.loadtxt("hmsk2.txt")

x = cp.Variable(H.shape[0])
c_p = cp.Parameter(len(c), value=c)
pb = cp.Problem(cp.Minimize(1/2 * cp.quad_form(x, H) + c_p @ x), [A @ x == b, G @ x <= h])

print("Wall Time 统计")
st = time.time()
m = gp.Model()
m.setParam("OutputFlag", 0)
y = m.addMVar((H.shape[0],), )
m.addConstr(A @ y == b)
m.addConstr(G @ y <= h)
m.setMObjective(H/2, c, 0)
m.optimize()
ed = time.time()
print(ed - st)

# c_p.value *= 2
# st = time.time()
# pb.solve(solver=cp.GUROBI, ignore_dpp=False)
# ed = time.time()
# print(ed - st)


# # 计算矩阵的特征值和特征向量
# eigenvalues, eigenvectors = np.linalg.eig(Hmsk)
#
# # 构造对角矩阵
# diagonal_matrix = np.zeros((len(eigenvalues), len(eigenvalues)))
# for i in range(len(eigenvalues)):
#     diagonal_matrix[i][i] = eigenvalues[i]
# amsk = amsk @ eigenvectors.T
# Gmsk = Gmsk @ eigenvectors.T

x = cp.Variable(Hmsk.shape[0])
c_p = cp.Parameter(len(amsk), value=amsk)
pb = cp.Problem(cp.Minimize(1/2 * np.diag(Hmsk) @ x ** 2 + c_p @ x), [Gmsk @ x <= hmsk])

print("Wall Time 统计")
st = time.time()
m = gp.Model()
m.setParam("OutputFlag", 0)
y = m.addMVar((Hmsk.shape[0],), )
m.addConstr(Gmsk @ y <= hmsk)
m.setMObjective(Hmsk/2, amsk, 0)
m.optimize()
ed = time.time()
print(ed - st)

# c_p.value *= 2
# st = time.time()
# pb.solve(solver=cp.GUROBI, ignore_dpp=False)
# ed = time.time()
# print(ed - st)
