import pickle
import sys
import time
import os

import pandas as pd
from matplotlib import pyplot as plt

from autonomous_optimization.libs.formulation import generate_standard_form, DecentralizationTool
from autonomous_optimization.data.data import pload_ref, qload_ref, hload_ref, res_ref, pqh_coeff
import numpy as np
import cvxpy as cp
import autonomous_optimization.libs.formulation as formulation

class DataContainer_Liaoning_Yingkou_Bayuquan:
    def __init__(self, date=1, non_coop=0):
        self.P_ref = 1
        self.V_ref = 1000
        self.I_ref = self.P_ref / self.V_ref
        self.R_ref = self.V_ref / self.I_ref
        self.solar_list = []
        self.wind_list = []
        self.gen_list = []
        self.bat_list = []
        T = formulation.T
        self.n_neighbours = []
        data_name = "Data.xlsx"
        self.date = f"---------------110{date+2}----------------"
        print(self.date)
        data_excel = pd.read_excel(data_name, sheet_name="Bus&Ids")
        connection_excel = pd.read_excel(data_name, sheet_name="Connections")
        RX = [pd.read_excel(data_name, sheet_name="Type1").values,
              pd.read_excel(data_name, sheet_name="Type2").values,
              pd.read_excel(data_name, sheet_name="Type3").values]
        self.pload = pload = pd.DataFrame(pd.read_csv(f"load/pload{date}.csv", header=None)).values * 0.9
        self.qload = qload = pd.DataFrame(pd.read_csv(f"load/qload{date}.csv", header=None)).values
        self.solar = solar = pd.DataFrame(pd.read_csv(f"res/solar{date}.csv", header=None)).values * 1
        self.wind = wind = pd.DataFrame(pd.read_csv(f"res/wind{date}.csv",header=None)).values
        self.n = data_excel.values.shape[0]
        connections = connection_excel.values
        to_grid_list = 0

        self.flags = []
        print(f"平均电负荷:{np.average(sum(pload))}")
        print(f"总可再生:{np.sum(sum(solar) + sum(wind))}")
        print(f"平均可再生:{np.average(sum(solar) + sum(wind))}")
        # plt.plot(sum(pload))
        # plt.plot(sum(wind) + sum(solar))
        # plt.show()

        solar_rank = 0
        wind_rank = 0
        self.data_dict_list = []
        for i in range(self.n):
            st = time.time()
            neighbours = []
            Rs = []
            Xs = []
            for connection in connections:
                if connection[0] == i or connection[1] == i:
                    neighbours += [connection[0] + connection[1] - i]
                    Rs += [RX[connection[3] - 1][0][0] * connection[2] / self.R_ref]
                    Xs += [RX[connection[3] - 1][0][1] * connection[2] / self.R_ref]
            res = [False, 0, 0]
            to_grid = True
            if data_excel.values[i][2] == 'yes':
                res[0] = True
                res[1] += solar[solar_rank][:T]
                if data_excel.values[i][6] == 'yes':
                    to_grid = True
                if to_grid:
                    to_grid_list += solar[solar_rank][:T]
                solar_rank += 1
                self.solar_list += [i]
            if data_excel.values[i][3] == 'yes':
                res[0] = True
                res[1] += wind[wind_rank][:T]
                if data_excel.values[i][6] == 'yes':
                    to_grid = True
                if to_grid:
                    to_grid_list += wind[wind_rank][:T]
                wind_rank += 1
                self.wind_list += [i]

            self.n_neighbours += [len(neighbours)]

            batt = [False, 0, 0, 0, 0.9, 0.9]  # 充电功率上限，放电功率上限，容量，充电效率，放电效率
            if not np.isnan(data_excel.values[i][4]):
                batt[0] = True
                batt[1] = float(data_excel.values[i][4]) / 2
                batt[2] = float(data_excel.values[i][4]) / 2
                batt[3] = float(data_excel.values[i][4])
                self.bat_list += [i]

            cogen = [False, 0, 0, 0, 0,]  # 下限、上限，功率因数tan、热电比
            c_cogen = [0, 0]
            if not np.isnan(data_excel.values[i][5]):
                cogen[0] = True
                cogen[1] = 0.7 * float(data_excel.values[i][5])
                cogen[2] = 1 * float(data_excel.values[i][5])
                cogen[3] = 0.5
                # pload[i] -= 0.3 * float(data_excel.values[i][5])
                self.gen_list += [i]
            # false_prop = 1.3 if i == 5 else 1
            false_prop = 1
            if cogen[0]:
                if cogen[2] >= 0.15:
                    c_cogen = [308.31*1.5, 356.22*1.5]
                    c_cogen = [462.16, 534.33]
                    # 719.1
                    # c_cogen = [462.16*1.3, 534.33*1.3]
                else:
                    c_cogen = [297.87*1.5, 324.63*1.5]
                    c_cogen = [446.81, 594.95]
                    # 684.3
                    # c_cogen = [446.81*1.3, 594.95*1.3]
                    # c_cogen = [297.87*1.5*1.2, 324.63*1.5*1.2]


            hp = (False, 0, 0),  # 上限， COP
            heatsto = (False, 0, 0, 0, 0.00),  # 储热上限，放热上限，容量，漏热率
            c_res = [10, 10]
            c_uppergrid = [np.array([510, 510, 510, 510, 510, 780,
                            780, 1020, 1020, 1020, 510, 510,
                            780, 780, 780, 780, 1020, 1020,
                            1020, 1020, 1020, 780, 510, 510]).repeat(4), 300]
            # c_uppergrid = [510, 510]
            self.price = c_uppergrid[0]
            self.c_uppergrid = c_uppergrid
            # print(i, ":", neighbours)
            self.non_coop = non_coop

            st_form, flag = generate_standard_form(len(neighbours), neighbours,
                                                           pload[i][:T], qload[i][:T], pload[i][:T]*0,
                                                           rlist=Rs, xlist=Xs,
                                                           ptype="VT" if i == 0 else "PQ",
                                                           tendency=1,
                                                           res=res,
                                                           cogen=cogen,
                                                           hp=hp,
                                                           batt=batt,
                                                           heatsto=heatsto,
                                                           c_res=c_res,
                                                           c_cogen=c_cogen,
                                                           c_uppergrid=c_uppergrid,
                                                           non_coop=non_coop,
                                                           comm="",
                                                           false_prop=false_prop,
                                                           to_grid=1,#(to_grid | non_coop)
                                                           )
            self.data_dict_list += [st_form]
            self.flags += [flag]
            ed = time.time()
            # print(ed - st)

        print(f"负荷低谷:{np.min(sum(pload))}")
        print(f"可再生峰值:{np.max(sum(solar) + sum(wind))}")
        print(f"目前允许全额上网可再生峰值:{np.max(to_grid_list)}")
        self.DES_id_list = [i for i in range(self.n)]
        self.DES_name_list = [f"DES{i}" for i in range(self.n)]
        for i, each_item_i in enumerate(self.data_dict_list):
            each_id_i = self.DES_id_list[i]
            for pos_i, j in enumerate(each_item_i['enid']):
                each_id_j = self.DES_id_list[j]
                # j = DES_id_list.index(each_id_j)
                each_item_j = self.data_dict_list[j]
                pos_j = each_item_j['enid'].index(i)
                each_item_j['Cij'][pos_j] = np.array(each_item_j['Cij'][pos_j])
                each_item_j['xi0'][pos_j] = np.array(each_item_j['xi0'][pos_j])
                each_item_i['Cji'] += [each_item_j['Cij'][pos_j]]
                each_item_i['xj0'] += [each_item_j['xi0'][pos_j]]

                each_item_j['Cij_ori'][pos_j] = np.array(each_item_j['Cij_ori'][pos_j])
                each_item_i['Cji_ori'] += [each_item_j['Cij_ori'][pos_j]]





if __name__ == '__main__':
    p_buys = []
    cogens = []
    batts = []
    batt_losses = []
    ress = []
    transaction_cost_upper = 0
    for date in range(7):
        dat = DataContainer_Liaoning_Yingkou_Bayuquan(date)
        tik = time.time()
        decentralization = DecentralizationTool(dat.n, dat, max_ite=1500)
        decentralization.build()
        print("开展集中优化，并输出调度运行情况：")
        decentralization.centralized_dispatch(verbose=False)
        res = 0
        for i in range(decentralization.n):
            if i in dat.solar_list or i in dat.wind_list:
                res += decentralization.X[i][(5 + dat.n_neighbours[i]*2)*formulation.T:
                                             (6 + dat.n_neighbours[i]*2)*formulation.T].value
        print(f"可再生消纳：{sum(res)}")
        p_buys += [decentralization.p_buy]

        p_cogen = 0
        stat_bat = 0
        batt_loss = 0
        res = 0
        for i in range(decentralization.n):
            flag = dat.flags[i]

            st = (5 + dat.n_neighbours[i] * 2) * formulation.T
            ed = st + formulation.T
            if flag[0]:
                res += decentralization.X[i][st:ed].value

            st = (5 + dat.n_neighbours[i] * 2 + flag[0] * 2) * formulation.T
            ed = st + formulation.T
            if flag[1]:
                p_cogen += decentralization.X[i][st:ed].value

            st = (5 + dat.n_neighbours[i] * 2 + flag[0] * 2 + flag[1] * 3 + flag[2] * 2) * formulation.T
            ed = st + formulation.T
            if flag[3]:
                stat_bat += decentralization.X[i][st:ed].value
                batt_loss += decentralization.X[i][st + formulation.T:ed + formulation.T].value -\
                             decentralization.X[i][st + formulation.T*2:ed + formulation.T*2].value

        cogens += [p_cogen]
        batts += [stat_bat]
        batt_losses += [batt_loss]
        ress += [res]
        # plt.plot(p_cogen)
        # plt.title(f"p_cogen cooperation = {1 - dat.non_coop}")
        # plt.show()
        #
        # plt.plot(stat_bat)
        # plt.title(f"stat_bat cooperation = {1 - dat.non_coop}")
        # plt.show()

    p_buys = np.hstack(p_buys)
    cogens = np.hstack(cogens)
    print(f"----------------统计-------------------")
    print(f"可再生发电：{np.sum(ress)}")
    print(f"买电：{np.sum(p_buys)}")
    print(f"发电机发电：{np.sum(cogens)}")
    print(f"电池损耗：{np.sum(batt_losses)}")
    batts = np.hstack(batts)
    plt.plot(p_buys)
    plt.title(f"p_buy cooperation = {1-dat.non_coop}")
    plt.show()
    plt.plot(cogens)
    plt.title(f"cogens cooperation = {1-dat.non_coop}")
    plt.show()

    plt.plot(batts)
    plt.title(f"batts cooperation = {1-dat.non_coop}")
    plt.show()