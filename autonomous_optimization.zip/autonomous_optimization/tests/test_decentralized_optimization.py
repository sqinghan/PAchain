import pickle
import sys
import time
import os

import pandas as pd
from matplotlib import pyplot as plt

from autonomous_optimization.libs.formulation import generate_standard_form, DecentralizationTool
from autonomous_optimization.data.data import pload_ref, qload_ref, hload_ref, res_ref, pqh_coeff
import numpy as np
import cvxpy as cp
import autonomous_optimization.libs.formulation as formulation
from test_base_scenarios_96 import DataContainer_Liaoning_Yingkou_Bayuquan


class DataContainer_test:
    def __init__(self):
        self.data_dict_list = [generate_standard_form(3, [1, 2, 3],
                                                      pqh_coeff[0][0] * pload_ref, pqh_coeff[0][1] * qload_ref,
                                                      pqh_coeff[0][2] * hload_ref,
                                                      ptype='VT',
                                                      c_uppergrid=(550, 200)),  # DES0
                               generate_standard_form(1, [0],
                                                      pqh_coeff[1][0] * pload_ref, pqh_coeff[1][1] * qload_ref,
                                                      pqh_coeff[1][2] * hload_ref,
                                                      cogen=(True, 0.1, 0.5, 0.5, 0),
                                                      batt=(True, 0.1, 0.1, 0.2, 0.9, 0.9),
                                                      c_cogen=(150, 400)),  # DES1

                               generate_standard_form(1, [0],
                                                      pqh_coeff[2][0] * pload_ref, pqh_coeff[2][1] * qload_ref,
                                                      pqh_coeff[2][2] * hload_ref,
                                                      res=(True, res_ref[2], 0.33),
                                                      cogen=(True, 0.25, 1.25, 0.2, 2),
                                                      batt=(True, 0.1, 0.1, 0.2, 0.9, 0.9),
                                                      heatsto=(True, 0.3, 0.3, 1.2, 0.01),
                                                      c_res=(10, 20),
                                                      c_cogen=(150, 400)),  # DES2

                               generate_standard_form(3, [0, 4, 5],
                                                      pqh_coeff[3][0] * pload_ref, pqh_coeff[3][1] * qload_ref,
                                                      pqh_coeff[3][2] * hload_ref,
                                                      cogen=(True, 0.2, 0.8, 0.5, 0),
                                                      batt=(True, 0.1, 0.1, 0.2, 0.9, 0.9),
                                                      c_cogen=(150, 400)),  # DES3

                               generate_standard_form(1, [3],
                                                      pqh_coeff[4][0] * pload_ref, pqh_coeff[4][1] * qload_ref,
                                                      pqh_coeff[4][2] * hload_ref,
                                                      res=(True, res_ref[4], 0.33),
                                                      cogen=(True, 0.25, 1.25, 0.2, 2),
                                                      hp=(True, 0.5, 2),
                                                      c_res=(10, 20),
                                                      c_cogen=(200, 370)),  # DES4

                               generate_standard_form(2, [3, 6],
                                                      pqh_coeff[5][0] * pload_ref, pqh_coeff[5][1] * qload_ref,
                                                      pqh_coeff[5][2] * hload_ref),  # DES 5

                               generate_standard_form(1, [5],
                                                      pqh_coeff[6][0] * pload_ref, pqh_coeff[6][1] * qload_ref,
                                                      pqh_coeff[6][2] * hload_ref,
                                                      res=(True, res_ref[6], 0.33),
                                                      hp=(True, 1.5, 2),
                                                      c_res=(10, 20)),  # DES 6
                               ]

        self.DES_id_list = [i for i in range(7)]
        self.DES_name_list = [f"DES{i}" for i in range(7)]
        for i, each_item_i in enumerate(self.data_dict_list):
            each_id_i = self.DES_id_list[i]
            for pos_i, j in enumerate(each_item_i['enid']):
                each_id_j = self.DES_id_list[j]
                # j = DES_id_list.index(each_id_j)
                each_item_j = self.data_dict_list[j]
                pos_j = each_item_j['enid'].index(i)
                each_item_j['Cij'][pos_j] = np.array(each_item_j['Cij'][pos_j])
                each_item_j['xi0'][pos_j] = np.array(each_item_j['xi0'][pos_j])
                each_item_i['Cji'] += [each_item_j['Cij'][pos_j]]
                each_item_i['xj0'] += [each_item_j['xi0'][pos_j]]


if __name__ == '__main__':
    p_residuals_all = []
    d_residuals_all = []
    costs = []
    for date in range(3,4):
        dat = DataContainer_Liaoning_Yingkou_Bayuquan(date=date)
        tik = time.time()
        decentralization = DecentralizationTool(dat.n, dat, max_ite=1500, cont=(date > 0))
        decentralization.build(dat.price)
        print("开展集中优化，并输出调度运行情况：")
        decentralization.centralized_dispatch(verbose=False)
        if date >= 1:
            with open(f"results{date - 1}.dmp", "rb") as file:
                decentralization_last = pickle.load(file)
            decentralization.lijs = decentralization_last.lijs
            decentralization.zs_copy = decentralization_last.zs_copy
        decentralization.dat = None
        print("开展去中心化优化")
        print(f"开始仿真时间戳:{tik}")

        # with open("results.dmp", "wb") as file:
        #     pickle.dump(decentralization, file)
        # print('\n所有节点乘子(仿真开始前)：')
        # for i, each_item_i in enumerate(decentralization.data_dict_list):
        #     for dt in range(3*formulation.T):
        #         print("%8.4f" % decentralization.lijs[i][0][dt],end=" ")
        #     print()
        # print("sleep 5")
        # time.sleep(5)
        for __ite__ in range(decentralization.max_ite):
            time_ite_start = time.time()
            ti_solve = []
            ti_edge_computing = []
            decentralization.prepare(__ite__)
            rg = range(decentralization.n)
            # rg = range(7,8)
            # X_UPDATE
            for i in rg:
                st = time.time()
                try:
                    decentralization.x_update(i, __ite__)
                except Exception:
                    print(f"求解出错:{i}")
                ed = time.time()
                ti_solve += [ed-st]
            # decentralization.costs += [decentralization.cost.getValue()]
            # decentralization.x_update_manipu(4, __ite__)

            # Z_UPDATE
            for i in rg:
                st = time.time()
                decentralization.z_update(i, __ite__)
                ed = time.time()
                ti_edge_computing += [ed - st]
            ti_solve = np.array(ti_solve)
            ti_edge_computing = np.array(ti_edge_computing)

            ti_final = ti_solve + ti_edge_computing
            ti_final = ti_final.tolist()

            time_ite_end = time.time()
            print("\r", end="")
            # print("迭代次度: {}: ".format(__ite__), "▓" * (__ite__ * 100 // decentralization.max_ite), end="")
            print("迭代次度: {}: ".format(__ite__), "收敛残差：{},  {}".format(decentralization.primal_residuals[-1],decentralization.dual_residuals[-1]),
                  " 最慢求解时间{}:".format(max(ti_final)),
                  " 最慢求解节点:{}".format(ti_final.index(max(ti_final))),
                  " 总求解时间:{}".format(time_ite_end - time_ite_start),
                  end="")
            sys.stdout.flush()
            if decentralization.primal_residuals[-1] <= 1.e-4 and decentralization.dual_residuals[-1] <= 1.e-4:
                break

        tok = time.time()
        print(f"")
        print(f"仿真结束:{tok}")
        print(f"总耗时:{tok-tik}")
        print(f"总成本{decentralization.cost.value}")
        X = []
        for i, each_item_i in enumerate(decentralization.data_dict_list):
            N = np.array(each_item_i['N'])
            x = np.array(each_item_i['x'])
            X.append(N @ decentralization.Y[i].value + x)

        print("总买电:", sum(X[0][0:formulation.T]))
        decentralization.probs = None
        decentralization.targets = decentralization.constraints = decentralization.agg_target = decentralization.agg_constraint = None
        for each in decentralization.a_list:
            each = each.value

        # with open(f"results{date}.dmp", "wb") as file:
        #     pickle.dump(decentralization, file)

        p_residuals_all += decentralization.primal_residuals
        d_residuals_all += decentralization.dual_residuals
        costs += decentralization.costs
    plt.semilogy(p_residuals_all)
    plt.semilogy(d_residuals_all)
    plt.legend(["primal", "dual"])
    plt.axis([0, len(p_residuals_all), 0.0001, 10])
    plt.show()
    plt.plot(costs)
    plt.show()


    #
    print('所有节点发电量：')
    for i, each_item_i in enumerate(decentralization.data_dict_list):
        for dt in range(decentralization.T):
            print("%8.4f" % X[i][dt], end=' ')
        print()
    print('\n所有节点上游功率：')
    for i, each_item_i in enumerate(decentralization.data_dict_list):
        for dt in range(formulation.T):
            print("%8.4f" % X[i][2 * formulation.T + dt], end=' ')
        print()

    print('所有节点成本：')
    for i, each_item_i in enumerate(decentralization.data_dict_list):
        H_before_aug = np.array(each_item_i['H_before_aug'])
        a = np.array(each_item_i['a'])
        const = np.array(each_item_i['const'])
        H_ori = np.array(each_item_i['H_ori'])
        c_ori = np.array(each_item_i['c_ori'])
        a_ori = each_item_i['a_ori']
        c1 = (1 / 2 * cp.quad_form(decentralization.Y[i], H_before_aug) + a @ decentralization.Y[i] + const).value
        c2 = (1 / 2 * cp.quad_form(decentralization.X[i], H_ori) + c_ori @ decentralization.X[i] + a_ori).value

        for pos_i, j in enumerate(each_item_i['enid']):
            p1 = each_item_i['Cij'][pos_i] @ decentralization.Y[i].value + each_item_i['xi0'][pos_i]
            l1 = decentralization.lijs[i][pos_i]
            c2 += p1 @ l1
        print("%10.4f" % c1, end=" ")
        print("%10.4f" % c2)
    # print('\n所有节点乘子：')
    # for i, each_item_i in enumerate(decentralization.data_dict_list):
    #     for dt in range(3*formulation.T):
    #         print("%8.4f" % decentralization.lijs[i][0][dt],end=" ")
    #     print()
    print('\n造假节点乘子：')
    for dt in range(3*formulation.T):
            print("%8.4f" % decentralization.lijs[47][0][dt],end=" ")
    print()
    for dt in range(3*formulation.T):
            print("%8.4f" % decentralization.lijs[42][1][dt],end=" ")
    print()

    #
    # print('\n所有节点电压：')
    # for i, each_item_i in enumerate(decentralization.data_dict_list):
    #     for dt in range(formulation.T):
    #         print("%8.4f" % X[i][4 * formulation.T + dt], end=' ')
    #     print()

    plt.figure()
    plt.semilogy(decentralization.primal_residuals)
    plt.semilogy(decentralization.dual_residuals)
    plt.semilogy(decentralization.combined_residuals)
    plt.legend(["primal residuals", "dual residuals", "combined residual"])
    plt.axis([0, decentralization.max_ite, 0.0001, 10])
    plt.figure()
    plt.plot(decentralization.costs)
    plt.title(f"{decentralization.rho[::formulation.T]}")
    plt.show()

    plt.figure()
    for i, each_item_i in enumerate(decentralization.data_dict_list):
        plt.plot(X[i][:decentralization.T], label=f"Node {i}'s power injection")
    plt.legend()
    plt.axis([0, decentralization.T, -2, 3])
    plt.show()