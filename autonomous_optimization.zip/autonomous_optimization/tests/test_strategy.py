import pickle
import sys
import time
import os

import pandas as pd
from matplotlib import pyplot as plt

from autonomous_optimization.libs.formulation import generate_standard_form, DecentralizationTool
from autonomous_optimization.data.data import pload_ref, qload_ref, hload_ref, res_ref, pqh_coeff
import numpy as np
import cvxpy as cp
import autonomous_optimization.libs.formulation as formulation
from test_base_scenarios_96 import DataContainer_Liaoning_Yingkou_Bayuquan


if __name__ == '__main__':
    transaction_cost_upper = 0
    for date in range(0,7):
        dat = DataContainer_Liaoning_Yingkou_Bayuquan(date, non_coop=1)
        tik = time.time()
        decentralization = DecentralizationTool(dat.n, dat, max_ite=1500)
        decentralization.build()
        print("开展集中优化，并输出调度运行情况：")
        decentralization.centralized_dispatch(verbose=True)
        for each in decentralization.target_cons:
            for dt in range(decentralization.T):
                print(each[0].dual_value[dt], end=" ")
            print()
        decentralization.dat=None
        decentralization.probs = None
        decentralization.targets = decentralization.constraints = decentralization.agg_target = decentralization.agg_constraint = None
        for each in decentralization.a_list:
            each = each.value
        with open(f"结果-不合作/results{date}.dmp", "wb") as file:
            pickle.dump(decentralization, file)
