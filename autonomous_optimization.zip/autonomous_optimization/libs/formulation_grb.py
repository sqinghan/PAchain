import random
import time

import gurobipy as gp
import numpy as np

# from scipy import stats
global T
T = 96
counter = 0


class DecentralizationTool:
    T = 96
    def __init__(self, n, dat, max_ite=5000, cont=False):
        self.dat = dat
        self.n = n
        self.Y = []
        self.X = []
        self.primal_residuals = []
        self.dual_residuals = []
        self.combined_residuals = []
        self.costs = []
        self.probs = []
        self.Y_last = [0 for i in range(n)]
        self.max_ite = max_ite
        self.data_dict_list = dat.data_dict_list
        self.constraints = []
        self.targets = []
        self.lijs = []
        self.a_list = []
        self.agg_target = 0
        self.agg_constraint = []
        self.cost = 0
        self.rho = 0
        self.zs_copy = 0
        self.cont = cont
        self.price = self.dat.price

    def build(self, init_value=800):
        self.Y = []
        self.X = []
        self.primal_residuals = []
        self.dual_residuals = []
        self.combined_residuals = []
        self.costs = []
        self.probs = []
        self.agg_prob = None
        self.Y_last = [0 for i in range(self.n)]
        self.constraints = []
        self.targets = []
        self.lijs = []
        self.a_list = []
        self.agg_target = 0
        self.agg_constraint = []
        self.cost = 0
        self.rho = 0
        self.zs_copy = 0
        self.init_value = np.array(init_value)
        self.agg_prob = gp.Model()
        # self.agg_prob.setParam("OutputFlag", 0)

        for i, each_item_i in enumerate(self.data_dict_list):
            H = each_item_i['H'] = np.array(each_item_i['H'])
            H_before_aug = np.array(each_item_i['H_before_aug'])
            G = np.array(each_item_i['G'])
            h = np.array(each_item_i['h'])
            a = np.array(each_item_i['a'])
            self.a_list += [a]
            const = each_item_i['const'] = np.array(each_item_i['const'])
            # print(const)
            m = gp.Model()
            m.setParam("OutputFlag", 0)
            self.probs += [m]
            y = m.addMVar((H.shape[0],), )
            self.Y += [y]
            m.addConstr(G @ y <= h)
            m.setMObjective(H / 2, a, const)
            # m.optimize()

            self.agg_target += 1 / 2 * (y @ H_before_aug @ y) + a @ y + const
            # self.agg_prob.addConstr(G @ y <= h)

            l = []
            for _rank, _ in enumerate(each_item_i['Cij']):
                if _rank == 0 and i != 0:
                    l += [np.hstack([np.ones(T)*(self.init_value), np.zeros(len(_)-T)])]
                else:
                    l += [np.hstack([np.ones(T)*(-self.init_value), np.zeros(len(_)-T)])]

            # self.lijs += [[np.zeros(len(_)) for _ in each_item_i['Cij']]]
            self.lijs += [l]

        # self.agg_prob.setObjective(self.agg_target)
        for i, each_item_i in enumerate(self.data_dict_list):
            N = np.array(each_item_i['N'])
            x = np.array(each_item_i['x'])
            self.X.append(N @ self.Y[i] + x)
        for i, each_item_i in enumerate(self.data_dict_list):
            for pos_i, j in enumerate(each_item_i['enid']):
                if i < j:
                    each_item_j = self.data_dict_list[j]
                    self.agg_constraint += [each_item_i['Cij'][pos_i] @ self.Y[i] + each_item_i['xi0'][pos_i] ==
                                            each_item_i['Cji'][pos_i] @ self.Y[j] + each_item_i['xj0'][pos_i]]

        self.cost = self.agg_target
        self.rho = (np.array(self.data_dict_list[0]['rho']).reshape(3*T)) ** 2
        self.zs_copy = [[] for _ in range(self.n)]


    def centralized_dispatch(self, verbose=True):
        self.agg_prob.optimize()

        p_buy = 0
        p_buy_cost = 0
        for i, each_item_i in enumerate(self.data_dict_list):
            if i != 0:# or True:
                # print("%8.4f" % self.X[i][-3 * T + dt].value, end=' ')
                p_buy += self.X[i][-3 * T:-2 * T].value - self.X[i][-2 * T:-1 * T].value
                p_buy_cost += np.array(self.dat.c_uppergrid[0]) @ self.X[i][-3 * T:-2 * T].value -\
                              self.dat.c_uppergrid[1] * np.sum(self.X[i][-2 * T:-1 * T].value)
        self.p_buy = self.X[0][0:T].value if self.dat.non_coop == 0 else p_buy
        if self.dat.non_coop == 1:
            self.p_buy = p_buy
            self.p_buy_cost = p_buy_cost
        else:
            self.p_buy = self.X[0][0:T].value
            self.p_buy_cost = self.dat.c_uppergrid[0] @ self.X[0][0:T].value

        print(f"买电成本:{self.p_buy_cost}")
        #
        # print(f'\n所有节点总买电{sum(p_buy)}')
        # for each in p_buy:
        #     print(each, end=" ")
        # print()
        print("总买电:", sum(self.p_buy))
        # print(p_buy)
        if not verbose:
            return
        print('所有节点发电量：')
        for i, each_item_i in enumerate(self.data_dict_list):
            for dt in range(T):
                print("%8.4f" % self.X[i][dt].value, end=' ')
            print()
        print('所有节点负荷：')
        for i, each_item_i in enumerate(self.data_dict_list):
            for dt in range(T):
                print("%8.4f" % self.dat.pload[i][dt], end=' ')
            print()
        print('所有节点成本：')
        for i, each_item_i in enumerate(self.data_dict_list):
            H_before_aug = np.array(each_item_i['H_before_aug'])
            a = np.array(each_item_i['a'])
            const = np.array(each_item_i['const'])
            H_ori = np.array(each_item_i['H_ori'])
            c_ori = np.array(each_item_i['c_ori'])
            a_ori = each_item_i['a_ori']
            print("%10.4f" % (1 / 2 * self.Y[i] @ H_before_aug @ self.Y[i] + a @ self.Y[i] + const).value, end=" ")
            print("%10.4f" % (1 / 2 * self.X[i] @ H_ori @ self.X[i] + c_ori @ self.X[i] + a_ori).value)
        print('\n所有节点上游功率：')
        for i, each_item_i in enumerate(self.data_dict_list):
            for dt in range(T):
                print("%8.4f" % self.X[i][2 * T + dt].value, end=' ')
            print()
        print('\n所有节点电压：')
        for i, each_item_i in enumerate(self.data_dict_list):
            for dt in range(T):
                print("%8.4f" % self.X[i][4 * T + dt].value, end=' ')
            print()

    def x_update(self, i, ite):
        ignore_dpp = False#(ite == 0)
        # self.probs[i].solve(solver=cp.GUROBI, ignore_dpp=ignore_dpp, warm_start=True)

        self.probs[i].setMObjective(self.data_dict_list[i]['H']/ 2, self.a_list[i] , self.data_dict_list[i]['const'])
        self.probs[i].optimize()
        self.dual_residuals[ite] = max(self.dual_residuals[ite],
                                       np.max(np.abs((self.Y[i].x - self.Y_last[i])))
                                       )

    def z_update(self, i, ite):
        each_item_i = self.data_dict_list[i]
        p1 = []
        p2 = []
        zs = []
        for pos_i, j in enumerate(each_item_i['enid']):
            p1 += [each_item_i['Cij'][pos_i] @ self.Y[i].x + each_item_i['xi0'][pos_i]]
            p2 += [each_item_i['Cji'][pos_i] @ self.Y[j].x + each_item_i['xj0'][pos_i]]
            zs += [(p1[pos_i] + p2[pos_i])/2]
            if ite == 0 and self.cont:
                continue
            self.lijs[i][pos_i] += self.rho * (p1[pos_i] - zs[pos_i])

        self.primal_residuals[ite] = max(self.primal_residuals[ite],
                                         np.max(np.abs((p1[pos_i] - p2[pos_i])))
                                         )

        if ite >= 1:
            self.combined_residuals[ite] += np.sum(self.rho * (p1[pos_i] - zs[pos_i]) ** 2)
            self.combined_residuals[ite] += np.sum(self.rho * (zs[pos_i] - self.zs_copy[i][pos_i]) ** 2)

        self.a_list[i] = np.array(each_item_i['a'])
        for pos_i, j in enumerate(each_item_i['enid']):
            each_item_j = self.data_dict_list[j]
            if ite == 0:
                if not self.cont:
                    self.zs_copy[i] += [zs[pos_i] + 0]
            else:
                self.zs_copy[i][pos_i] = zs[pos_i] + 0
            self.a_list[i] += each_item_i['Cij'][pos_i].T @ (self.lijs[i][pos_i] +
                                                                   self.rho * each_item_i['xi0'][pos_i] -
                                                                   self.rho * self.zs_copy[i][pos_i])

    def prepare(self,ite):
        self.primal_residuals += [0]
        self.dual_residuals += [0]
        self.combined_residuals += [0] if ite >=1 else [100]
        if ite >= 1:
            self.Y_last = [_.x for _ in self.Y]


def generate_standard_form(m, enid,
                           pload, qload, hload,
                           rlist=None, xlist=None,
                           ptype='PQ',
                           tendency=1,
                           res=(False, None, 0),  # 上限列表、功率因数tan
                           cogen=(False, 0, 0, 0, 0,),  # 下限、上限，功率因数tan、热电比
                           hp=(False, 0, 0),  # 上限， COP
                           batt=(False, 0, 0, 0, 0.9, 0.9),  # 充电功率上限，放电功率上限，容量，充电效率，放电效率
                           heatsto=(False, 0, 0, 0, 0.00),  # 储热上限，放热上限，容量，漏热率
                           c_res=(0, 0),
                           c_cogen=(0, 0),
                           c_uppergrid=(550, 400),
                           non_coop=0,
                           comm="",
                           false_prop=1,
                           to_grid=False
                           ):
    if xlist is None:
        xlist = [0.001]
    if rlist is None:
        rlist = [0.001]
    global counter
    counter = counter + 1
    # all of the variables are initialized as:
    # [Pgi, Qgi]
    # 2 * T
    #  [Pui, Qui, ui]={(5*T)*1},  发电量、传输线功率、电压，本节点的基本参数
    #  [u_father]={T*1},  父节点的电压
    #  [Pu_child_1, Qu_child_1, Pu_child_2, Qu_child_2..] = {(T * m_neighbours) * 1},  子节点的发电量
    #  ------------------- 4 + 2 * (m - 1)
    #  [Hgi],
    # 1 * T
    #  -------------------8 + (n_up + n_down)

    m_child = m-1 if ptype == 'PQ' else m
    nx = 6 + (2 * m_child) + 1
    ndev = 0
    flags = []

    if res[0] is True:
        nx += 2
        ndev += 2
        flags += [1]
    else:
        flags += [0]
    if cogen[0] is True:
        nx += 3
        ndev += 3
        flags += [1]
    else:
        flags += [0]
    if hp[0] is True:
        nx += 2
        ndev += 2
        flags += [1]
    else:
        flags += [0]
    if batt[0] is True and T > 1:
        nx += 3
        ndev += 3
        flags += [1]
    else:
        flags += [0]
    if heatsto[0] is True and T > 1:
        nx += 3
        ndev += 3
        flags += [1]
    else:
        flags += [0]
    if ptype != 'PQ' or non_coop == 1:
        flags += [1]
        ndev += 3
        nx += 3
    else:
        flags += [0]

    nx_ext = nx * T
    # variables = cp.Variable(nx_ext)

    I = np.eye(T)
    O = np.zeros((T, T))
    e = np.ones(T)
    o = np.zeros(T)
    A_pqbalance = np.vstack(
        [np.hstack([I, O] + [I, O, O, O] + [-I, O] * m_child + [O] * (1 + ndev)),
         np.hstack([O, I] + [O, I, O, O] + [O, -I] * m_child + [O] * (1 + ndev))])
    b_pqbalance = np.hstack([pload, qload])

    if ptype == "PQ":
        R = rlist[0]
        X = xlist[0]
        A_powerflow = np.hstack(
            [O, O, 2 * R * I, 2 * X * I, I, -I] + [O] * (2 * m_child + 1 + ndev))
        b_powerflow = o
    else:
        A_powerflow = np.vstack([
            np.hstack([O, O, I, O, O, O] + [O] * (2 * m_child + 1 + ndev)),
            np.hstack([O, O, O, I, O, O] + [O] * (2 * m_child + 1 + ndev)),
            np.hstack([O, O, O, O, I, O] + [O] * (2 * m_child + 1 + ndev)),
            np.hstack([O, O, O, O, O, I] + [O] * (2 * m_child + 1 + ndev)),
            # np.hstack([I, O, O, O, O, O] + [O] * (2 * m_child + 1 + ndev)),
            # np.hstack([O, I, O, O, O, O] + [O] * (2 * m_child + 1 + ndev)),
        ])
        b_powerflow = np.hstack([o, o, e, o,])

    T0 = 273
    Tr = 293
    Tr_excess = Tr - T0
    # 建立热平衡约束(松弛)
    if np.max(np.abs(hload)) <= 1.e-4:
        pass
        G_hbalance = np.zeros((1, nx_ext))
        G_hbalance[0][0] = 1
        h_hbalance = np.hstack([100])
    else:
        G_hbalance = np.hstack([O] * (6 + 2 * m_child) + [-I] + [O] * ndev)
        h_hbalance = -np.hstack([hload])

    A_gen = np.vstack([
        np.hstack([-I, O] + [O] * (4 + 2 * m_child) + [O] + [I, O] * flags[0] + [I, O, O] * flags[1]
                  + [-I, O] * flags[2] + [O, -I, I * batt[5]] * flags[3] + [O, O, O] * flags[4]
                  + [I, -I, O] * flags[5]),

        np.hstack([O, -I] + [O] * (4 + 2 * m_child) + [O] + [O, I] * flags[0] + [O, I, O] * flags[1]
                  + [O, O] * flags[2] + [O, O, O] * flags[3] + [O, O, O] * flags[4] +
                  [O, O, I] * flags[5]),

        np.hstack([O, O] + [O] * (4 + 2 * m_child) + [-I] + [O, O] * flags[0] + [O, O, I] * flags[1]
                  + [O, I] * flags[2] + [O, O, O] * flags[3] + [O, -I, I] * flags[4] +
                  [O, O, O] * flags[5]),
    ])
    b_gen = np.zeros(3 * T)

    O_def = O[0:T - 1, :]

    A_dev = []
    b_dev = []
    G_dev = []
    h_dev = []

    if flags[0]:
        a = np.hstack(
            [O, O] + [O] * (4 + 2 * m_child) + [O] + [res[2] * I, -I] * flags[0] + [O, O, O] * flags[1] + [O, O] * flags[2] +
            [O, O, O] * flags[3] + [O, O, O] * flags[4] + [O, O, O] * flags[5])
        b = o
        A_dev.append(a)
        b_dev.append(b)

        for dt in range(T):
            if res[1][dt] <= 1.e-3:
                a = np.hstack([o, o] + [o] * (4 + 2 * m_child) + [o] +
                              [np.hstack([0] * dt + [1] + [0] * (T - dt - 1)), o] * flags[0] +
                              [o, o, o] * flags[1] + [o, o] * flags[2] +
                              [o, o, o] * flags[3] + [o, o, o] * flags[4] + [o, o, o] * flags[5])
                b = 0
                A_dev.append(a)
                b_dev.append(b)
            else:
                g1 = np.hstack([o, o] + [o] * (4 + 2 * m_child) + [o] +
                               [np.hstack([0] * dt + [1] + [0] * (T - dt - 1)), o] * flags[0] +
                               [o, o, o] * flags[1] + [o, o] * flags[2] +
                               [o, o, o] * flags[3] + [o, o, o] * flags[4] + [o, o, o] * flags[5])
                g2 = np.hstack([o, o] + [o] * (4 + 2 * m_child) + [o] +
                               [np.hstack([0] * dt + [-1] + [0] * (T - dt - 1)), o] * flags[0] +
                               [o, o, o] * flags[1] + [o, o] * flags[2] +
                               [o, o, o] * flags[3] + [o, o, o] * flags[4] + [o, o, o] * flags[5])
                h1 = res[1][dt]
                h2 = 0
                G_dev.append(g1)
                G_dev.append(g2)
                h_dev.append(h1)
                h_dev.append(h2)
    if flags[1]:
        if cogen[3] is not None:
            a = np.hstack([O, O] + [O] * (4 + 2 * m_child) + [O] + [O, O] * flags[0] + [cogen[3] * I, -I, O] * flags[1]
                          + [O, O] * flags[2] + [O, O, O] * flags[3] + [O, O, O] * flags[4] + [O, O, O] * flags[5])
            b = o
            A_dev.append(a)
            b_dev.append(b)

        a = np.hstack([O, O] + [O] * (4 + 2 * m_child) + [O] + [O, O] * flags[0] + [cogen[4] * I, O, -I] * flags[1]
                      + [O, O] * flags[2] + [O, O, O] * flags[3] + [O, O, O] * flags[4] + [O, O, O] * flags[5])
        b = o
        A_dev.append(a)
        b_dev.append(b)
        G_dev.append(np.vstack([
            np.hstack([O, O] + [O] * (4 + 2 * m_child) + [O] +
                      [O, O] * flags[0] + [I, O, O] * flags[1] + [O, O] * flags[2] +
                      [O, O, O] * flags[3] + [O, O, O] * flags[4] + [O, O, O] * flags[5]),
            np.hstack([O, O] + [O] * (4 + 2 * m_child) + [O] +
                      [O, O] * flags[0] + [-I, O, O] * flags[1] + [O, O] * flags[2] +
                      [O, O, O] * flags[3] + [O, O, O] * flags[4] + [O, O, O] * flags[5])
        ]))
        h_dev += [np.ones(T) * cogen[2], -np.ones(T) * cogen[1]]
    if flags[2]:
        a = np.hstack(
            [O, O] + [O] * (4 + 2 * m_child) + [O] + [O, O] * flags[0] + [O, O, O] * flags[1] + [hp[2] * I, -I] * flags[2] + \
            [O, O, O] * flags[3] + [O, O, O] * flags[4] + [O, O, O] * flags[5])
        b = o
        A_dev.append(a)
        b_dev.append(b)
        G_dev.append(np.vstack([
            np.hstack([O, O] + [O] * (4 + 2 * m_child) + [O] +
                      [O, O] * flags[0] + [O, O, O] * flags[1] + [I, O] * flags[2] +
                      [O, O, O] * flags[3] + [O, O, O] * flags[4] + [O, O, O] * flags[5]),
            np.hstack([O, O] + [O] * (4 + 2 * m_child) + [O] +
                      [O, O] * flags[0] + [O, O, O] * flags[1] + [-I, O] * flags[2] +
                      [O, O, O] * flags[3] + [O, O, O] * flags[4] + [O, O, O] * flags[5]),
        ]))
        h_dev += [np.ones(T) * hp[1], -np.zeros(T)]
    if flags[3] and T > 1:
        a = np.hstack([O_def, O_def] + [O_def] * (4 + 2 * m_child) + [O_def] +
                      [O_def, O_def] * flags[0] +
                      [O_def, O_def, O_def] * flags[1] +
                      [O_def, O_def] * flags[2] +
                      [(np.vstack([np.hstack([np.zeros((T - 1, 1)), np.eye(T - 1)]),
                                   np.hstack([np.array([[1]]), np.zeros((1, T - 1))])]) - I)[0:T - 1, :],
                       -I[0:T - 1, :] * batt[4]* (24/T),
                       I[0:T - 1, :] * (24/T)] * flags[3] +
                      [O_def, O_def, O_def] * flags[4] + [O_def, O_def, O_def] * flags[5])
        b = np.zeros(T - 1)
        A_dev.append(a)
        b_dev.append(b)
        a = np.hstack([o, o] + [o] * (4 + 2 * m_child) + [o] +
                              [o, o] * flags[0] +
                              [o, o, o] * flags[1] + [o, o] * flags[2] +
                              [np.hstack([1] + [0] * (T - 1)), o, o] * flags[3] + [o, o, o] * flags[4] + [o, o, o] * flags[5])
        b = batt[3] * 0.5
        A_dev.append(a)
        b_dev.append(b)
        G_dev.append(np.hstack(
            [o, o] + [o] * (4 + 2 * m_child) + [o] +
            [o, o] * flags[0] + [o, o, o] * flags[1] + [o, o] * flags[2] +
            [np.hstack([1] + [0] * (T - 2) + [-1]),
             np.hstack([0] * (T - 1) + [-1 * batt[4]]),
             np.hstack([0] * (T - 1) + [1])] * flags[3]
            + [o, o, o] * flags[4] + [o, o, o] * flags[5]
        ))
        h_dev += [0]

        G_dev.append(np.vstack([
            np.hstack([O, O] + [O] * (4 + 2 * m_child) + [O] +
                      [O, O] * flags[0] + [O, O, O] * flags[1] + [O, O] * flags[2] +
                      [I, O, O] * flags[3] + [O, O, O] * flags[4] + [O, O, O] * flags[5]),
            np.hstack([O, O] + [O] * (4 + 2 * m_child) + [O] +
                      [O, O] * flags[0] + [O, O, O] * flags[1] + [O, O] * flags[2] +
                      [-I, O, O] * flags[3] + [O, O, O] * flags[4] + [O, O, O] * flags[5])
        ]))
        h_dev += [np.ones(T) * batt[3], o]

        G_dev.append(np.vstack([
            np.hstack([O, O] + [O] * (4 + 2 * m_child) + [O] +
                      [O, O] * flags[0] + [O, O, O] * flags[1] + [O, O] * flags[2] +
                      [O, I, O] * flags[3] + [O, O, O] * flags[4] + [O, O, O] * flags[5]),
            np.hstack([O, O] + [O] * (4 + 2 * m_child) + [O] +
                      [O, O] * flags[0] + [O, O, O] * flags[1] + [O, O] * flags[2] +
                      [O, -I, O] * flags[3] + [O, O, O] * flags[4] + [O, O, O] * flags[5])
        ]))
        h_dev += [np.ones(T) * batt[1], o]

        G_dev.append(np.vstack([
            np.hstack([O, O] + [O] * (4 + 2 * m_child) + [O] +
                      [O, O] * flags[0] + [O, O, O] * flags[1] + [O, O] * flags[2] +
                      [O, O, I] * flags[3] + [O, O, O] * flags[4] + [O, O, O] * flags[5]),
            np.hstack([O, O] + [O] * (4 + 2 * m_child) + [O] +
                      [O, O] * flags[0] + [O, O, O] * flags[1] + [O, O] * flags[2] +
                      [O, O, -I] * flags[3] + [O, O, O] * flags[4] + [O, O, O] * flags[5])
        ]))
        h_dev += [np.ones(T) * batt[2], o]

    if flags[4] and T > 1:
        a = np.hstack([O_def, O_def] + [O_def] * (4 + 2 * m_child) + [O_def] +
                      [O_def, O_def] * flags[0] +
                      [O_def, O_def, O_def] * flags[1] +
                      [O_def, O_def] * flags[2] +
                      [O_def, O_def, O_def] * flags[3] +
                      [(np.vstack([np.hstack([np.zeros((T - 1, 1)), np.eye(T - 1) / (1 - heatsto[4])]),
                                   np.hstack([np.array([[1 / (1 - heatsto[4])]]), np.zeros((1, T - 1))])]) - I)[0:T - 1,
                       :],
                       -I[0:T - 1, :],
                       I[0:T - 1, :]] * flags[4] + [O_def, O_def, O_def] * flags[5])
        b = np.zeros(T - 1)
        A_dev.append(a)
        b_dev.append(b)

        a = np.hstack([o, o] + [o] * (4 + 2 * m_child) + [o] +
                              [o, o] * flags[0] +
                              [o, o, o] * flags[1] + [o, o] * flags[2] +
                              [o, o, o] * flags[3] + [np.hstack([1] + [0] * (T - 1)), o, o] * flags[4] + [o, o, o] * flags[5])
        b = heatsto[3] * 0.5
        A_dev.append(a)
        b_dev.append(b)
        G_dev.append(np.hstack(
            [o, o] + [o] * (4 + 2 * m_child) + [o] +
            [o, o] * flags[0] + [o, o, o] * flags[1] + [o, o] * flags[2] +
            [o, o, o] * flags[3] +
            [np.hstack([1 / (1 - heatsto[4])] + [0] * (T - 2) + [-1]),
             np.hstack([0] * (T - 1) + [-1]),
             np.hstack([0] * (T - 1) + [1])] * flags[4] + [o, o, o] * flags[5]
        ))
        h_dev += [0]

        G_dev.append(np.vstack([
            np.hstack([O, O] + [O] * (4 + 2 * m_child) + [O] +
                      [O, O] * flags[0] + [O, O, O] * flags[1] + [O, O] * flags[2] +
                      [O, O, O] * flags[3] + [I, O, O] * flags[4] + [O, O, O] * flags[5]),
            np.hstack([O, O] + [O] * (4 + 2 * m_child) + [O] +
                      [O, O] * flags[0] + [O, O, O] * flags[1] + [O, O] * flags[2] +
                      [O, O, O] * flags[3] + [-I, O, O] * flags[4] + [O, O, O] * flags[5])
        ]))
        h_dev += [np.ones(T) * heatsto[3], o]

        G_dev.append(np.vstack([
            np.hstack([O, O] + [O] * (4 + 2 * m_child) + [O] +
                      [O, O] * flags[0] + [O, O, O] * flags[1] + [O, O] * flags[2] +
                      [O, O, O] * flags[3] + [O, I, O] * flags[4] + [O, O, O] * flags[5]),
            np.hstack([O, O] + [O] * (4 + 2 * m_child) + [O] +
                      [O, O] * flags[0] + [O, O, O] * flags[1] + [O, O] * flags[2] +
                      [O, O, O] * flags[3] + [O, -I, O] * flags[4] + [O, O, O] * flags[5])
        ]))
        h_dev += [np.ones(T) * heatsto[1], o]

        G_dev.append(np.vstack([
            np.hstack([O, O] + [O] * (4 + 2 * m_child) + [O] +
                      [O, O] * flags[0] + [O, O, O] * flags[1] + [O, O] * flags[2] +
                      [O, O, O] * flags[3] + [O, O, I] * flags[4] + [O, O, O] * flags[5]),
            np.hstack([O, O] + [O] * (4 + 2 * m_child) + [O] +
                      [O, O] * flags[0] + [O, O, O] * flags[1] + [O, O] * flags[2] +
                      [O, O, O] * flags[3] + [O, O, -I] * flags[4] + [O, O, O] * flags[5])
        ]))
        h_dev += [np.ones(T) * heatsto[2], o]

    if flags[5]:
        G_dev.append(np.hstack(
            [O, O] + [O] * (2 * m_child + 4) + [O] +
            [O, O] * flags[0] + [O, O, O] * flags[1] + [O, O] * flags[2] +
            [O, O, O] * flags[3] +
            [O, O, O] * flags[4] + [-I, O, O] * flags[5]
        ))
        h_dev += [-0*e]
        # G_dev.append(np.hstack(
        #     [O, O] + [O] * (2 * m_child + 4) + [O] +
        #     [O, O] * flags[0] + [O, O, O] * flags[1] + [O, O] * flags[2] +
        #     [O, O, O] * flags[3] +
        #     [O, O, O] * flags[4] + [I, O, O] * flags[5]
        # ))
        if non_coop==0 and not to_grid:
            A_dev.append(np.hstack(
                [O, O] + [O] * (2 * m_child + 4) + [O] +
                [O, O] * flags[0] + [O, O, O] * flags[1] + [O, O] * flags[2] +
                [O, O, O] * flags[3] +
                [O, O, O] * flags[4] + [O, -I, O] * flags[5]
            ))
            b_dev += [o]
        else:
            G_dev.append(np.hstack(
                [O, O] + [O] * (2 * m_child + 4) + [O] +
                [O, O] * flags[0] + [O, O, O] * flags[1] + [O, O] * flags[2] +
                [O, O, O] * flags[3] +
                [O, O, O] * flags[4] + [O, -I, O] * flags[5]
            ))
            h_dev += [o]
        # h_dev += [o, 1000 * e, o, 1000 * e]

    if tendency == 1:
        pass
    elif tendency == 2:
        pass
        # G_dev.append(np.vstack(
        # [np.hstack([-I, O] + [O, O, O, O] + [O, O] * m_child + [O] * (1 + ndev)),
        #  np.hstack([O, -I] + [O, O, O, O] + [O, O] * m_child + [O] * (1 + ndev))])
        # )
        # h_dev.append(np.hstack([-pload, -qload]))

        G_dev.append(np.hstack([-I, O] + [O, O, O, O] + [O, O] * m_child + [O] * (1 + ndev)))
        h_dev.append(-pload)
    elif tendency == 3 and T > 1:
        delta = 2/T
        A_dev.append(np.vstack([
            np.hstack([O, O] + [O] * (4 + 2 * m_child) + [O] +
                      [O, O] * flags[0] + [O, O, O] * flags[1] + [O, O] * flags[2] +
                      [I, O, O] * flags[3] + [O, O, O] * flags[4] + [O, O, O] * flags[5]),
        ])[1:T,:])
        sto_designed = np.array([6*delta, 7*delta, 8*delta, 9*delta, 10*delta, 11*delta,
                                 12*delta, 11*delta, 10*delta, 9*delta, 8*delta, 7*delta,
                                 6*delta, 5*delta, 8*delta, 9*delta, 10*delta, 11*delta,
                                 12*delta, 11*delta, 10*delta, 9*delta, 8*delta, 7*delta])[1:T]
        b_dev += [sto_designed * batt[3]]

    if non_coop == 1 and ptype == "PQ":
        A_dev.append(np.vstack([
            np.hstack([O, O, I, O, O, O] + [O] * (2 * m_child + 1 + ndev)),
            np.hstack([O, O, O, I, O, O] + [O] * (2 * m_child + 1 + ndev))
        ]))
        b_dev += [np.hstack([o, o])]
    # A_dev = np.vstack(A_dev)
    # b_dev = np.hstack(b_dev)
    # G_dev = np.vstack(G_dev)
    # h_dev = np.hstack(h_dev)
    H = np.eye(nx_ext) * 0.1
    c = -np.ones(nx_ext) * 0  # 5.e-3

    # 可再生成本
    for j in range((2 + (4 + 2 * m_child) + 1 + 0 * flags[0]) * T,
                   (2 + (4 + 2 * m_child) + 1 + 1 * flags[0]) * T):
        H[j][j] += c_res[0] * false_prop
    # 普通发电成本
    for j in range((2 + (4 + 2 * m_child) + 1 + (2 * flags[0] + 0 * flags[1])) * T,
                   (2 + (4 + 2 * m_child) + 1 + (2 * flags[0] + 1 * flags[1])) * T):
        H[j][j] += c_cogen[0] * false_prop

    c_voltage = 0
    # for j in range((2 + 2) * T,
    #                (2 + 3) * T):
    #     H[j][j] += 1
    #
    # for j in range((2 + 2) * T,
    #                (2 + 3) * T):
    #     c[j] -= 1
    # c_voltage = 1 / 2
    for j in range((2 + (4 + 2 * m_child) + 1 + 0 * flags[0]) * T,
                   (2 + (4 + 2 * m_child) + 1 + 1 * flags[0]) * T):
        c[j] += c_res[1] * false_prop
    for j in range((2 + (4 + 2 * m_child) + 1 + (2 * flags[0] + 0 * flags[1])) * T,
                   (2 + (4 + 2 * m_child) + 1 + (2 * flags[0] + 1 * flags[1])) * T):
        c[j] += c_cogen[1] * false_prop
    for j in range((2 + (4 + 2 * m_child) + 1 + (
            2 * flags[0] + 3 * flags[1] + 2 * flags[2] + 3 * flags[3] + 3 * flags[4] + 0 * flags[5])) * T,
                   (2 + (4 + 2 * m_child) + 1 + (
                           2 * flags[0] + 3 * flags[1] + 2 * flags[2] + 3 * flags[3] + 3 * flags[4] + 1 * flags[
                       5])) * T):
        if type(c_uppergrid[0]) == int or type(c_uppergrid[0]) == float:
            c[j] += c_uppergrid[0]
        else:
            c[j] += c_uppergrid[0][j - (2 + (4 + 2 * m_child) + 1 + (
                2 * flags[0] + 3 * flags[1] + 2 * flags[2] + 3 * flags[3] + 3 * flags[4] + 0 * flags[5])) * T]
    for j in range((2 + (4 + 2 * m_child) + 1 + (
            2 * flags[0] + 3 * flags[1] + 2 * flags[2] + 3 * flags[3] + 3 * flags[4] + 1 * flags[5])) * T,
                   (2 + (4 + 2 * m_child) + 1 + (
                           2 * flags[0] + 3 * flags[1] + 2 * flags[2] + 3 * flags[3] + 3 * flags[4] + 2 * flags[
                       5])) * T):
        c[j] += -c_uppergrid[1]

    # 所有的约束为：
    # A_pqbalance x = b_pqbalance (节点能量守恒)
    # A_powerflow x = b_powerflow (欧姆定律/潮流方程, 仅电网节点有)
    # G_hbalance x <= h_hbalance
    # A_gen x = b_gen (节点注入功率和各个设备之间的关系)
    # A_dev x = b_dev
    # G_dev x <= h_dev ()
    if not (A_dev == []):
        A = np.vstack([A_pqbalance, A_powerflow, A_gen, np.vstack(A_dev)])
        b = np.hstack([b_pqbalance, b_powerflow, b_gen, np.hstack(b_dev)])
    else:
        A = np.vstack([A_pqbalance, A_powerflow, A_gen])
        b = np.hstack([b_pqbalance, b_powerflow, b_gen])
    if not (G_dev == []):
        G = np.vstack([np.vstack(G_dev), G_hbalance])
        h = np.hstack([np.hstack(h_dev), h_hbalance])
    else:
        G = np.vstack([G_hbalance])
        h = np.hstack([h_hbalance])

    assert np.linalg.matrix_rank(A) - A.shape[0] == 0

    # R = np.eye(nx_ext) @ stats.ortho_group.rvs(nx_ext)
    q, r = np.linalg.qr(A.T, mode='complete')
    C = q[:, 0:A.shape[0]]
    N = q[:, A.shape[0]:]
    x0 = C @ np.linalg.inv(r[0:A.shape[0], 0:A.shape[0]].T) @ b

    # print("生成时测试:")
    # variables_simp = cp.Variable(A.shape[1] - A.shape[0])
    # test_cost = 1 / 2 * cp.quad_form(variables, R.T @ H @ R) + c @ R @ variables
    # test_cons = [A @ R @ variables == b,
    #              G @ R @ variables <= h]
    # test_prob = cp.Problem(cp.Minimize(test_cost), test_cons)
    # test_prob.solve(solver=cp.GUROBI)

    from scipy import stats
    rnd = stats.ortho_group.rvs(A.shape[1] - A.shape[0])
    rnd = rnd.T @ np.diag([0.6+0.8*random.random() for _ in range(A.shape[1]-A.shape[0])]) @ rnd
    R = np.eye(A.shape[1] - A.shape[0]) @ rnd

    Cij = []
    xi0 = []
    start = 0 if ptype == 'VT' else 1
    if ptype == "PQ":
        Cij += [np.vstack([np.hstack([O, O, I, O, O, O] + [O] * (nx - 6)),
                           np.hstack([O, O, O, I, O, O] + [O] * (nx - 6)),
                           np.hstack([O, O, O, O, O, I] + [O] * (nx - 6))]) @ N @ R]
        xi0 += [np.vstack([np.hstack([O, O, I, O, O, O] + [O] * (nx - 6)),
                           np.hstack([O, O, O, I, O, O] + [O] * (nx - 6)),
                           np.hstack([O, O, O, O, O, I] + [O] * (nx - 6))]) @ x0]
    xj0 = []
    for each in range(start, m):
        j = each - start + 1
        Cij += [np.vstack([np.hstack([O, O, O, O, O, O] + [O] * 2 * (j - 1) + [I, O] + [O] * (nx - 6 - 2 * j)),
                           np.hstack([O, O, O, O, O, O] + [O] * 2 * (j - 1) + [O, I] + [O] * (nx - 6 - 2 * j)),
                           np.hstack([O, O, O, O, I, O] + [O] * (nx - 6))]) @ N @ R]
        xi0 += [np.vstack([np.hstack([O, O, O, O, O, O] + [O] * 2 * (j - 1) + [I, O] + [O] * (nx - 6 - 2 * j)),
                           np.hstack([O, O, O, O, O, O] + [O] * 2 * (j - 1) + [O, I] + [O] * (nx - 6 - 2 * j)),
                           np.hstack([O, O, O, O, I, O] + [O] * (nx - 6))]) @ x0]
    rho = np.hstack([np.ones(T)*np.sqrt(10), np.ones(T)*np.sqrt(1), np.ones(T)*np.sqrt(1)]).reshape((3*T, 1))
    prox = 0.0
    H_pre = R.T @ N.T @ H @ N @ R
    H_before_aug = np.copy(H_pre)
    for _ in Cij:
        H_pre += ((rho*_).T @ (rho*_))
    for _ in range(H_pre.shape[0]):
        H_pre[_][_] += prox


    # if ptype == "PQ":
    #     Cij += [np.hstack([O, O, O, O, O, I] + [O] * (nx - 6)) @ N]
    #     xi0 += [np.hstack([O, O, O, O, O, I] + [O] * (nx - 6)) @ x0]
    # for each in range(start, m):
    #     j = each - start + 1
    #     Cij += [np.vstack([np.hstack([O, O, O, O, O, O] + [O] * 2 * (j - 1) + [I, O] + [O] * (nx - 6 - 2 * j)),
    #                        np.hstack([O, O, O, O, O, O] + [O] * 2 * (j - 1) + [O, I] + [O] * (nx - 6 - 2 * j))]) @ N]
    #     xi0 += [np.vstack([np.hstack([O, O, I, O, O, O] + [O] * (nx - 6)),
    #                        np.hstack([O, O, O, I, O, O] + [O] * (nx - 6))]) @ x0]
    # Cji = []
    # xj0 = []
    G_pre = G @ N @ R
    h_pre = h - G @ x0
    for row in range(G_pre.shape[0]):
        if (np.abs(G_pre[row]) < 1.e-8).all():
            # print(counter)
            G_pre[row][0] = 1
            h_pre[row] = 100
    return {
        "H": H_pre.tolist(),
        "a": ((c + x0.T @ H) @ N @ R).tolist(),
        'const': (1 / 2 * x0 @ H @ x0 + c @ x0 + c_voltage * T).tolist(),
        'G': G_pre.tolist(),
        'h': h_pre.tolist(),
        'Cij': [_.tolist() for _ in Cij],
        'xi0': [_.tolist() for _ in xi0],
        # 'Cji_for_father': np.vstack([np.hstack([O, O, I, O, O, O] + [O] * (nx - 6)),
        #                              np.hstack([O, O, O, I, O, O] + [O] * (nx - 6))]) @ N,
        # 'Cji_for_child': np.vstack([np.hstack([O, O, O, O, O, I] + [O] * (nx - 6))]) @ N,
        'Cji': [],
        'xj0': [],
        'N': (N @ R).tolist(),
        'R': R.tolist(),
        'x': x0.tolist(),
        'rho': rho.tolist(),
        'H_ori': H.tolist(),
        "c_ori": c.tolist(),
        "a_ori": c_voltage * T,
        "H_before_aug": H_before_aug.tolist(),
        "prox": prox,
        'T': T,
        'enid': enid,
    }, flags
