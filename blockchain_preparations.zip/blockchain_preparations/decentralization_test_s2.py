import json
import os
import sys

import matplotlib.pyplot as plt
import numpy as np

import formulation
from formulation import generate_standard_form
from create_formulation_through_predefined_apis import pload_ref, qload_ref, hload_ref, \
    res_ref, pqh_coeff
from network_config import *

T = formulation.T = 24
st = 0

# pload_ref qload_ref hload_ref 负荷参考值
# pqh_coeff 各节点的负荷系数
data_dict_list = [generate_standard_form(1, [1],
                                         pqh_coeff[0][0] * pload_ref, pqh_coeff[0][1] * qload_ref,
                                         pqh_coeff[0][2] * hload_ref,
                                         ptype='VT',
                                         c_uppergrid=(550, 200)),  # DES0
                  generate_standard_form(4, [0, 2, 3, 5],
                                         pqh_coeff[1][0] * pload_ref, pqh_coeff[1][1] * qload_ref,
                                         pqh_coeff[1][2] * hload_ref,
                                         tendency=3,
                                         cogen=(True, 0.05, 0.25, 0.5, 0),
                                         batt=(True, 0.1, 0.1, 0.2, 0.9, 0.9),
                                         c_cogen=(150, 400),
                                         comm='battery'),  # DES1

                  generate_standard_form(1, [1],
                                         pqh_coeff[2][0] * pload_ref, pqh_coeff[2][1] * qload_ref,
                                         pqh_coeff[2][2] * hload_ref,
                                         tendency=2,
                                         res=(True, res_ref[2], 0.33),
                                         cogen=(True, 0.2, 1, 0.2, 2),
                                         batt=(True, 0.1, 0.1, 0.2, 0.9, 0.9),
                                         heatsto=(True, 0.3, 0.3, 1.2, 0.01),
                                         c_res=(10, 20),
                                         c_cogen=(100, 400)),  # DES2

                  generate_standard_form(2, [1, 4],
                                         pqh_coeff[3][0] * pload_ref, pqh_coeff[3][1] * qload_ref,
                                         pqh_coeff[3][2] * hload_ref,
                                         tendency=2,
                                         cogen=(True, 0.3, 1.5, 0.5, 0),
                                         batt=(True, 0.1, 0.1, 0.2, 0.9, 0.9),
                                         c_cogen=(100, 320)),  # DES3

                  generate_standard_form(1, [3],
                                         pqh_coeff[4][0] * pload_ref, pqh_coeff[4][1] * qload_ref,
                                         pqh_coeff[4][2] * hload_ref,
                                         tendency=2,
                                         res=(True, res_ref[4], 0.33),
                                         cogen=(True, 0.25, 1.25, 0.2, 2),
                                         hp=(True, 0.5, 2),
                                         c_res=(10, 20),
                                         c_cogen=(200, 370)),  # DES4

                  generate_standard_form(2, [1, 6],
                                         pqh_coeff[5][0] * pload_ref, pqh_coeff[5][1] * qload_ref,
                                         pqh_coeff[5][2] * hload_ref),  # DES 5

                  generate_standard_form(3, [5, 7, 8],
                                         pqh_coeff[6][0] * pload_ref, pqh_coeff[6][1] * qload_ref,
                                         pqh_coeff[6][2] * hload_ref,
                                         tendency=1,
                                         res=(True, res_ref[6], 0.33),
                                         hp=(True, 1.5, 2),
                                         c_res=(10, 20)),  # DES 6

                  generate_standard_form(2, [6, 9],
                                         pqh_coeff[7][0] * pload_ref, pqh_coeff[7][1] * qload_ref,
                                         pqh_coeff[7][2] * hload_ref,
                                         tendency=2,
                                         res=(True, res_ref[7], 0.33),
                                         cogen=(True, 0.2, 1, 0.2, 1),
                                         hp=(True, 1.2, 1.8),
                                         c_res=(10, 20),
                                         c_cogen=(100, 400)),  # DES 7

                  generate_standard_form(1, [6],
                                         pqh_coeff[8][0] * pload_ref, pqh_coeff[8][1] * qload_ref,
                                         pqh_coeff[8][2] * hload_ref,
                                         tendency=3,
                                         batt=(True, 0.5, 0.5, 2, 0.9, 0.9),
                                         comm='battery'),  # DES 8

                  generate_standard_form(1, [7],
                                         pqh_coeff[9][0] * pload_ref, pqh_coeff[9][1] * qload_ref,
                                         pqh_coeff[9][2] * hload_ref,
                                         res=(True, res_ref[9], 0.2),
                                         c_res=(10, 20)),  # DES 9
                  ]

DES_id_list = [str(ids[j]) for j in DESs]
DES_name_list = [names[j] for j in DESs]

# i:序号，each_id_i:序号i的DES的id, item_i:对应的数据体, j:相邻节点序号，pos_i:j是i的第几个相邻节点, pos_j:i是j的第几个相邻节点。

for i, each_item_i in enumerate(data_dict_list):
    each_id_i = DES_id_list[i]
    for pos_i, j in enumerate(each_item_i['enid']):
        each_id_j = DES_id_list[j]
        # j = DES_id_list.index(each_id_j)
        each_item_j = data_dict_list[j]
        pos_j = each_item_j['enid'].index(i)
        each_item_j['Cij'][pos_j] = np.array(each_item_j['Cij'][pos_j])
        each_item_j['xi0'][pos_j] = np.array(each_item_j['xi0'][pos_j])
        each_item_i['Cji'] += [each_item_j['Cij'][pos_j]]
        each_item_i['xj0'] += [each_item_j['xi0'][pos_j]]

import cvxpy as cp

Y = []

constraints = []
targets = []
agg_target = 0
agg_constraint = []
lijs = []
lijhats = []
zs = []
accelij1 = []
accelij2 = []
probs = []
a_list = []


for i, each_item_i in enumerate(data_dict_list):
    H = np.array(each_item_i['H'])
    H_before_aug = np.array(each_item_i['H_before_aug'])
    G = np.array(each_item_i['G'])
    h = np.array(each_item_i['h'])
    a = cp.Parameter(H.shape[0], value=np.array(each_item_i['a']))
    a_list += [a]
    const = np.array(each_item_i['const'])
    Y.append(cp.Variable(H.shape[0]))

    targets += [1 / 2 * cp.quad_form(Y[i], H) + a @ Y[i] + const]
    constraints += [[G @ Y[i] <= h]]
    agg_target += 1 / 2 * cp.quad_form(Y[i], H_before_aug) + a @ Y[i] + const
    agg_constraint += [G @ Y[i] <= h]
    lijs += [[np.zeros(len(_)) for _ in each_item_i['Cij']]]
    lijhats += [[np.zeros(len(_)) for _ in each_item_i['Cij']]]
    accelij1 += [[np.zeros(len(_)) for _ in each_item_i['Cij']]]
    accelij2 += [[np.zeros(len(_)) for _ in each_item_i['Cij']]]
    probs += [cp.Problem(cp.Minimize(targets[i]), constraints[i])]
    # print(cp.Problem(cp.Minimize(cp.quad_form(y, H)), [G @ y <= h]).solve())

for i, each_item_i in enumerate(data_dict_list):
    for pos_i, j in enumerate(each_item_i['enid']):
        if i < j:
            each_item_j = data_dict_list[j]
            agg_constraint += [each_item_i['Cij'][pos_i] @ Y[i] + each_item_i['xi0'][pos_i] ==
                               each_item_i['Cji'][pos_i] @ Y[j] + each_item_i['xj0'][pos_i]]


print("-----------------------Centralized Dispatch---------------------------")
pb = cp.Problem(cp.Minimize(agg_target), constraints=agg_constraint)
pb.solve(solver=cp.GUROBI)
print(pb.status)
print(pb.value)
X = []
for i, each_item_i in enumerate(data_dict_list):
    N = np.array(each_item_i['N'])
    x = np.array(each_item_i['x'])
    X.append(N @ Y[i].value + x)

print('所有节点发电量：')
for i, each_item_i in enumerate(data_dict_list):
    for dt in range(T):
        print("%8.4f" % X[i][dt], end=' ')
    print()
print('所有节点成本：')
for i, each_item_i in enumerate(data_dict_list):
    H_before_aug = np.array(each_item_i['H_before_aug'])
    a = np.array(each_item_i['a'])
    const = np.array(each_item_i['const'])
    H_ori = np.array(each_item_i['H_ori'])
    c_ori = np.array(each_item_i['c_ori'])
    print("%10.4f" % (1 / 2 * cp.quad_form(Y[i], H_before_aug) + a @ Y[i] + const).value, end=" ")
    print("%10.4f" % (1 / 2 * cp.quad_form(X[i], H_ori) + c_ori @ X[i]).value)
print('\n所有节点上游功率：')
for i, each_item_i in enumerate(data_dict_list):
    for dt in range(T):
        print("%8.4f" % X[i][2 * T + dt], end=' ')
    print()

print("-----------------------Decentralized Dispatch---------------------------")
rho = (np.array(data_dict_list[0]['rho']).reshape(3*T)) ** 2

p1 = [[] for _ in range(len(data_dict_list))]
p2 = [[] for _ in range(len(data_dict_list))]
zs = [[] for _ in range(len(data_dict_list))]
zhats = [[] for _ in range(len(data_dict_list))]
p1_last = None
p2_last = None
Y_last = [_.value * 0 for _ in Y]

# print("----计算结果X2----")
# print(X[2])
# print("----------------")


primal_residuals = [] #[[] for _ in range(len(data_dict_list))]
dual_residuals = [] #[[] for _ in range(len(data_dict_list))]
costs = []
max_ite = 500
gamma = 1

number_of_acce = 0

cost = 0
for i, each_item_i in enumerate(data_dict_list):
    H_before_aug = np.array(each_item_i['H_before_aug'])
    a = np.array(each_item_i['a'])
    const = np.array(each_item_i['const'])
    cost += (1 / 2 * cp.quad_form(Y[i], H_before_aug) + a @ Y[i] + const)


a_last = 1
zs_last = None
lijs_last = None

a_this = 1
c_list = []
c_list_detail = [[] for _ in range(len(data_dict_list))]

for __ite__ in range(max_ite):
    # a_last = a_this
    # a_this = (1 + np.sqrt(1 + 4 * a_last ** 2)) / 2
    primal_residuals += [0]
    dual_residuals += [0]
    c_list += [0]
    if __ite__ >= 1:
        p1_last = p1
        p2_last = p2
        a_last = a_this = 1
        # a_last = a_this
        # a_this = (1 + np.sqrt(1 + 4 * a_last ** 2))/2
        p1 = [[] for _ in range(len(data_dict_list))]
        p2 = [[] for _ in range(len(data_dict_list))]
        Y_last = [_.value for _ in Y]
        zs_last = zs
        zs = [[] for _ in range(len(data_dict_list))]
        lijs_last = lijs
        for each in c_list_detail:
            each.append([0])
    else:
        c_list[0] = 100
        for each in c_list_detail:
            each.append([100])

    print("\r", end="")
    print("迭代次度: {}: ".format(__ite__), "▓" * (__ite__ * 100 // max_ite), end="")
    sys.stdout.flush()

    # X_UPDATE
    for i, prob in enumerate(probs):
        prob.solve(solver=cp.GUROBI)
        dual_residuals[__ite__] = max(dual_residuals[__ite__], max(Y[i].value - Y_last[i]))
    costs += [cost.value]
    # Z-UPDATE
    for i, each_item_i in enumerate(data_dict_list):
        a_list[i].value = np.array(each_item_i['a'])
        for pos_i, j in enumerate(each_item_i['enid']):
            each_item_j = data_dict_list[j]
            p1[i] += [each_item_i['Cij'][pos_i] @ Y[i].value + each_item_i['xi0'][pos_i]]
            p2[i] += [each_item_i['Cji'][pos_i] @ Y[j].value + each_item_i['xj0'][pos_i]]
            # lijs[i][pos_i] += rho/2 * (p1[i][pos_i] - p2[i][pos_i])

            if __ite__ == 0:
                zs[i] += [(p1[i][pos_i] + p2[i][pos_i])/2]
            else:
                zs[i] += [gamma * (p1[i][pos_i] + p2[i][pos_i])/2 + (1-gamma)*zhats[i][pos_i]]

            # accelij2[i][pos_i] = accelij1[i][pos_i] + 0                               # 2 =》 last
            # accelij1[i][pos_i] = lijs[i][pos_i] + rho/2 * (p1[i][pos_i] - p2[i][pos_i])
            # lijs[i][pos_i] = accelij1[i][pos_i] + (a_last - 1)/a_this * (accelij1[i][pos_i] - accelij2[i][pos_i])

            if __ite__ == 0:
                lijs[i][pos_i] = lijs[i][pos_i] + rho * (p1[i][pos_i] - zs[i][pos_i])
            else:
                lijs[i][pos_i] = lijhats[i][pos_i] + rho * (gamma*p1[i][pos_i] + (1-gamma)*zhats[i][pos_i] - zs[i][pos_i])

            if __ite__ >= 1:
                c_list[__ite__] += np.sum(rho * (gamma*p1[i][pos_i] + (1-gamma)*zhats[i][pos_i] - zs[i][pos_i]) ** 2)
                c_list[__ite__] += np.sum(rho * (zs[i][pos_i] - zhats[i][pos_i]) ** 2)
                c_list_detail[i][__ite__] += np.sum(rho * (gamma*p1[i][pos_i] + (1-gamma)*zhats[i][pos_i] - zs[i][pos_i]) ** 2)
                c_list_detail[i][__ite__] += np.sum(rho * (zs[i][pos_i] - zhats[i][pos_i]) ** 2)

            primal_residuals[__ite__] = max(primal_residuals[__ite__], max(np.abs(p1[i][pos_i] - p2[i][pos_i])))

    if c_list[__ite__] <= c_list[__ite__-1] * 0.999:
        number_of_acce += 1
    for i, each_item_i in enumerate(data_dict_list):
        a_list[i].value = np.array(each_item_i['a']) - each_item_i['prox'] * Y[i].value
        for pos_i, j in enumerate(each_item_i['enid']):
            each_item_j = data_dict_list[j]
            if __ite__ == 0:
                lijhats[i][pos_i] = lijs[i][pos_i] + 0
                zhats[i] += [zs[i][pos_i] + 0]
            else:
                if c_list[__ite__] <= c_list[__ite__-1] * 0.999 or True:
                    a_last = a_this = 1
                    lijhats[i][pos_i] = lijs[i][pos_i] + (a_last - 1)/a_this * (lijs[i][pos_i] - lijs_last[i][pos_i])
                    zhats[i][pos_i] = zs[i][pos_i] + (a_last - 1)/a_this * (zs[i][pos_i] - zs_last[i][pos_i])
                else:
                    a_this = 1
                    lijhats[i][pos_i] = lijs_last[i][pos_i] + 0
                    zhats[i][pos_i] = zs_last[i][pos_i] + 0
                    c_list[__ite__] = c_list[__ite__-1] / 0.999
            a_list[i].value += each_item_i['Cij'][pos_i].T @ (lijhats[i][pos_i] + rho * each_item_i['xi0'][pos_i]
                                                              - rho * zhats[i][pos_i])
    # print(a_list[0].value[0])


print()

X = []
for i, each_item_i in enumerate(data_dict_list):
    N = np.array(each_item_i['N'])
    x = np.array(each_item_i['x'])
    X.append(N @ Y[i].value + x)

print('所有节点发电量：')
for i, each_item_i in enumerate(data_dict_list):
    for dt in range(T):
        print("%8.4f" % X[i][dt], end=' ')
    print()

cost = 0

for i, each_item_i in enumerate(data_dict_list):
    H_before_aug = np.array(each_item_i['H_before_aug'])
    a = np.array(each_item_i['a'])
    const = np.array(each_item_i['const'])
    print("%8.4f" % (1 / 2 * cp.quad_form(Y[i], H_before_aug) + a @ Y[i] + const).value, end=" ")
    cost += (1 / 2 * cp.quad_form(Y[i], H_before_aug) + a @ Y[i] + const).value
print('所有节点成本：')
print(f'\n总成本：{round(cost, 4)}')

print("0号节点买卖电电价:")
for _i in range(24):
    print(lijs[0][0][_i], end=" ")
print()
for _i in range(24,48):
    print(lijs[0][0][_i], end=" ")
print()
for _i in range(48,72):
    print(lijs[0][0][_i], end=" ")
print()


print('所有节点上游功率：')
for i, each_item_i in enumerate(data_dict_list):
    for dt in range(T):
        print("%8.4f" % X[i][2 * T + dt], end=' ')
    print()

# print("-----迭代计算结果X2-------")
# print(X[2])
# print("------------------------")
# print('所有节点决策变量（masked）：')
# for i, each_item_i in enumerate(data_dict_list):
#     print(Y[i].value, end=' ')
#     print()
#
# print('所有节点决策变量：')
# for i, each_item_i in enumerate(data_dict_list):
#     print(X[i], end=' ')
#     print()

print(f"加速次数:{number_of_acce}")

with open("primal_residuals_s2.txt", "w") as file:
    for each in primal_residuals:
        file.write(str(each))
        file.write("\n")
with open("dual_residuals_s2.txt", "w") as file:
    for each in dual_residuals:
        file.write(str(each))
        file.write("\n")
with open("costs_s2.txt", "w") as file:
    for each in costs:
        file.write(str(each))
        file.write("\n")
plt.semilogy(primal_residuals)
plt.semilogy(dual_residuals)
plt.semilogy(c_list)
plt.legend(["primal residuals", "dual residuals", "combined residual"])
plt.axis([0, max_ite, 0.000001, 10])
plt.show()

print("\n")