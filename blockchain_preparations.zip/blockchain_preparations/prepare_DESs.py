import os

from network_config import *

DES_id_list = [ids[j] for j in DESs]
DES_name_list = [names[j] for j in DESs]


    # with open(f'config/{name}/formulation.json', 'w') as file:
    #     file.write(json.dumps(data_dict_list[j]))
