import numpy as np

# from scipy import stats
from network_config import ids, DESs

DES_id_list = [ids[j] for j in DESs]
T = 1
counter = 0

def generate_standard_form(m, enid,
                           pload, qload, hload,
                           rlist=None, xlist=None,
                           ptype='PQ',
                           tendency=1,
                           res=(False, None, 0),  # 上限列表、功率因数tan
                           cogen=(False, 0, 0, 0, 0,),  # 下限、上限，功率因数tan、热电比
                           hp=(False, 0, 0),  # 上限， COP
                           batt=(False, 0, 0, 0, 0.9, 0.9),  # 充电功率上限，放电功率上限，容量，充电效率，放电效率
                           heatsto=(False, 0, 0, 0, 0.00),  # 储热上限，放热上限，容量，漏热率
                           c_res=(0, 0),
                           c_cogen=(0, 0),
                           c_uppergrid=(550, 400),
                           non_coop=0,
                           comm="",
                           false_prop=1
                           ):
    if xlist is None:
        xlist = [0.001]
    if rlist is None:
        rlist = [0.001]
    global counter
    counter = counter + 1
    # all of the variables are initialized as:
    # [Pgi, Qgi]
    # 2 * T
    #  [Pui, Qui, ui]={(5*T)*1},  发电量、传输线功率、电压，本节点的基本参数
    #  [u_father]={T*1},  父节点的电压
    #  [Pu_child_1, Qu_child_1, Pu_child_2, Qu_child_2..] = {(T * m_neighbours) * 1},  子节点的发电量
    #  ------------------- 4 + 2 * (m - 1)
    #  [Hgi],
    # 1 * T
    #  -------------------8 + (n_up + n_down)

    m_child = m-1 if ptype == 'PQ' else m
    nx = 6 + (2 * m_child) + 1
    ndev = 0
    flags = []

    if res[0] is True:
        nx += 2
        ndev += 2
        flags += [1]
    else:
        flags += [0]
    if cogen[0] is True:
        nx += 3
        ndev += 3
        flags += [1]
    else:
        flags += [0]
    if hp[0] is True:
        nx += 2
        ndev += 2
        flags += [1]
    else:
        flags += [0]
    if batt[0] is True and T > 1:
        nx += 3
        ndev += 3
        flags += [1]
    else:
        flags += [0]
    if heatsto[0] is True and T > 1:
        nx += 3
        ndev += 3
        flags += [1]
    else:
        flags += [0]
    if ptype != 'PQ' or non_coop == 1:
        flags += [1]
        ndev += 3
        nx += 3
    else:
        flags += [0]

    nx_ext = nx * T
    # variables = cp.Variable(nx_ext)

    I = np.eye(T)
    O = np.zeros((T, T))
    e = np.ones(T)
    o = np.zeros(T)
    A_pqbalance = np.vstack(
        [np.hstack([I, O] + [I, O, O, O] + [-I, O] * m_child + [O] * (1 + ndev)),
         np.hstack([O, I] + [O, I, O, O] + [O, -I] * m_child + [O] * (1 + ndev))])
    b_pqbalance = np.hstack([pload, qload])

    if ptype == "PQ":
        R = rlist[0]
        X = xlist[0]
        A_powerflow = np.hstack(
            [O, O, 2 * R * I, 2 * X * I, I, -I] + [O] * (2 * m_child + 1 + ndev))
        b_powerflow = o
    else:
        A_powerflow = np.vstack([
            np.hstack([O, O, I, O, O, O] + [O] * (2 * m_child + 1 + ndev)),
            np.hstack([O, O, O, I, O, O] + [O] * (2 * m_child + 1 + ndev)),
            np.hstack([O, O, O, O, I, O] + [O] * (2 * m_child + 1 + ndev)),
            np.hstack([O, O, O, O, O, I] + [O] * (2 * m_child + 1 + ndev)),
            # np.hstack([I, O, O, O, O, O] + [O] * (2 * m_child + 1 + ndev)),
            # np.hstack([O, I, O, O, O, O] + [O] * (2 * m_child + 1 + ndev)),
        ])
        b_powerflow = np.hstack([o, o, e, o,])

    T0 = 273
    Tr = 293
    Tr_excess = Tr - T0
    # 建立热平衡约束(松弛)
    if np.max(np.abs(hload)) <= 1.e-3:
        G_hbalance = np.zeros((1, nx_ext))
        G_hbalance[0][0] = 1
        h_hbalance = np.hstack([100])
    else:
        G_hbalance = np.hstack([O] * (6 + 2 * m_child) + [-I] + [O] * ndev)
        h_hbalance = -np.hstack([hload])

    A_gen = np.vstack([
        np.hstack([-I, O] + [O] * (4 + 2 * m_child) + [O] + [I, O] * flags[0] + [I, O, O] * flags[1]
                  + [-I, O] * flags[2] + [O, -I, I * batt[5]] * flags[3] + [O, O, O] * flags[4]
                  + [I, -I, O] * flags[5]),

        np.hstack([O, -I] + [O] * (4 + 2 * m_child) + [O] + [O, I] * flags[0] + [O, I, O] * flags[1]
                  + [O, O] * flags[2] + [O, O, O] * flags[3] + [O, O, O] * flags[4] +
                  [O, O, I] * flags[5]),

        np.hstack([O, O] + [O] * (4 + 2 * m_child) + [-I] + [O, O] * flags[0] + [O, O, I] * flags[1]
                  + [O, I] * flags[2] + [O, O, O] * flags[3] + [O, -I, I] * flags[4] +
                  [O, O, O] * flags[5]),
    ])
    b_gen = np.zeros(3 * T)

    O_def = O[0:T - 1, :]

    A_dev = []
    b_dev = []
    G_dev = []
    h_dev = []

    if flags[0]:
        a = np.hstack(
            [O, O] + [O] * (4 + 2 * m_child) + [O] + [res[2] * I, -I] * flags[0] + [O, O, O] * flags[1] + [O, O] * flags[2] +
            [O, O, O] * flags[3] + [O, O, O] * flags[4] + [O, O, O] * flags[5])
        b = o
        A_dev.append(a)
        b_dev.append(b)

        for dt in range(T):
            if res[1][dt] <= 1.e-3:
                a = np.hstack([o, o] + [o] * (4 + 2 * m_child) + [o] +
                              [np.hstack([0] * dt + [1] + [0] * (T - dt - 1)), o] * flags[0] +
                              [o, o, o] * flags[1] + [o, o] * flags[2] +
                              [o, o, o] * flags[3] + [o, o, o] * flags[4] + [o, o, o] * flags[5])
                b = 0
                A_dev.append(a)
                b_dev.append(b)
            else:
                g1 = np.hstack([o, o] + [o] * (4 + 2 * m_child) + [o] +
                               [np.hstack([0] * dt + [1] + [0] * (T - dt - 1)), o] * flags[0] +
                               [o, o, o] * flags[1] + [o, o] * flags[2] +
                               [o, o, o] * flags[3] + [o, o, o] * flags[4] + [o, o, o] * flags[5])
                g2 = np.hstack([o, o] + [o] * (4 + 2 * m_child) + [o] +
                               [np.hstack([0] * dt + [-1] + [0] * (T - dt - 1)), o] * flags[0] +
                               [o, o, o] * flags[1] + [o, o] * flags[2] +
                               [o, o, o] * flags[3] + [o, o, o] * flags[4] + [o, o, o] * flags[5])
                h1 = res[1][dt]
                h2 = 0
                G_dev.append(g1)
                G_dev.append(g2)
                h_dev.append(h1)
                h_dev.append(h2)
    if flags[1]:
        if cogen[3] is not None:
            a = np.hstack([O, O] + [O] * (4 + 2 * m_child) + [O] + [O, O] * flags[0] + [cogen[3] * I, -I, O] * flags[1]
                          + [O, O] * flags[2] + [O, O, O] * flags[3] + [O, O, O] * flags[4] + [O, O, O] * flags[5])
            b = o
            A_dev.append(a)
            b_dev.append(b)

        a = np.hstack([O, O] + [O] * (4 + 2 * m_child) + [O] + [O, O] * flags[0] + [cogen[4] * I, O, -I] * flags[1]
                      + [O, O] * flags[2] + [O, O, O] * flags[3] + [O, O, O] * flags[4] + [O, O, O] * flags[5])
        b = o
        A_dev.append(a)
        b_dev.append(b)
        G_dev.append(np.vstack([
            np.hstack([O, O] + [O] * (4 + 2 * m_child) + [O] +
                      [O, O] * flags[0] + [I, O, O] * flags[1] + [O, O] * flags[2] +
                      [O, O, O] * flags[3] + [O, O, O] * flags[4] + [O, O, O] * flags[5]),
            np.hstack([O, O] + [O] * (4 + 2 * m_child) + [O] +
                      [O, O] * flags[0] + [-I, O, O] * flags[1] + [O, O] * flags[2] +
                      [O, O, O] * flags[3] + [O, O, O] * flags[4] + [O, O, O] * flags[5])
        ]))
        h_dev += [np.ones(T) * cogen[2], -np.ones(T) * cogen[1]]
    if flags[2]:
        a = np.hstack(
            [O, O] + [O] * (4 + 2 * m_child) + [O] + [O, O] * flags[0] + [O, O, O] * flags[1] + [hp[2] * I, -I] * flags[2] + \
            [O, O, O] * flags[3] + [O, O, O] * flags[4] + [O, O, O] * flags[5])
        b = o
        A_dev.append(a)
        b_dev.append(b)
        G_dev.append(np.vstack([
            np.hstack([O, O] + [O] * (4 + 2 * m_child) + [O] +
                      [O, O] * flags[0] + [O, O, O] * flags[1] + [I, O] * flags[2] +
                      [O, O, O] * flags[3] + [O, O, O] * flags[4] + [O, O, O] * flags[5]),
            np.hstack([O, O] + [O] * (4 + 2 * m_child) + [O] +
                      [O, O] * flags[0] + [O, O, O] * flags[1] + [-I, O] * flags[2] +
                      [O, O, O] * flags[3] + [O, O, O] * flags[4] + [O, O, O] * flags[5]),
        ]))
        h_dev += [np.ones(T) * hp[1], -np.zeros(T)]
    if flags[3] and T > 1:
        a = np.hstack([O_def, O_def] + [O_def] * (4 + 2 * m_child) + [O_def] +
                      [O_def, O_def] * flags[0] +
                      [O_def, O_def, O_def] * flags[1] +
                      [O_def, O_def] * flags[2] +
                      [(np.vstack([np.hstack([np.zeros((T - 1, 1)), np.eye(T - 1)]),
                                   np.hstack([np.array([[1]]), np.zeros((1, T - 1))])]) - I)[0:T - 1, :],
                       -I[0:T - 1, :] * batt[4],
                       I[0:T - 1, :]] * flags[3] +
                      [O_def, O_def, O_def] * flags[4] + [O_def, O_def, O_def] * flags[5])
        b = np.zeros(T - 1)
        A_dev.append(a)
        b_dev.append(b)
        a = np.hstack([o, o] + [o] * (4 + 2 * m_child) + [o] +
                              [o, o] * flags[0] +
                              [o, o, o] * flags[1] + [o, o] * flags[2] +
                              [np.hstack([1] + [0] * (T - 1)), o, o] * flags[3] + [o, o, o] * flags[4] + [o, o, o] * flags[5])
        b = batt[3] * 0.5
        A_dev.append(a)
        b_dev.append(b)
        G_dev.append(np.hstack(
            [o, o] + [o] * (4 + 2 * m_child) + [o] +
            [o, o] * flags[0] + [o, o, o] * flags[1] + [o, o] * flags[2] +
            [np.hstack([1] + [0] * (T - 2) + [-1]),
             np.hstack([0] * (T - 1) + [-1 * batt[4]]),
             np.hstack([0] * (T - 1) + [1])] * flags[3]
            + [o, o, o] * flags[4] + [o, o, o] * flags[5]
        ))
        h_dev += [0]

        G_dev.append(np.vstack([
            np.hstack([O, O] + [O] * (4 + 2 * m_child) + [O] +
                      [O, O] * flags[0] + [O, O, O] * flags[1] + [O, O] * flags[2] +
                      [I, O, O] * flags[3] + [O, O, O] * flags[4] + [O, O, O] * flags[5]),
            np.hstack([O, O] + [O] * (4 + 2 * m_child) + [O] +
                      [O, O] * flags[0] + [O, O, O] * flags[1] + [O, O] * flags[2] +
                      [-I, O, O] * flags[3] + [O, O, O] * flags[4] + [O, O, O] * flags[5])
        ]))
        h_dev += [np.ones(T) * batt[3], o]

        G_dev.append(np.vstack([
            np.hstack([O, O] + [O] * (4 + 2 * m_child) + [O] +
                      [O, O] * flags[0] + [O, O, O] * flags[1] + [O, O] * flags[2] +
                      [O, I, O] * flags[3] + [O, O, O] * flags[4] + [O, O, O] * flags[5]),
            np.hstack([O, O] + [O] * (4 + 2 * m_child) + [O] +
                      [O, O] * flags[0] + [O, O, O] * flags[1] + [O, O] * flags[2] +
                      [O, -I, O] * flags[3] + [O, O, O] * flags[4] + [O, O, O] * flags[5])
        ]))
        h_dev += [np.ones(T) * batt[1], o]

        G_dev.append(np.vstack([
            np.hstack([O, O] + [O] * (4 + 2 * m_child) + [O] +
                      [O, O] * flags[0] + [O, O, O] * flags[1] + [O, O] * flags[2] +
                      [O, O, I] * flags[3] + [O, O, O] * flags[4] + [O, O, O] * flags[5]),
            np.hstack([O, O] + [O] * (4 + 2 * m_child) + [O] +
                      [O, O] * flags[0] + [O, O, O] * flags[1] + [O, O] * flags[2] +
                      [O, O, -I] * flags[3] + [O, O, O] * flags[4] + [O, O, O] * flags[5])
        ]))
        h_dev += [np.ones(T) * batt[2], o]

    if flags[4] and T > 1:
        a = np.hstack([O_def, O_def] + [O_def] * (4 + 2 * m_child) + [O_def] +
                      [O_def, O_def] * flags[0] +
                      [O_def, O_def, O_def] * flags[1] +
                      [O_def, O_def] * flags[2] +
                      [O_def, O_def, O_def] * flags[3] +
                      [(np.vstack([np.hstack([np.zeros((T - 1, 1)), np.eye(T - 1) / (1 - heatsto[4])]),
                                   np.hstack([np.array([[1 / (1 - heatsto[4])]]), np.zeros((1, T - 1))])]) - I)[0:T - 1,
                       :],
                       -I[0:T - 1, :],
                       I[0:T - 1, :]] * flags[4] + [O_def, O_def, O_def] * flags[5])
        b = np.zeros(T - 1)
        A_dev.append(a)
        b_dev.append(b)

        a = np.hstack([o, o] + [o] * (4 + 2 * m_child) + [o] +
                              [o, o] * flags[0] +
                              [o, o, o] * flags[1] + [o, o] * flags[2] +
                              [o, o, o] * flags[3] + [np.hstack([1] + [0] * (T - 1)), o, o] * flags[4] + [o, o, o] * flags[5])
        b = heatsto[3] * 0.5
        A_dev.append(a)
        b_dev.append(b)
        G_dev.append(np.hstack(
            [o, o] + [o] * (4 + 2 * m_child) + [o] +
            [o, o] * flags[0] + [o, o, o] * flags[1] + [o, o] * flags[2] +
            [o, o, o] * flags[3] +
            [np.hstack([1 / (1 - heatsto[4])] + [0] * (T - 2) + [-1]),
             np.hstack([0] * (T - 1) + [-1]),
             np.hstack([0] * (T - 1) + [1])] * flags[4] + [o, o, o] * flags[5]
        ))
        h_dev += [0]

        G_dev.append(np.vstack([
            np.hstack([O, O] + [O] * (4 + 2 * m_child) + [O] +
                      [O, O] * flags[0] + [O, O, O] * flags[1] + [O, O] * flags[2] +
                      [O, O, O] * flags[3] + [I, O, O] * flags[4] + [O, O, O] * flags[5]),
            np.hstack([O, O] + [O] * (4 + 2 * m_child) + [O] +
                      [O, O] * flags[0] + [O, O, O] * flags[1] + [O, O] * flags[2] +
                      [O, O, O] * flags[3] + [-I, O, O] * flags[4] + [O, O, O] * flags[5])
        ]))
        h_dev += [np.ones(T) * heatsto[3], o]

        G_dev.append(np.vstack([
            np.hstack([O, O] + [O] * (4 + 2 * m_child) + [O] +
                      [O, O] * flags[0] + [O, O, O] * flags[1] + [O, O] * flags[2] +
                      [O, O, O] * flags[3] + [O, I, O] * flags[4] + [O, O, O] * flags[5]),
            np.hstack([O, O] + [O] * (4 + 2 * m_child) + [O] +
                      [O, O] * flags[0] + [O, O, O] * flags[1] + [O, O] * flags[2] +
                      [O, O, O] * flags[3] + [O, -I, O] * flags[4] + [O, O, O] * flags[5])
        ]))
        h_dev += [np.ones(T) * heatsto[1], o]

        G_dev.append(np.vstack([
            np.hstack([O, O] + [O] * (4 + 2 * m_child) + [O] +
                      [O, O] * flags[0] + [O, O, O] * flags[1] + [O, O] * flags[2] +
                      [O, O, O] * flags[3] + [O, O, I] * flags[4] + [O, O, O] * flags[5]),
            np.hstack([O, O] + [O] * (4 + 2 * m_child) + [O] +
                      [O, O] * flags[0] + [O, O, O] * flags[1] + [O, O] * flags[2] +
                      [O, O, O] * flags[3] + [O, O, -I] * flags[4] + [O, O, O] * flags[5])
        ]))
        h_dev += [np.ones(T) * heatsto[2], o]

    if flags[5]:
        G_dev.append(np.hstack(
            [O, O] + [O] * (2 * m_child + 4) + [O] +
            [O, O] * flags[0] + [O, O, O] * flags[1] + [O, O] * flags[2] +
            [O, O, O] * flags[3] +
            [O, O, O] * flags[4] + [-I, O, O] * flags[5]
        ))
        # G_dev.append(np.hstack(
        #     [O, O] + [O] * (2 * m_child + 4) + [O] +
        #     [O, O] * flags[0] + [O, O, O] * flags[1] + [O, O] * flags[2] +
        #     [O, O, O] * flags[3] +
        #     [O, O, O] * flags[4] + [I, O, O] * flags[5]
        # ))
        A_dev.append(np.hstack(
            [O, O] + [O] * (2 * m_child + 4) + [O] +
            [O, O] * flags[0] + [O, O, O] * flags[1] + [O, O] * flags[2] +
            [O, O, O] * flags[3] +
            [O, O, O] * flags[4] + [O, -I, O] * flags[5]
        ))
        # G_dev.append(np.hstack(
        #     [O, O] + [O] * (2 * m_child + 4) + [O] +
        #     [O, O] * flags[0] + [O, O, O] * flags[1] + [O, O] * flags[2] +
        #     [O, O, O] * flags[3] +
        #     [O, O, O] * flags[4] + [O, I, O] * flags[5]
        # ))
        # h_dev += [o, 1000 * e, o, 1000 * e]
        h_dev += [o]
        b_dev += [o]

    if tendency == 1:
        pass
    elif tendency == 2:
        pass
        # G_dev.append(np.vstack(
        # [np.hstack([-I, O] + [O, O, O, O] + [O, O] * m_child + [O] * (1 + ndev)),
        #  np.hstack([O, -I] + [O, O, O, O] + [O, O] * m_child + [O] * (1 + ndev))])
        # )
        # h_dev.append(np.hstack([-pload, -qload]))

        G_dev.append(np.hstack([-I, O] + [O, O, O, O] + [O, O] * m_child + [O] * (1 + ndev)))
        h_dev.append(-pload)
    elif tendency == 3 and T > 1:
        delta = 2/T
        A_dev.append(np.vstack([
            np.hstack([O, O] + [O] * (4 + 2 * m_child) + [O] +
                      [O, O] * flags[0] + [O, O, O] * flags[1] + [O, O] * flags[2] +
                      [I, O, O] * flags[3] + [O, O, O] * flags[4] + [O, O, O] * flags[5]),
        ])[1:T,:])
        sto_designed = np.array([6*delta, 5*delta, 4*delta, 3*delta, 2*delta, delta,
                                 0, delta, 2*delta, 3*delta, 4*delta, 5*delta,
                                 6*delta, 7*delta, 8*delta, 9*delta, 10*delta, 11*delta,
                                 12*delta, 11*delta, 10*delta, 9*delta, 8*delta, 7*delta])[1:T]
        b_dev += [sto_designed * batt[3]]

    if non_coop == 1:
        A_dev.append(np.vstack([
            np.hstack([O, O, I, O, O, O] + [O] * (2 * m_child + 1 + ndev)),
            np.hstack([O, O, O, I, O, O] + [O] * (2 * m_child + 1 + ndev))
        ]))
        b_dev += [np.hstack([o, o])]
    # A_dev = np.vstack(A_dev)
    # b_dev = np.hstack(b_dev)
    # G_dev = np.vstack(G_dev)
    # h_dev = np.hstack(h_dev)
    H = np.eye(nx_ext) * 0.01
    # 可再生成本
    for j in range((2 + (4 + 2 * m_child) + 1 + 0 * flags[0]) * T,
                   (2 + (4 + 2 * m_child) + 1 + 1 * flags[0]) * T):
        H[j][j] += c_res[0] * false_prop
    # 普通发电成本
    for j in range((2 + (4 + 2 * m_child) + 1 + (2 * flags[0] + 0 * flags[1])) * T,
                   (2 + (4 + 2 * m_child) + 1 + (2 * flags[0] + 1 * flags[1])) * T):
        H[j][j] += c_cogen[0] * false_prop

    c = -np.ones(nx_ext) * 0  # 5.e-3
    for j in range((2 + (4 + 2 * m_child) + 1 + 0 * flags[0]) * T,
                   (2 + (4 + 2 * m_child) + 1 + 1 * flags[0]) * T):
        c[j] += c_res[1] * false_prop
    for j in range((2 + (4 + 2 * m_child) + 1 + (2 * flags[0] + 0 * flags[1])) * T,
                   (2 + (4 + 2 * m_child) + 1 + (2 * flags[0] + 1 * flags[1])) * T):
        c[j] += c_cogen[1] * false_prop
    for j in range((2 + (4 + 2 * m_child) + 1 + (
            2 * flags[0] + 3 * flags[1] + 2 * flags[2] + 3 * flags[3] + 3 * flags[4] + 0 * flags[5])) * T,
                   (2 + (4 + 2 * m_child) + 1 + (
                           2 * flags[0] + 3 * flags[1] + 2 * flags[2] + 3 * flags[3] + 3 * flags[4] + 1 * flags[
                       5])) * T):
        c[j] += c_uppergrid[0]
    for j in range((2 + (4 + 2 * m_child) + 1 + (
            2 * flags[0] + 3 * flags[1] + 2 * flags[2] + 3 * flags[3] + 3 * flags[4] + 1 * flags[5])) * T,
                   (2 + (4 + 2 * m_child) + 1 + (
                           2 * flags[0] + 3 * flags[1] + 2 * flags[2] + 3 * flags[3] + 3 * flags[4] + 2 * flags[
                       5])) * T):
        c[j] += -c_uppergrid[1]

    # 所有的约束为：
    # A_pqbalance x = b_pqbalance (节点能量守恒)
    # A_powerflow x = b_powerflow (欧姆定律/潮流方程, 仅电网节点有)
    # G_hbalance x <= h_hbalance
    # A_gen x = b_gen (节点注入功率和各个设备之间的关系)
    # A_dev x = b_dev
    # G_dev x <= h_dev ()
    if not (A_dev == []):
        A = np.vstack([A_pqbalance, A_powerflow, A_gen, np.vstack(A_dev)])
        b = np.hstack([b_pqbalance, b_powerflow, b_gen, np.hstack(b_dev)])
    else:
        A = np.vstack([A_pqbalance, A_powerflow, A_gen])
        b = np.hstack([b_pqbalance, b_powerflow, b_gen])
    if not (G_dev == []):
        G = np.vstack([np.vstack(G_dev), G_hbalance])
        h = np.hstack([np.hstack(h_dev), h_hbalance])
    else:
        G = np.vstack([G_hbalance])
        h = np.hstack([h_hbalance])

    assert np.linalg.matrix_rank(A) - A.shape[0] == 0

    # R = np.eye(nx_ext) @ stats.ortho_group.rvs(nx_ext)
    q, r = np.linalg.qr(A.T, mode='complete')
    C = q[:, 0:A.shape[0]]
    N = q[:, A.shape[0]:]
    x0 = C @ np.linalg.inv(r[0:A.shape[0], 0:A.shape[0]].T) @ b

    # variables_simp = cp.Variable(A.shape[1] - A.shape[0])
    # test_cost = 1 / 2 * cp.quad_form(variables, R.T @ H @ R) + c @ R @ variables
    # test_cons = [A @ R @ variables == b,
    #              G @ R @ variables <= h]
    # test_prob = cp.Problem(cp.Minimize(test_cost), test_cons)
    # test_prob.solve(solver=cp.ECOS)

    from scipy import stats
    R = np.eye(A.shape[1] - A.shape[0]) #@ stats.ortho_group.rvs(A.shape[1] - A.shape[0])

    Cij = []
    xi0 = []
    start = 0 if ptype == 'VT' else 1
    if ptype == "PQ":
        Cij += [np.vstack([np.hstack([O, O, I, O, O, O] + [O] * (nx - 6)),
                           np.hstack([O, O, O, I, O, O] + [O] * (nx - 6)),
                           np.hstack([O, O, O, O, O, I] + [O] * (nx - 6))]) @ N @ R]
        xi0 += [np.vstack([np.hstack([O, O, I, O, O, O] + [O] * (nx - 6)),
                           np.hstack([O, O, O, I, O, O] + [O] * (nx - 6)),
                           np.hstack([O, O, O, O, O, I] + [O] * (nx - 6))]) @ x0]
    xj0 = []
    for each in range(start, m):
        j = each - start + 1
        Cij += [np.vstack([np.hstack([O, O, O, O, O, O] + [O] * 2 * (j - 1) + [I, O] + [O] * (nx - 6 - 2 * j)),
                           np.hstack([O, O, O, O, O, O] + [O] * 2 * (j - 1) + [O, I] + [O] * (nx - 6 - 2 * j)),
                           np.hstack([O, O, O, O, I, O] + [O] * (nx - 6))]) @ N @ R]
        xi0 += [np.vstack([np.hstack([O, O, O, O, O, O] + [O] * 2 * (j - 1) + [I, O] + [O] * (nx - 6 - 2 * j)),
                           np.hstack([O, O, O, O, O, O] + [O] * 2 * (j - 1) + [O, I] + [O] * (nx - 6 - 2 * j)),
                           np.hstack([O, O, O, O, I, O] + [O] * (nx - 6))]) @ x0]
    rho = np.hstack([np.ones(T)*np.sqrt(400), np.ones(T)*np.sqrt(1.9), np.ones(T)*np.sqrt(0.9)]).reshape((3*T, 1))
    prox = 0.0
    H_pre = R.T @ N.T @ H @ N @ R
    H_before_aug = np.copy(H_pre)
    for _ in Cij:
        H_pre += ((rho*_).T @ (rho*_))
    for _ in range(H_pre.shape[0]):
        H_pre[_][_] += prox


    # if ptype == "PQ":
    #     Cij += [np.hstack([O, O, O, O, O, I] + [O] * (nx - 6)) @ N]
    #     xi0 += [np.hstack([O, O, O, O, O, I] + [O] * (nx - 6)) @ x0]
    # for each in range(start, m):
    #     j = each - start + 1
    #     Cij += [np.vstack([np.hstack([O, O, O, O, O, O] + [O] * 2 * (j - 1) + [I, O] + [O] * (nx - 6 - 2 * j)),
    #                        np.hstack([O, O, O, O, O, O] + [O] * 2 * (j - 1) + [O, I] + [O] * (nx - 6 - 2 * j))]) @ N]
    #     xi0 += [np.vstack([np.hstack([O, O, I, O, O, O] + [O] * (nx - 6)),
    #                        np.hstack([O, O, O, I, O, O] + [O] * (nx - 6))]) @ x0]
    # Cji = []
    # xj0 = []
    G_pre = G @ N @ R
    h_pre = h - G @ x0
    for row in range(G_pre.shape[0]):
        if (np.abs(G_pre[row]) < 1.e-8).all():
            # print(counter)
            G_pre[row][0] = 1
            h_pre[row] = 100
    return {
        "H": H_pre.tolist(),
        "a": ((c + x0.T @ H) @ N @ R).tolist(),
        'const': (1 / 2 * x0 @ H @ x0 + c @ x0).tolist(),
        'G': G_pre.tolist(),
        'h': h_pre.tolist(),
        'Cij': [_.tolist() for _ in Cij],
        'xi0': [_.tolist() for _ in xi0],
        # 'Cji_for_father': np.vstack([np.hstack([O, O, I, O, O, O] + [O] * (nx - 6)),
        #                              np.hstack([O, O, O, I, O, O] + [O] * (nx - 6))]) @ N,
        # 'Cji_for_child': np.vstack([np.hstack([O, O, O, O, O, I] + [O] * (nx - 6))]) @ N,
        'Cji': [],
        'xj0': [],
        'N': (N @ R).tolist(),
        'R': R.tolist(),
        'x': x0.tolist(),
        'rho': rho.tolist(),
        'H_ori': H.tolist(),
        "c_ori": c.tolist(),
        "H_before_aug": H_before_aug.tolist(),
        "prox": prox,
        'T': T,
        'enid': enid,
        'false_prop': false_prop
    }
