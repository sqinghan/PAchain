import os
import subprocess as sp

# check if folder "ca-cert" exists
# if not, create it
# if yes, delete it
if os.path.exists("ca-cert"):
    # print("ca-cert path exists. Do you want to delete it and continue? (y/n)")
    # if input().lower() == "y":
    #     pass
    # else:
    #     exit()
    sp.call(["rmdir", "/s", "/q", "ca-cert"], shell=True)
sp.call(["mkdir", "ca-cert"], shell=True)

# 1. generate a root CA certificate and private key
sp.call(['openssl', 'genrsa', '-out', 'ca-cert/ca.key', '2048'], shell=True)
# 2. generate CSR with config file
sp.call(['openssl', 'req', '-new', '-key', 'ca-cert/ca.key', '-out', 'ca-cert/ca.csr', '-config', 'ca.cnf'], shell=True)
# 3. create a self-signed CA certificate
# validDate = input("Enter the expiration (days) of the certificate: ")
sp.call(['openssl', 'x509', '-req',
         '-days', '180',
         '-in', 'ca-cert/ca.csr',
         '-signkey', 'ca-cert/ca.key',
         '-extensions', 'v3_ca',
         '-extfile', 'ca.cnf',
         '-out', 'ca-cert/ca.crt'], shell=True)
print("CA certificate and private key generated")
