import os

from network_config import *

DES_id_list = [ids[j] for j in DESs]
DES_name_list = [names[j] for j in DESs]

miner_id_list = [ids[j] for j in miners]
miner_name_list = [names[j] for j in miners]


if not os.path.exists('config'):
    os.mkdir('config')
for j, name in enumerate(miner_name_list):
    if not os.path.exists(f'config/{name}'):
        os.mkdir(f'config/{name}')
    with open(f'config/{name}/personal_settings.ini', 'w') as file:
        file.write(
            f"""[personal_info]
name = {name}
uuid = {miner_id_list[j]}
ip = 127.0.0.1
port = {j + 5000}
db_username = chainnode_{j+1}
db_database = chainnode_{j+1}
[key_info]
cert = {name}.crt
key = {name}.key
cert_path = ../certs
[peer_info]
miner_name_list = {[names[j] for j in miners]}
miner_host_list = {[hosts[j] for j in miners]}
miner_id_list = {[str(ids[j]) for j in miners]}
worker_name_list = {[names[j] for j in workers]}
worker_host_list = {[hosts[j] for j in workers]}
worker_id_list = {[str(ids[j]) for j in workers]}
DES_name_list = {[names[j] for j in DESs]}
DES_host_list = {[hosts[j] for j in DESs]}
DES_id_list = {[str(ids[j]) for j in DESs]}"""
        )
    # with open(f'config/{name}/formulation.json', 'w') as file:
    #     file.write(json.dumps(data_dict_list[j]))
