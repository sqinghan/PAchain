import json
import os

import numpy as np

import formulation
from formulation import generate_standard_form
# from scipy import stats
from network_config_37 import *

T = formulation.T = 24
st =0

pload_ref = np.array(
    [1.2144038958333332, 0.9896153958333334, 0.7402298958333333, 0.8761478958333334, 0.7988603958333333,
     0.7212353958333333, 0.7167398958333333, 0.8864753958333333, 0.8426543958333333, 0.9952448958333333,
     1.0222988958333334, 1.1842988958333334, 1.0903118958333333, 1.0211513958333334, 1.0020083958333332,
     0.9501818958333333, 1.0127138958333333, 1.1915723958333333, 1.1083583958333334, 1.1169633958333333,
     1.1718273958333334, 1.0495443958333332, 1.2791738958333332,0.9992973958333335])[st:st+T]*0.5
qload_ref = pload_ref * 0.5
hload_ref = np.array(
        [1.624784, 1.638504, 1.6162159999999999, 1.5983239999999999, 1.61203, 1.5983239999999999, 1.5979039999999998,
         1.54952, 1.5264339999999998, 1.503348, 1.491812, 1.491518, 1.4835379999999998, 1.491812, 1.503348, 1.503348,
         1.503348, 1.5355479999999997, 1.551648, 1.5838480000000001, 1.5765959999999999, 1.622796, 1.6587899999999998,
         1.64577])[st:st+T]
res_ref = np.array([[0] * T,
                    [0] * T,
                    [0, 0, 0, 0, 0, 0, 0.100949253, 0.315997541, 0.474579416, 0.657945325, 0.68574479, 0.604655655,
                     0.71258068, 0.656914195, 0.553506591, 0.490404576, 0.251662218, 0.103382833, 0, 0, 0, 0, 0, 0][
                    st:st+T],
                    [0] * T,
                    [0, 0, 0, 0, 0, 0, 0.105598604, 0.279935569, 0.466004864, 0.53631236, 0.593271175, 0.615781596,
                     0.762409542, 0.684955459, 0.526937186, 0.505547652, 0.260079043, 0.104478731, 0, 0, 0, 0, 0, 0][
                    st:st+T],
                    [0] * T,
                    [0, 0, 0, 0, 0, 0, 0.099546833, 0.258707523, 0.495263306, 0.605575024, 0.586427903, 0.722821769,
                     0.605961626, 0.660333068, 0.624532266, 0.487809578, 0.287682209, 0.113171569, 0, 0, 0, 0, 0, 0][
                    st:st+T],
                            [0.691225245, 0.414056967, 0.476091694, 0.526446598, 0.441226356, 0.474464105, 0.445550482,
                             0.421585603, 0.475253551, 0.576896466, 0.494331734, 0.536518692, 0.633654027, 0.336525468,
                             0.341682659, 0.374460552, 0.366086197, 0.3590915, 0.400445336, 0.368258254, 0.475447777,
                             0.542314323, 0.505545943, 0.478702393][st:st+T],
                    [0] * T,
                    [0, 0, 0, 0, 0, 0, 0.106369706, 0.298881466, 0.380106205, 0.590286529, 0.724331158, 0.738907282,
                     0.783817547, 0.712861619, 0.568653731, 0.478731304, 0.253980025, 0.110102457, 0, 0, 0, 0, 0, 0][
                    st:st+T],
                    ])*0.2
pqh_coeff = np.array([[0, 0, 0], # 799 0
             [630, 315, 0],  # 701 1
             [0, 0, 0],  # 702 2
             [0, 0, 0],  # 703 3
             [0, 0, 0],  # 704 4
             [0, 0, 0],  # 705 5
             [0, 0, 0],  # 706 6
             [0, 0, 0],  # 707 7
             [0, 0, 0],  # 708 8
             [0, 0, 0],  # 709 9
             [0, 0, 0], # 710 10
             [0, 0, 0], # 711 11
             [85, 40, 0], # 712 12
             [85, 40, 0], # 713 13
             [38, 18, 0], # 714 14
             [85, 40, 0], # 718 15
             [85, 40, 0], # 720 16
             [161, 80, 0], # 722 17
             [42, 21, 0], # 724 18
             [42, 21, 0], # 725 19
             [42, 21, 0], # 727 20
             [126, 63, 0], # 728 21
             [42, 21, 0], # 729 22
             [85, 40, 0], # 730 23
             [85, 40, 0], # 731 24
             [42, 21, 0], # 732 25
             [85, 40, 0], # 733 26
             [85, 40, 0], # 734 27
             [85, 40, 0], # 735 28
             [85, 40, 0], # 736 29
             [140, 70, 0], # 737 30
             [126, 62, 0], # 738 31
             [85, 40, 0], # 740 32
             [42, 21, 0], # 741 33
             [93, 44, 0], # 742 34
             [126, 62, 0], # 744 35
             [126, 62, 0], # 775 36
             ]) / 1000

neighbours = [[1], # 799 0
              [0, 2],
              [1, 3, 5, 13],
              [2, 20, 23],
              [13, 14, 16],
              [2, 12, 34],
              [16, 19],
              [16, 17, 18],
              [9, 25, 26],
              [23, 8, 24, 36],
              [27, 28, 29],
              [31, 32, 33],
              [5],
              [2, 4],
              [4, 15],
              [14],
              [4, 6, 7],
              [7],
              [7],
              [6],
              [3, 35],
              [35],
              [35],
              [3, 9],
              [9],
              [8],
              [8, 27],
              [26, 10, 30],
              [10],
              [10],
              [27, 31],
              [30, 11],
              [11],
              [11],
              [5],
              [20, 21, 22],
              [9],
              ]

data_dict_list = []

for node_rank in range(37):
    pa = {}
    if node_rank == 0:
        pa = {'ptype':'VT',
              'c_uppergrid': (550, 200)}
    else:
        if pqh_coeff[node_rank][0] >= 0.1:
            pa['cogen'] = (True,
                           0.24*pqh_coeff[node_rank][0],
                           1.20*pqh_coeff[node_rank][0],
                           0.5, 0)
            pa['c_cogen'] = (150, 450)
        elif pqh_coeff[node_rank][0] >= 0:
            pa['batt'] = (True,
                          0.1*pqh_coeff[node_rank][0],
                          0.1*pqh_coeff[node_rank][0],
                          0.4*pqh_coeff[node_rank][0],
                          0.9, 0.9)
        if node_rank >= 20 and node_rank <= 29:
            pa['res'] = (True, res_ref[node_rank - 20], 0.33)
            pa['c_res'] = (10, 20)

    node_data = generate_standard_form(len(neighbours[node_rank]),
                                       neighbours[node_rank],
                                       pqh_coeff[node_rank][0] * pload_ref,
                                       pqh_coeff[node_rank][1] * qload_ref,
                                       pqh_coeff[node_rank][2] * hload_ref,
                                       **pa)
    data_dict_list += [node_data]
DES_id_list = [str(ids[j]) for j in DESs]
DES_name_list = [names[j] for j in DESs]

if __name__ == "__main__":

    for i, each_item_i in enumerate(data_dict_list):
        each_id_i = DES_id_list[i]
        for pos_i, j in enumerate(each_item_i['enid']):
            each_id_j = DES_id_list[j]
            # j = DES_id_list.index(each_id_j)
            each_item_j = data_dict_list[j]
            pos_j = each_item_j['enid'].index(i)
            each_item_i['Cji'] += [each_item_j['Cij'][pos_j]]
            each_item_i['xj0'] += [each_item_j['xi0'][pos_j]]



    if not os.path.exists('config37'):
        os.mkdir('config37')
    for j, name in enumerate(DES_name_list):
        if not os.path.exists(f'config37/{name}'):
            os.mkdir(f'config37/{name}')
        with open(f'config37/{name}/formulation.json', 'w') as file:
            file.write(json.dumps(data_dict_list[j]))


    if not os.path.exists('config37'):
        os.mkdir('config37')
    for j, name in enumerate(DES_name_list):
        if not os.path.exists(f'config37/{name}'):
            os.mkdir(f'config37/{name}')
        print(name)
        with open(f'config37/{name}/personal_settings.ini', 'w') as file:
            file.write(
                f"""[personal_info]
    name = {name}
    uuid = {DES_id_list[j]}
    ip = 127.0.0.1
    port = {j + 5060}
    [key_info]
    cert = {name}.crt
    key = {name}.key
    cert_path = ../certs
    [peer_info]
    miner_name_list = {[names[j] for j in miners]}
    miner_host_list = {[hosts[j] for j in miners]}
    miner_id_list = {[str(ids[j]) for j in miners]}
    worker_name_list = {[names[j] for j in workers]}
    worker_host_list = {[hosts[j] for j in workers]}
    worker_id_list = {[str(ids[j]) for j in workers]}
    neighbour_name_list = {[str(DES_name_list[_]) for _ in data_dict_list[j]['enid']]}
    neighbour_id_list = {[str(DES_id_list[_]) for _ in data_dict_list[j]['enid']]}"""
            )



    # import cvxpy as cp
    # Y = []
    # cons = []
    # target = 0
    # for i, each_item_i in enumerate(data_dict_list):
    #     H = np.array(each_item_i['H_before_aug'])
    #     G = np.array(each_item_i['G'])
    #     h = np.array(each_item_i['h'])
    #     a = np.array(each_item_i['a'])
    #     const = np.array(each_item_i['const'])
    #     Y.append(cp.Variable(H.shape[0]))
    #     target += 1/2 * cp.quad_form(Y[i], H) + a @ Y[i] + const
    #     cons += [G @ Y[i] <= h]
    #     # print(cp.Problem(cp.Minimize(cp.quad_form(y, H)), [G @ y <= h]).solve())
    # for i, each_item_i in enumerate(data_dict_list):
    #     for pos_i, j in enumerate(each_item_i['enid']):
    #         if i < j:
    #             # print(i, j)
    #             each_item_j = data_dict_list[j]
    #             cons += [np.array(each_item_i['Cij'][pos_i]) @ Y[i] + np.array(each_item_i['xi0'][pos_i]) ==
    #                      np.array(each_item_i['Cji'][pos_i]) @ Y[j] + np.array(each_item_i['xj0'][pos_i])]
    # pb = cp.Problem(cp.Minimize(target),constraints=cons)
    # pb.solve(solver=cp.GUROBI, ignore_dpp=True)
    # print(pb.status)
    # print(pb.value)
    # X = []
    # for i, each_item_i in enumerate(data_dict_list):
    #     N = np.array(each_item_i['N'])
    #     x = np.array(each_item_i['x'])
    #     X.append(N @ Y[i].value + x)
    #
    #
    # print('所有节点发电量：')
    # for i, each_item_i in enumerate(data_dict_list):
    #     for dt in range(T):
    #         print(X[i][dt], end=' ')
    #     print()
    # print('所有节点成本：')
    # for i, each_item_i in enumerate(data_dict_list):
    #     H = np.array(each_item_i['H'])
    #     a = np.array(each_item_i['a'])
    #     const = np.array(each_item_i['const'])
    #     H_ori = np.array(each_item_i['H_ori'])
    #     c_ori = np.array(each_item_i['c_ori'])
    #     print((1/2 * cp.quad_form(Y[i], H) + a @ Y[i] + const).value)
    #     print((1/2 * cp.quad_form(X[i], H_ori) + c_ori @ X[i]).value)
    # print('所有节点上游功率：')
    # for i, each_item_i in enumerate(data_dict_list):
    #     for dt in range(T):
    #         print(X[i][2*T + dt], end=' ')
    #     print()
    # print('所有节点决策变量（masked）：')
    # for i, each_item_i in enumerate(data_dict_list):
    #     print(Y[i].value, end=' ')
    #     print()
    #
    # print('所有节点决策变量：')
    # for i, each_item_i in enumerate(data_dict_list):
    #     print(X[i], end=' ')
    #     print()