import random
import uuid

names = ['miner0', 'miner1', 'miner2', 'miner3',
         'worker0', 'worker1', 'worker2', 'worker3', 'worker4', 'worker5', 'worker6', 'worker7', 'worker8', 'worker9',
         'DES0', 'DES1', 'DES2', 'DES3', 'DES4', 'DES5', 'DES6', 'DES7', 'DES8', 'DES9']
path = 'config'
types = ['miner', 'miner', 'miner', 'miner',
         'worker', 'worker', 'worker', 'worker', 'worker', 'worker', 'worker', 'worker', 'worker', 'worker',
         'DES', 'DES', 'DES', 'DES', 'DES', 'DES', 'DES', 'DES', 'DES', 'DES'
         ]
hosts = ['127.0.0.1:5000', '127.0.0.1:5001', '127.0.0.1:5002', '127.0.0.1:5003',
         '127.0.0.1:6000', '127.0.0.1:6001', '127.0.0.1:6002', '127.0.0.1:6003', '127.0.0.1:6004', '127.0.0.1:6005',
         '127.0.0.1:6006', '127.0.0.1:6007','127.0.0.1:6008','127.0.0.1:6009',
         '127.0.0.1:5060', '127.0.0.1:5061', '127.0.0.1:5062', '127.0.0.1:5063', '127.0.0.1:5064',
         '127.0.0.1:5065', '127.0.0.1:5066', '127.0.0.1:5067', '127.0.0.1:5068', '127.0.0.1:5069', ]

host_names = ['miner0.chainnode.dmchain.com', 'miner1.chainnode.dmchain.com',
              'miner2.chainnode.dmchain.com', 'miner3.chainnode.dmchain.com',
              'worker0.chainnode.dmchain.com', 'worker1.chainnode.dmchain.com', 'worker2.chainnode.dmchain.com',
              'worker3.chainnode.dmchain.com', 'worker4.chainnode.dmchain.com', 'worker5.chainnode.dmchain.com',
              'worker6.chainnode.dmchain.com', 'worker7.chainnode.dmchain.com', 'worker8.chainnode.dmchain.com', 'worker9.chainnode.dmchain.com',
              '127.0.0.1:5060', '127.0.0.1:5061', '127.0.0.1:5062', '127.0.0.1:5063', '127.0.0.1:5064',
              '127.0.0.1:5065', '127.0.0.1:5066', '127.0.0.1:5067', '127.0.0.1:5068', '127.0.0.1:5069', ]

rd = random.Random()
rd.seed(0)

ids = [uuid.UUID(int=rd.getrandbits(128)) for j in range(24)]
miners = [0, 1, 2, 3]
workers = [4, 5, 6, 7, 8, 9, 10, 11, 12, 13]
DESs = [14, 15, 16, 17, 18, 19, 20, 21, 22, 23]
