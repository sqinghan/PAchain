import json
import os

import numpy as np

import formulation
from formulation import generate_standard_form
# from scipy import stats
from network_config import *

T = formulation.T = 24
st = 0

pload_ref = np.array(
    [1.2144038958333332, 0.9896153958333334, 0.7402298958333333, 0.8761478958333334, 0.7988603958333333,
     0.7212353958333333, 0.7167398958333333, 0.8864753958333333, 0.8426543958333333, 0.9952448958333333,
     1.0222988958333334, 1.1842988958333334, 1.0903118958333333, 1.0211513958333334, 1.0020083958333332,
     0.9501818958333333, 1.0127138958333333, 1.4915723958333333, 1.4083583958333334, 1.3169633958333333,
     1.3718273958333334, 1.2495443958333332, 1.5791738958333332, 1.1992973958333335])[st:st+T]*0.5
qload_ref = pload_ref * 0.6
hload_ref = np.array(
        [1.624784, 1.638504, 1.6162159999999999, 1.5983239999999999, 1.61203, 1.5983239999999999, 1.5979039999999998,
         1.54952, 1.5264339999999998, 1.503348, 1.491812, 1.491518, 1.4835379999999998, 1.491812, 1.503348, 1.503348,
         1.503348, 1.5355479999999997, 1.551648, 1.5838480000000001, 1.5765959999999999, 1.622796, 1.6587899999999998,
         1.64577])[st:st+T]
res_ref = np.array([[0] * T,
                    [0] * T,
                    [0, 0, 0, 0, 0, 0, 0.100949253, 0.315997541, 0.474579416, 0.657945325, 0.68574479, 0.604655655,
                     0.71258068, 0.656914195, 0.553506591, 0.490404576, 0.251662218, 0.103382833, 0, 0, 0, 0, 0, 0][
                    st:st+T],
                    [0] * T,
                    [0, 0, 0, 0, 0, 0, 0.105598604, 0.279935569, 0.466004864, 0.53631236, 0.593271175, 0.615781596,
                     0.762409542, 0.684955459, 0.526937186, 0.505547652, 0.260079043, 0.104478731, 0, 0, 0, 0, 0, 0][
                    st:st+T],
                    [0] * T,
                    [0, 0, 0, 0, 0, 0, 0.099546833, 0.258707523, 0.495263306, 0.605575024, 0.586427903, 0.722821769,
                     0.605961626, 0.660333068, 0.624532266, 0.487809578, 0.287682209, 0.113171569, 0, 0, 0, 0, 0, 0][
                    st:st+T],
                            [0.691225245, 0.414056967, 0.476091694, 0.526446598, 0.441226356, 0.474464105, 0.445550482,
                             0.421585603, 0.475253551, 0.576896466, 0.494331734, 0.536518692, 0.633654027, 0.336525468,
                             0.341682659, 0.374460552, 0.366086197, 0.3590915, 0.400445336, 0.368258254, 0.475447777,
                             0.542314323, 0.505545943, 0.478702393][st:st+T],
                    [0] * T,
                    [0, 0, 0, 0, 0, 0, 0.106369706, 0.298881466, 0.380106205, 0.590286529, 0.724331158, 0.738907282,
                     0.783817547, 0.712861619, 0.568653731, 0.478731304, 0.253980025, 0.110102457, 0, 0, 0, 0, 0, 0][
                    st:st+T],
                    ])*2
pqh_coeff = [[0, 0, 0],  # 0
             [1.2, 1.2, 0],  # 1
             [1, 1, 1],  # 2
             [0.92, 0.92, 0],  # 3
             [0.96, 0.96, 0.9],  # 4
             [0, 0, 0],  # 5
             [1.5, 1.5, 1.5],  # 6
             [1.1, 1.1, 1.1],  # 7
             [0.67, 0.67, 0],  # 8
             [1, 1, 0]]  # 9
data_dict_list = [generate_standard_form(1, [1],
                                         pqh_coeff[0][0] * pload_ref, pqh_coeff[0][1] * qload_ref,
                                         pqh_coeff[0][2] * hload_ref,
                                         ptype='VT',
                                         c_uppergrid=(550, 200)),  # DES0
                  generate_standard_form(4, [0, 2, 3, 5],
                                         pqh_coeff[1][0] * pload_ref, pqh_coeff[1][1] * qload_ref,
                                         pqh_coeff[1][2] * hload_ref,
                                         cogen=(True, 0.1, 0.5, 0.5, 0),
                                         batt=(True, 0.1, 0.1, 0.2, 0.9, 0.9),
                                         c_cogen=(150, 400)),  # DES1

                  generate_standard_form(1, [1],
                                         pqh_coeff[2][0] * pload_ref, pqh_coeff[2][1] * qload_ref,
                                         pqh_coeff[2][2] * hload_ref,
                                         res=(True, res_ref[2], 0.33),
                                         cogen=(True, 0.25, 1.25, 0.2, 2),
                                         batt=(True, 0.1, 0.1, 0.2, 0.9, 0.9),
                                         heatsto=(True, 0.3, 0.3, 1.2, 0.01),
                                         c_res=(10, 20),
                                         c_cogen=(150, 400)),  # DES2

                  generate_standard_form(2, [1, 4],
                                         pqh_coeff[3][0] * pload_ref, pqh_coeff[3][1] * qload_ref,
                                         pqh_coeff[3][2] * hload_ref,
                                         cogen=(True, 0.2, 0.8, 0.5, 0),
                                         batt=(True, 0.1, 0.1, 0.2, 0.9, 0.9),
                                         c_cogen=(150, 400)),  # DES3

                  generate_standard_form(1, [3],
                                         pqh_coeff[4][0] * pload_ref, pqh_coeff[4][1] * qload_ref,
                                         pqh_coeff[4][2] * hload_ref,
                                         res=(True, res_ref[4], 0.33),
                                         cogen=(True, 0.25, 1.25, 0.2, 2),
                                         hp=(True, 0.5, 2),
                                         c_res=(10, 20),
                                         c_cogen=(200, 370)),  # DES4

                  generate_standard_form(2, [1, 6],
                                         pqh_coeff[5][0] * pload_ref, pqh_coeff[5][1] * qload_ref,
                                         pqh_coeff[5][2] * hload_ref),  # DES 5

                  generate_standard_form(3, [5, 7, 8],
                                         pqh_coeff[6][0] * pload_ref, pqh_coeff[6][1] * qload_ref,
                                         pqh_coeff[6][2] * hload_ref,
                                         res=(True, res_ref[6], 0.33),
                                         hp=(True, 1.5, 2),
                                         c_res=(10, 20)),  # DES 6

                  generate_standard_form(2, [6, 9],
                                         pqh_coeff[7][0] * pload_ref, pqh_coeff[7][1] * qload_ref,
                                         pqh_coeff[7][2] * hload_ref,
                                         res=(True, res_ref[7], 0.33),
                                         cogen=(True, 0.3, 1.5, 0.2, 1),
                                         hp=(True, 1.2, 1.8),
                                         c_res=(10, 20),
                                         c_cogen=(100, 400)),  # DES 7

                  generate_standard_form(1, [6],
                                         pqh_coeff[8][0] * pload_ref, pqh_coeff[8][1] * qload_ref,
                                         pqh_coeff[8][2] * hload_ref,
                                         batt=(True, 0.5, 0.5, 2, 0.9, 0.9)),  # DES 8

                  generate_standard_form(1, [7],
                                         pqh_coeff[9][0] * pload_ref, pqh_coeff[9][1] * qload_ref,
                                         pqh_coeff[9][2] * hload_ref,
                                         res=(True, res_ref[9], 0.2),
                                         c_res=(10, 20)),  # DES 9
                  ]
DES_id_list = [str(ids[j]) for j in DESs]
DES_name_list = [names[j] for j in DESs]

if __name__ == "__main__":

    for i, each_item_i in enumerate(data_dict_list):
        each_id_i = DES_id_list[i]
        for pos_i, j in enumerate(each_item_i['enid']):
            each_id_j = DES_id_list[j]
            # j = DES_id_list.index(each_id_j)
            each_item_j = data_dict_list[j]
            pos_j = each_item_j['enid'].index(i)
            each_item_i['Cji'] += [each_item_j['Cij'][pos_j]]
            each_item_i['xj0'] += [each_item_j['xi0'][pos_j]]



    if not os.path.exists('config'):
        os.mkdir('config')
    for j, name in enumerate(DES_name_list):
        if not os.path.exists(f'config/{name}'):
            os.mkdir(f'config/{name}')
        with open(f'config/{name}/formulation.json', 'w') as file:
            file.write(json.dumps(data_dict_list[j]))


    if not os.path.exists('config'):
        os.mkdir('config')
    for j, name in enumerate(DES_name_list):
        if not os.path.exists(f'config/{name}'):
            os.mkdir(f'config/{name}')
        with open(f'config/{name}/personal_settings.ini', 'w') as file:
            file.write(
                f"""[personal_info]
    name = {name}
    uuid = {DES_id_list[j]}
    ip = 127.0.0.1
    port = {j + 5060}
    [key_info]
    cert = {name}.crt
    key = {name}.key
    cert_path = ../certs
    [peer_info]
    miner_name_list = {[names[j] for j in miners]}
    miner_host_list = {[hosts[j] for j in miners]}
    miner_id_list = {[str(ids[j]) for j in miners]}
    worker_name_list = {[names[j] for j in workers]}
    worker_host_list = {[hosts[j] for j in workers]}
    worker_id_list = {[str(ids[j]) for j in workers]}
    neighbour_name_list = {[str(DES_name_list[_]) for _ in data_dict_list[j]['enid']]}
    neighbour_id_list = {[str(DES_id_list[_]) for _ in data_dict_list[j]['enid']]}"""
            )



    import cvxpy as cp
    Y = []
    cons = []
    target = 0
    for i, each_item_i in enumerate(data_dict_list):
        H = np.array(each_item_i['H'])
        G = np.array(each_item_i['G'])
        h = np.array(each_item_i['h'])
        a = np.array(each_item_i['a'])
        const = np.array(each_item_i['const'])
        Y.append(cp.Variable(H.shape[0]))
        target += 1/2 * cp.quad_form(Y[i], H) + a @ Y[i] + const
        cons += [G @ Y[i] <= h]
        # print(cp.Problem(cp.Minimize(cp.quad_form(y, H)), [G @ y <= h]).solve())
    for i, each_item_i in enumerate(data_dict_list):
        for pos_i, j in enumerate(each_item_i['enid']):
            if i < j:
                # print(i, j)
                each_item_j = data_dict_list[j]
                cons += [np.array(each_item_i['Cij'][pos_i]) @ Y[i] + np.array(each_item_i['xi0'][pos_i]) ==
                         np.array(each_item_i['Cji'][pos_i]) @ Y[j] + np.array(each_item_i['xj0'][pos_i])]
    pb = cp.Problem(cp.Minimize(target),constraints=cons)
    pb.solve(solver=cp.GUROBI)
    print(pb.status)
    print(pb.value)
    X = []
    for i, each_item_i in enumerate(data_dict_list):
        N = np.array(each_item_i['N'])
        x = np.array(each_item_i['x'])
        X.append(N @ Y[i].value + x)


    print('所有节点发电量：')
    for i, each_item_i in enumerate(data_dict_list):
        for dt in range(T):
            print(X[i][dt], end=' ')
        print()
    print('所有节点成本：')
    for i, each_item_i in enumerate(data_dict_list):
        H = np.array(each_item_i['H'])
        a = np.array(each_item_i['a'])
        const = np.array(each_item_i['const'])
        H_ori = np.array(each_item_i['H_ori'])
        c_ori = np.array(each_item_i['c_ori'])
        print((1/2 * cp.quad_form(Y[i], H) + a @ Y[i] + const).value)
        print((1/2 * cp.quad_form(X[i], H_ori) + c_ori @ X[i]).value)
    print('所有节点上游功率：')
    for i, each_item_i in enumerate(data_dict_list):
        for dt in range(T):
            print(X[i][2*T + dt], end=' ')
        print()
    print('所有节点决策变量（masked）：')
    for i, each_item_i in enumerate(data_dict_list):
        print(Y[i].value, end=' ')
        print()

    print('所有节点决策变量：')
    for i, each_item_i in enumerate(data_dict_list):
        print(X[i], end=' ')
        print()