import os
import subprocess as sp

from network_config import *

if os.path.exists("ca-cert/ca.crt") and os.path.exists("ca-cert/ca.key"):
    print("CA is ready")
else:
    print("CA is not ready, generate it first")
    print("Run generate-ca.py")
    exit()

if os.path.exists(path):
    sp.call(["rmdir", "/s", "/q", path], shell=True)
sp.call(["mkdir", path], shell=True)
sp.call(["mkdir", path + "\\certs"], shell=True)

for each_name, each_type, each_host, each_host_name, each_uid in zip(names, types, hosts, host_names, ids):
    if os.path.exists(path + '/' + each_name):
        sp.call(["rmdir", "/s", "/q", path + '/' + each_name], shell=True)
    sp.call(["mkdir", path + '\\' + each_name], shell=True)
    open(path + '/' + each_name + '/' + each_name + '.cnf', "w").write(
        """
        [ req ]
        default_bits		= 2048
        default_keyfile 	= privkey.pem
        prompt=no
        distinguished_name	= DN
        # x509_extensions	= v3_ca	
        string_mask = utf8only
        req_extensions = v3_req
        [v3_req]
        basicConstraints = CA:FALSE
        keyUsage = nonRepudiation, digitalSignature, keyEncipherment
        extendedKeyUsage = serverAuth
        subjectAltName = @alt_names
        [alt_names]
        DNS.1 = localhost
        IP.1 = 127.0.0.1
        [DN]
        C  = CN
        ST = Beijing
        L = Beijing
        O = DMChain
        OU = %s.%s.dmchain.com
        CN   = %s
        uid = %s
        """ % (each_name, each_type, 'localhost', each_uid)
    )
    sp.call(['openssl', 'genrsa', '-out', path + '/' + each_name + '/' + each_name + '.key', '2048'], shell=True)
    sp.call(['openssl', 'req',
             '-new', '-key', path + '/' + each_name + '/' + each_name + '.key',
             '-out', path + '/' + each_name + '/' + each_name + '.csr',
             '-config', path + '/' + each_name + '/' + each_name + '.cnf'],
            shell=True)
    sp.call(['openssl', 'x509', '-req',
             '-days', '180',
             '-in', path + '/' + each_name + '/' + each_name + '.csr',
             '-CA', 'ca-cert/ca.crt',
             '-CAkey', 'ca-cert/ca.key',
             '-extensions', 'v3_req',
             '-extfile', path + '/' + each_name + '/' + each_name + '.cnf',
             # '-CA', 'chainnode2/chainnode2.crt',
             # '-CAkey', 'chainnode2/chainnode  2.key',
             '-CAcreateserial',
             '-out', path + '/' + each_name + '/' + each_name + '.crt'], shell=True)
    sp.call(['copy',
              path + '\\' + each_name + '\\' + each_name + '.crt',
              path + '\\certs\\' + each_name + '.crt'], shell=True)
    # break

# input csr file
# csrFile = input("Enter the CSR file name: ")
#
# # print csr information
# print("CSR information:")
# # csr decoder and return the subject
# csrInfo = sp.check_output(['openssl', 'req', '-in', csrFile, '-noout','-subject'])
# print("".join(csrInfo.decode('utf-8').split("subject=")[1].replace(", ", "\n")))
# # validate csr
# print("Do you want to continue? (y/n)")
# if input().lower() == "y":
#     pass
# else:
#     exit()


# input expiration days
# validDate = input("Enter the expiration (days) of the certificate: ")

# openssl x509 -req -in fabrikam.csr -CA  contoso.crt -CAkey contoso.key -CAcreateserial -out fabrikam.crt -days 365 -sha256
# sp.call(['openssl', 'x509', '-req', '-in', csrFile, '-CA', 'ca-cert/ca.crt', '-CAkey', 'ca-cert/ca.key', '-CAcreateserial', '-out', 'server.crt', '-days', validDate, '-sha256'])
