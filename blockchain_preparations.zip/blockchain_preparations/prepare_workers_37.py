import os

from network_config_37 import *

DES_id_list = [ids[j] for j in DESs]
DES_name_list = [names[j] for j in DESs]

miner_id_list = [ids[j] for j in miners]
miner_name_list = [names[j] for j in miners]

worker_id_list = [ids[j] for j in workers]
worker_name_list = [names[j] for j in workers]


if not os.path.exists('config37'):
    os.mkdir('config37')
for j, name in enumerate(worker_name_list):
    if not os.path.exists(f'config37/{name}'):
        os.mkdir(f'config37/{name}')
    with open(f'config37/{name}/personal_settings.ini', 'w') as file:
        file.write(
            f"""[personal_info]
name = {name}
uuid = {worker_id_list[j]}
ip = 127.0.0.1
[key_info]
cert = {name}.crt
key = {name}.key
cert_path = ../certs
[peer_info]
miner_name_list = {[names[j] for j in miners]}
miner_host_list = {[hosts[j] for j in miners]}
miner_id_list = {[str(ids[j]) for j in miners]} 
DES_name_list = {[names[j] for j in DESs]}
DES_host_list = {[hosts[j] for j in DESs]}
DES_id_list = {[str(ids[j]) for j in DESs]}"""
        )
    # with open(f'config/{name}/formulation.json', 'w') as file:
    #     file.write(json.dumps(data_dict_list[j]))
